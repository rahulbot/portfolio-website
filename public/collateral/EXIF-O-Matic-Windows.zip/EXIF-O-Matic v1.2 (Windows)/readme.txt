
EXIF-O-Matic v1.2 (2009.01.22)

Welcome to EXIF-O-Matic!
Most digital cameras store loads of meta-data within the image files
that they create, these datum make up the EXIF standard.  They include
things like the exact time the photo was taken, the f-stop, the flash 
setting, etc.  I wanted to view this information in my online photo
album, but I couldn't find a nice EXIF library that exported to HTML,
so I wrote a small application around Drew Noakes' extraction library
  http://drewnoakes.com/code/exif/

Created by Rahulbotics.
  http://www.rahulbotics.com/

---------------
Getting Started
---------------

 ( Note to PC Users - double click the "EXIF-O-Matic.bat"
   file to run the program.  If it looks like a window appears
   and then vanishes, you probably need to download Java from
       http://java.sun.com/j2se/1.4.1/download.html
  )

Keep an eye on the status bar at the bottom of the window, it
gives instructions and feedback about what is going on.
It's pretty simple -
 1) Choose File->Open to load an image and view it's EXIF tags
 2) Click the "Export File" button to save a text or html version
    of the tags
 3) Click the "Process Folder" button to export the tags of all
    the images in the same folder

-------
Support
-------

If you have questions of bugs, please email 
  rahul@rahulbotics.com
To uninstall EXIF-O-Matic, just delete this folder.

Notes:
 - Mac Classic Java support is quite behind the times now, so
   it's not really worth my effort to get this working in that OS
 - This shouldn't do anything bad to your system, as it is
   such a simple applicaton.  But in case it does, I'm not
   liable for any damage you inflict upon yourself!

------------
Postcardware
------------
In homage to the old days of BBSing, I've released this software
as "postcard-ware". That means that if you use this and like it,
all I ask is that you send me a postcard from where you live.
Come on - postcards are cheap, and our sun-starved scientists
love communicating with the outside world! Our address is:

		Rahulbotics
		63 Irving St.
		Somverille, MA 02144

If you REALLY like this program, then consider going to the webpage
listed above and donating a bit of money to me via PayPal.  Just $5
or so.

-------
CHANGES
-------
v1.2 (2009.01.20)
 - moved over to rahulbotics for cleanup
v1.1.8 (2003.05.20)
 - added a preference for the field separator in exported TXT files, 
   which now defaults to be a tab
 - added the image filename to start of exported TXT files
 - fixed strange new bug that required it to sit in the Applications
   directory on Mac OSX
v1.1.7 (2003.05.10)
 - updated template to validate to HTML and CSS official specs
 - added OS/2 release, just because someone said it works fine
v1.1.6 (2003.04.11)
 - fixed big "process folder" bug, it now works right
 - tested and works with Java 1.4 on OSX
v1.1.5 (2003.02.11)
 - added preference to optionally export "Unknown" tags
 - updated to use metadataExtractor library v2.1
 - cleaned up interface (now resizable, fixed button sizes, moved
    image name to window titlebar, new menus on non-OSX systems)
 - fixed ouputed HTML file date to have correct month number
 - fixed launch scripts on Windows and Linux
v1.1 (2002.12.30)
 - updated to use new "metadataExtractor" library v2.0
 - (OSX) added file type handler for JPEG images
v1.0.4 (2002.12.02)
 - (OSX) added drop-tray border to image thumbnail for a more
   Aqua-like look :-)
v1.0.3 (2002.11.26)
 - only backend code changes, integrated revised IotF libraries
v1.0.2 (2002.11.20)
 - added an alert to let the user know when and why it finds an
   error in the formatting of a file's EXIF tags
v1.0.1 (2002.11.19)
 - (Linux) fixed shell script, thanks to David Rudder
v1.0 (2002.11.18)
 - Released for PC, Mac OS X, and Linux
 - Created by Rahul Bhargava, Institute of the Futute
