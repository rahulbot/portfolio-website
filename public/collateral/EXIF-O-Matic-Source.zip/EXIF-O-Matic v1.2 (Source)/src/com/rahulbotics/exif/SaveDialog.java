
package com.rahulbotics.exif;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.rahulbotics.gui.DescriptiveOptionPanel;

/**
 * This is the advance save dialog that pops up.  Its lets the user pick
 * between TXT and HTML saving....
 *
 *	@author	Rahul Bhargava
 */
public class SaveDialog extends JDialog implements ActionListener{

	/** These are the subpanels for the various options */
	private DescriptiveOptionPanel dopFileType;

	/** true means OK, false means cancel */
	private boolean okToSave;

	/** 
	 * Make the interface for this dialog.
	 *	@param	par	the parent frame to go modal on
	 */
	public SaveDialog(Frame par){
		super(par,true);
		setTitle("File Saving Options");
		//title
		JLabel header= new JLabel("File Saving Options");
		header.setFont( new Font("Serif",Font.PLAIN,18) );
		header.setBorder( BorderFactory.createEmptyBorder(10,10,5,10) );
		//options
		dopFileType = new DescriptiveOptionPanel(
			"File Type",
			"HTML","TXT",
				"Select \"HTML\" to save the EXIF tags about\n"+
				 "each image into a wepage as a nicely formatted\n"+
				 "table.  Select \"TXT\" to dump it to a regular\n"+
				 "text file with each tag on a new line.  The\n"+
				 "HTML does really look much nicer, trust me. But\n"+
				 "ugly text is easier to parse programatically ;-)");
		JPanel optionsPanel = new JPanel();
		optionsPanel.setLayout( new GridLayout(1,1,5,5) );
		optionsPanel.add(dopFileType);
		optionsPanel.setBorder( BorderFactory.createEmptyBorder(8,8,5,8) );
		//buttons
		JPanel buttonPanel = new JPanel();
		JButton saveButton = new JButton("OK");
		saveButton.addActionListener(this);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(new JLabel("           "));
		buttonPanel.add(new JLabel("           "));
		buttonPanel.add(new JLabel("           "));
		buttonPanel.add(new JLabel("           "));
		buttonPanel.add(cancelButton);
		buttonPanel.add(saveButton);
		//add it all to this panel
		JPanel parentPanel = new JPanel();	
		parentPanel.setLayout( new BorderLayout() );
		parentPanel.add(optionsPanel,BorderLayout.CENTER);
		parentPanel.add(buttonPanel,BorderLayout.SOUTH);
		//do the dialog part....
		this.setContentPane(parentPanel);
		this.setSize(400,190);
		this.setResizable(false);
		this.show();
	}

	/** 
	 * Return the option selected for the file type linking.
	 *	@return	Saves as HTML if true, TXT if false
	 */
	public boolean getHTML(){
		if(dopFileType.getSelectedIndex()==0) {
			//System.out.println("get local = true");
			return true;
		}
		//System.out.println("get local = false");
		return false;
	}

	/**
	 * Return the user button clicked.
	 *	@return	true means OK, false means cancel.  call this just
	 * 			after the dialog is shown.
	 */
	public boolean okToSave(){
		return okToSave;
	}
	
	/**
	 * Handle the OK and Cancel button clicks. Both hide the dialog box.
	 */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			if( ((JButton)obj).getText().equals("OK") ){
				okToSave = true;
				this.setVisible(false);
			} else if ( ((JButton)obj).getText().equals("Cancel") ){
				okToSave = false;
				this.setVisible(false);
			}
		}
	}	

}
