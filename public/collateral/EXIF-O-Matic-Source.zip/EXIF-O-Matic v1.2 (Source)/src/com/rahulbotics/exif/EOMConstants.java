package com.rahulbotics.exif;

import com.rahulbotics.Constants;

/** 
 * Just a useful place to collect constants used in this application.
 *
 *	@author Rahul Bhargava
 */
public interface EOMConstants extends Constants{

	public static String VERSION = "1.2";

	public static String APP_NAME = "Exif-O-Matic";
	
	public static String PREFS_FILE = "EOMPrefs.properties";

}
