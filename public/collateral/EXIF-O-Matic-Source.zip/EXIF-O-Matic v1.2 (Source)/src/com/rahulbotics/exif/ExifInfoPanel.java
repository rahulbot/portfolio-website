package com.rahulbotics.exif;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.rahulbotics.Constants;
import com.rahulbotics.gui.GUIUtilities;
import com.rahulbotics.gui.ImageBorder;
import com.rahulbotics.io.ImageUtilities;

/**
 * This displays an image and a table of the EXIF info it contains.
 * This is the heart of EXIF-O-Matic, the other class is just a shell.
 *
 *	@author	Rahul Bhargava
 */
public class ExifInfoPanel extends JPanel
						implements ActionListener {
	/** println if true */
	private static boolean DEBUG = false;
	/** this class does much of the parsing, I wrote it earlier, so I just left stuff there */
	private ExifInfoWriter myExifWriter;
	/** this is set after the file dialog, to see if it was cancelled */
	public boolean failed = false;
	/** a pointer back, mainly for modal stuff */
	private JFrame parent;

	/**
	* Build and pop up the interface for a file.
	*/
	public ExifInfoPanel(JFrame p,File f) {
		super();
		parent = p;
		myExifWriter = new ExifInfoWriter();
		myExifWriter.setFile(f);
		setupInterface();
	}
	/**
	* Build and pop up the interface, ask use to open a file.
	*/
	public ExifInfoPanel(JFrame p) {
		super();
		parent = p;
		//open a file and get it all ready
		myExifWriter = new ExifInfoWriter();
		if( myExifWriter.selectFile() == null) {
			failed = true;
			return;	//cancelled open
		}
		setupInterface();
	}

	/** constructor helper */
	private void setupInterface(){
		JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,5,10));
		//setup the title label
		JLabel myTitle = new JLabel( myExifWriter.getSelectedFileName(),JLabel.CENTER );
		myTitle.setFont( new Font("Serif", Font.PLAIN, 20) );
		//generate and load an image thumbnail
		ImageIcon myImageIcon = new ImageIcon( myExifWriter.getSelectedFile().toString() );
		ImageUtilities.resizeTo(myImageIcon,200);
		JLabel myLabel = new JLabel(myImageIcon);
		JPanel myLabelPanel;
    	if(Constants.isMacOSX) {
			myLabelPanel = ImageBorder.getOSXImageWellPanel(myLabel);
		} else {
	 		myLabelPanel = new JPanel(new BorderLayout());
	 		myLabelPanel.add(myLabel,BorderLayout.CENTER);
		}
		myLabelPanel.setPreferredSize(new Dimension(225,225));
		//setup the buttons
		JButton fileButton = new JButton("Export Info File");
		fileButton.addActionListener(this);
		fileButton.setBounds(30,270,180,26);
		JButton folderButton = new JButton("Process this Folder");
		folderButton.addActionListener(this);		
		folderButton.setBounds(30,300,180,26);
		leftPanel.add(myLabelPanel);
		leftPanel.add(fileButton);
		leftPanel.add(folderButton);
		leftPanel.setMinimumSize(new Dimension(260,330));
		leftPanel.setPreferredSize(new Dimension(260,330));
		//setup the list
		String[] columnNames = {"Tag Name","Tag Value"};
		output("about to get tags...");
		Object[][] tagInfo = myExifWriter.getTagsAsObjectArray();
		if(tagInfo == null){
			failed = true;
			return;	//couldn't read file
		}
		output("got ("+tagInfo.length+") tags...");
		JTable table = new JTable(tagInfo,columnNames);
		GUIUtilities.setCellEditable(table,false);
		JScrollPane jspTable = new JScrollPane(table);
		jspTable.setMinimumSize(new Dimension(350,330));
		//table.setPreferredScrollableViewportSize(new Dimension(450,350));
		//jspTable.setBounds(240,20,450,380);
		//add it all to the panel
		this.setLayout(new BorderLayout());
		this.setPreferredSize(new Dimension(700,450));
		//this.add(myTitle,BorderLayout.NORTH);
		this.add(leftPanel,BorderLayout.WEST);
		this.add(jspTable,BorderLayout.CENTER);
		this.setBorder(BorderFactory.createEmptyBorder(10,10,0,10));
		this.setVisible(true);
		parent.setTitle(EOMConstants.APP_NAME+" : "+myTitle.getText());
	}

	/**
	 * Create EXIF HTMl files for all those in this folder
	 */
	public void processFolder(){
		SaveDialog myDialog = new SaveDialog(this.parent);
		if(myDialog.okToSave()){
			if(myDialog.getHTML())
				myExifWriter.writeInfoForFolder(ExifInfoWriter.FILE_HTML);
			else
				myExifWriter.writeInfoForFolder(ExifInfoWriter.FILE_TXT);
		}
	}

	/**
	 * Write the HTML file for this folder
	 */
	public void writeInfoFile(){
		SaveDialog myDialog = new SaveDialog(this.parent);
		if(myDialog.okToSave()){
			if(myDialog.getHTML())
				myExifWriter.writeInfoForImage(ExifInfoWriter.FILE_HTML);
			else
				myExifWriter.writeInfoForImage(ExifInfoWriter.FILE_TXT);
		}
	}

	/**
	 * Handles the buttons...
	 */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			if( ((JButton)obj).getText().equals("Export Info File")){
				writeInfoFile();
			} else if( ((JButton)obj).getText().equals("Process this Folder")){
				processFolder();
			}
		}
	}
	
/******************************************************************************
 **		UTILITIES
 ******************************************************************************/
    
	/**
 	 * Just launch the thing!
	 */
    public static void main(String s[]) {
		JFrame myFrame = new JFrame("Exif Info Panel");
		myFrame.getContentPane().add( new ExifInfoPanel(myFrame) );
		myFrame.setBounds(10,10,700,450);
		myFrame.setVisible(true);
    }

	/**
 	 * utility println for debugging
	 */
	public static void output(String msg){
		if(DEBUG)
			System.out.println(" ExifInfoPanel : "+msg);
	}

}
