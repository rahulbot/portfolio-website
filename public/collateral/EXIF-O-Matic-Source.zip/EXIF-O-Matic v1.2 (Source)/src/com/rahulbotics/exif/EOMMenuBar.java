package com.rahulbotics.exif;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import com.apple.mrj.*;
import com.rahulbotics.gui.AboutDialog;

/** 
 * The menu bar for Exif-O-Matic.  Most of the actions are executed
 * from here.  It also has hooks for better Mac OSX - like behaviour.
 *
 *	@author Rahul Bhargava
 */
public class EOMMenuBar extends JMenuBar 
		implements ActionListener, EOMConstants,
					MRJAboutHandler, MRJQuitHandler, MRJOpenDocumentHandler,
					MRJPrefsHandler {

	private static boolean DEBUG = false;

	/** a pointer back fo routputting and accessors */
	private ExifOMatic par;

	/**
	 * Make the menu bar.
	 *	@param	p	the PictureStory parent
	 *	@param	f	the default font size
	 *	@param	i	the default image size
	 *	@param	s	the name of the default search site
	 */
	public EOMMenuBar(ExifOMatic p){
		super();
		par = p;
		registerMRJHandlers();
		addFileMenu();
		setEnabled("Export...",false);
		setEnabled("Close",false);
		stylizeMenu(this);
	}

	/**
	 * Register the About and Quit handlers to be this class.
	 */
	private void registerMRJHandlers(){
		MRJApplicationUtils.registerAboutHandler(this);
		MRJApplicationUtils.registerQuitHandler(this);
		MRJApplicationUtils.registerOpenDocumentHandler(this);
		if(isMacOSX) MRJApplicationUtils.registerPrefsHandler(this);
	}
	
	/**
	 * Add the platform-specific File menu.
	 */
	private void addFileMenu(){
		if(isMacOSX){
			this.add( buildMenu("File", false,
				new String[]{"Open...","Close","Export...","Process Folder...","-","Postcardware"}, new char[]{'O','W','E','F',' ','D'}, "","" ) );
		} else {
			this.add( buildMenu("File", false,
				new String[]{"Open...","Close","Export...","Process Folder...","-","Exit"}, new char[]{'O','W','E','F',' ','X'}, "","" ) );
			this.add( buildMenu("About", false,
				new String[]{"Preferences","-","About","Postcardware"}, new char[]{';',' ','I','D'}, "","" ) );				
		}
	}


	/**
	 * A lower-level utility to build the menus.
	 *	@param menuName	the name of the menu
	 *	@param 	group	true if you want the items to be a mutex, false otherwise
	 *	@param 	items	a string array of the items to go in this menu
	 *	@param 	shortcuts	the key to use as a shortcut for each item in the items array
	 *	@param	def		the default option to select, if group is true
	 *	@return	the menu that was created out of these items
	 */
	private JMenu buildMenu( String menuName, boolean group, String[] items, char[] shortcuts, String post, String def ){
		JMenu jm = new JMenu(menuName);
		stylizeMenu(jm);
		stylizeMenu(jm.getPopupMenu());
		ButtonGroup myButGrp = new ButtonGroup();
		for(int i=0;i<items.length;i++){
			if(items[i].equals("-")){
				jm.addSeparator();
			} else {
				JMenuItem j = new JMenuItem();
				if(group){
					j = new JRadioButtonMenuItem(items[i]+post);
					myButGrp.add(j);
					if( j.getText().indexOf(def) != -1 )
						j.setSelected(true);
				} else j = new JMenuItem(items[i]+post);
				if( shortcuts!=null )
					if(shortcuts[i]!=' ')
						j.setAccelerator( KeyStroke.getKeyStroke(shortcuts[i],OS_KEY_MASK) );
				stylizeMenu(j);
				j.addActionListener(this);
				jm.add(j);
			}
		}
		return jm;
	}

	/**
	 * Colorize the menu for the cool interface, though only on a PC.
	 *	@param	src		the menu to stylize
	 */
	public static JComponent stylizeMenu(JComponent src){
		/*if(isMacOSX) return src;
		src.setBorder(BorderFactory.createLineBorder(ColorBlack,1));
		src.setBackground( ColorDark );
		src.setFont( new Font("Sans Serif", Font.PLAIN, 12) );
		src.setForeground( ColorWhite );		*/
		return src;
	}

/******************************************************************************
 **		EVENT HANDLERS
 ******************************************************************************/

	/**
	 * Handles the edit buttons and the popupmenu items
	 */
	public void actionPerformed(ActionEvent e){
		Object o = e.getSource();
		//System.out.println("object = "+o);
		if(o instanceof JMenuItem){
			JMenuItem j = (JMenuItem) o;
			String s = j.getText();
			if ( s.equals("Open...")){
				par.open();
			} else if ( s.equals("Close")){
				par.close();
			} else if ( s.equals("Export...")){
				par.exportInfoForImage();
			} else if ( s.equals("Process Folder...")){
				par.processFolder();
			} else if ( s.equals("About")){
				par.about();
			} else if ( s.equals("Preferences")){
				par.showPrefsDialog();
			} else if ( s.equals("Postcardware")){
				AboutDialog.showPostcardware(par);
			} else if ( s.equals("Exit")){
				par.exit();			
			}
		}
	}
	
	/**
	 * Handles the Max OSX Quit event - close the application.
	 */
	public void handleQuit(){
		par.exit();		
	}

	/**
	 * Handles the Max OSX Preferences event - close the application.
	 */
	public void handlePrefs(){
		par.showPrefsDialog();
	}

	/** Handles the Max OSX About event - pops up the about box. */
	public void handleAbout(){
		par.about();
	}

	/** Handles the Max OSX open document event - pops up the about box. */
	public void handleOpenFile(File file){
		//System.out.println("got an open file!");
		par.openFile(file);
	}

/******************************************************************************
 **		UTILITY
 ******************************************************************************/

	/**
	 * Enable of disable the Export menu item
	 */
	public void setEnabled(String s,boolean b){
		for(int m=0;m<this.getMenuCount();m++){
			JMenu currMenu = this.getMenu(m);
			for(int i=0;i<currMenu.getItemCount();i++){
				JMenuItem currItem = currMenu.getItem(i);
				if(currItem != null) {
					if(currItem.getText().equals(s))
						currItem.setEnabled( b );
				}
			}
		}
	}

}
