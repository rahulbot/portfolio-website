package com.rahulbotics.exif;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.drew.imaging.jpeg.JpegMetadataReader;
import com.drew.imaging.jpeg.JpegProcessingException;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.MetadataException;
import com.drew.metadata.Tag;
import com.rahulbotics.Constants;
import com.rahulbotics.gui.Alerts;
import com.rahulbotics.gui.FileDialogs;
import com.rahulbotics.io.FileUtilities;
import com.rahulbotics.io.ImageUtilities;

/**
 * This will open a directory and walk it, creating a text file that
 * holds all the EXIF info pulled out of that image.  This uses the 
 * handy ExifExtractor from Drew Noakes: 
 *		http://drewnoakes.com/code/exif/
 *
 * <p> I should output in XML eventually using this DTD:
 * http://www.matthewkendall.com/imagemetadata/DIG35-wd1-20000306.dtd.txt
 * </p>
 *
 * <p>I should rename this to ExifManager or something...
 *
 *	@author	Rahul Bhargava
 */
public class ExifInfoWriter extends JFrame implements Constants,ActionListener {
	/** true if run as it's own app, false if nested by some other parent */
	static boolean independant = false;
	/** println if true */
	private static boolean DEBUG = false;
	/** generate a nice HTML file */
	public static final int FILE_HTML = 0;
	/** generate a plain old TXT file */
	public static final int FILE_TXT = 1;
	/** not used now, but eventually generate an XML file */
	public static final int FILE_XML = 2;

	/** the directory in which to place the .txt / .html files */
	private static String EXIF_SUB_DIR = "exif/";
	/** the directory in which to place the thumbnailed .jpg files */
	private static String THUMBNAIL_SUB_DIR = "thumbnails/";
	/** the directory in which to place the medium-sized .jpg files */
	private static String MEDIUM_SUB_DIR = "medium/";
	/** the file to write the JavaScript info to */
	private static String JS_FILE_NAME = "info.js";

	/** this holds the directory selected by the user */
	private File selectedFile;
	/** for outputting the status */
	private JTextArea status;
	
	/** helper for PhotoBot **/
	private JTextField jtfUserName;
	/** helper for PhotoBot **/
	private JTextField jtfYear;
	
	/**
	* Build and pop up the interface.
	*/
	public ExifInfoWriter() {
		super("PhotoBot Manager");
		addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent event) {
					close();
				}
			});
		this.getContentPane().setLayout(new BorderLayout());
		//make the buttons
		jtfUserName = new JTextField("rahulb");
		jtfYear = new JTextField("2004");
		JButton jbPickFolder2 = new JButton("Select File...");
		jbPickFolder2.addActionListener(this);
		JButton jbPickFolder = new JButton("Select File...");
		jbPickFolder.addActionListener(this);
		JButton jbCreateFile = new JButton("Generate for File");
		jbCreateFile.addActionListener(this);
		JButton jbCreate = new JButton("Generate for Folder");
		jbCreate.addActionListener(this);
		JButton jbCreateYear = new JButton("Generate for Year");
		jbCreateYear.addActionListener(this);
		JButton jbPhotoBot = new JButton("Prepare for PhotoBot");
		jbPhotoBot.addActionListener(this);
		JButton jbPhotoBotYear = new JButton("Prepare Year for PhotoBot");
		jbPhotoBotYear.addActionListener(this);
		//make the tab panels
		JPanel pbPanel = new JPanel(new FlowLayout());
		pbPanel.add(jbPickFolder2);
		pbPanel.add(new JLabel("username:"));
		pbPanel.add(jtfUserName);
		pbPanel.add(new JLabel("year:"));
		pbPanel.add(jtfYear);
		pbPanel.add(jbPhotoBot);
		pbPanel.add(jbPhotoBotYear);
		JPanel otherPanel = new JPanel(new FlowLayout());
		otherPanel.add(jbPickFolder);
		otherPanel.add(jbCreateFile);
		otherPanel.add(jbCreate);
		otherPanel.add(jbCreateYear);
		JTabbedPane tabs = new JTabbedPane();
		tabs.add("PhotoBot",pbPanel);
		tabs.add("EXIF Files",otherPanel);
		//and the status field
		status = new JTextArea();
		status.setEditable(false);
		status.setFont( new Font("SansSerif", Font.PLAIN, 9) );
		JScrollPane jspStatus = new JScrollPane(status);
		jspStatus.setPreferredSize(new Dimension(200,200));
		//finish setting up the JFrame
		this.getContentPane().add(tabs,BorderLayout.CENTER);
		this.getContentPane().add(jspStatus,BorderLayout.SOUTH);
		this.setBounds(50,50,500,400);
		//this.setResizable(false);
    }

	/**
	* Pop a file dialog to pick a file in the folder to then walk
	* for the images.
	*	@return	a file in the folder, null if problem
	*/
	public File selectFile(){
		setStatus("selecting file...");
		File myF = FileDialogs.showOpenAWT("Select an Image to Process",
									null,null,"jpg",this);
		if(myF == null){
			setStatus("no file selected");
			return null;
		}
		setFile(myF);
		return selectedFile;
	}

	/**
	* Sets the current file
	*	@param myF	the file to parse
	*/
	public void setFile(File myF){
		selectedFile = myF;
		setStatus("viewing file info for "+selectedFile.getAbsolutePath());
	}

/******************************************************************************
 **		PhotoBot stuff (for when independant)
 ******************************************************************************/
	
	public void prepareForPhotoBotYear(){
		File albumDir = selectedFile.getParentFile();
		File yearDir = albumDir.getParentFile();
		setStatus("** Generating for year "+yearDir);
		if(!yearDir.isDirectory()) return;
		File[] fileList = yearDir.listFiles();
		for(int i=0;i<fileList.length;i++){
			File currFile = fileList[i];
			if(currFile.isDirectory()){
				selectedFile = currFile;
				prepareForPhotoBot();
			}
		}		
		setStatus("** done for year "+yearDir);
	}
	
	//call this one
	public void prepareForPhotoBot(){
		File folder = selectedFile.isFile() ? new File(selectedFile.getParent()): selectedFile;
		File folder2 = new File(folder.getParent(),folder.getName().replace('.','_'));
		folder.renameTo(folder2);	//fix old folder names?
		writeInfoForFolder(folder2,false,FILE_HTML,"../../exif.css");
		try{
			writePhotoBotInfo(folder2,false,
				jtfUserName.getText(),jtfYear.getText());
		} catch (IOException ioe){
			System.out.println("CRAP!");
		}
	}

	//helper for prepareForPhotoBot
	private boolean writePhotoBotInfo(File f, boolean force, String userName, String userYear) throws IOException{
		if(f==null){
			setStatus("no folder selected");
			return false;
		}
		File folder = f.isFile() ? new File(f.getParent()): f;
		//make the subdirs
		File thumbDir = new File(folder,THUMBNAIL_SUB_DIR);
		File medDir = new File(folder,MEDIUM_SUB_DIR);
		File infoFile = new File(folder,JS_FILE_NAME);
		if(force || !thumbDir.exists()) thumbDir.mkdir();
		if(force || !medDir.exists()) medDir.mkdir();
		//pick only the images (".thm" are movie previews)
		File[] imgFiles = folder.listFiles(new FilenameFilter(){
					public boolean accept(File dir, String name){
						return name.toLowerCase().endsWith("jpg") ||
								name.toLowerCase().endsWith("avi") ||
								name.toLowerCase().endsWith("mp4") ||
								name.toLowerCase().endsWith("mov");
					}
				});
		StringBuffer info = new StringBuffer();
		Date now = GregorianCalendar.getInstance().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd G 'at' hh:mm:ss z");
		info.append("cgiLastEdited=\""+formatter.format(now)+"\";\n");
		info.append("cgiUser=\""+userName+"\";\n");
		info.append("cgiYear=\""+userYear+"\";\n");
		info.append("cgiFolder=\""+folder.getName()+"\";\n");
		info.append("cgiFiles = new Array("+imgFiles.length+");\n");
		int thumbCreatedCount = 0;
		int medCreatedCount = 0;
		File thumbFile,medFile;
		Image img;
		Image newImg;
		for(int i=0;i<imgFiles.length;i++){
			//System.out.println(i+" - "+imgFiles[i].getName());
			info.append("cgiFiles["+i+"] = new Array(\""+imgFiles[i].getName()+"\",");
			medFile = new File(medDir,imgFiles[i].getName());
			img = null;
			if( imgFiles[i].getName().toLowerCase().endsWith("jpg") &&
					(force || !medFile.exists())){
				img = new ImageIcon(imgFiles[i].getAbsolutePath()).getImage();
				newImg = ImageUtilities.resizeTo(img,new Dimension(640,480));
				ImageUtilities.writeJPEG( newImg,medFile,80 );
				medCreatedCount++;
			}
			if(imgFiles[i].getName().toLowerCase().endsWith("avi")){
				if(new File(FileUtilities.removeExtension(imgFiles[i].getAbsolutePath())+".THM").exists()) {
					thumbFile = new File(thumbDir,FileUtilities.removeExtension(imgFiles[i].getName())+".jpg");
					info.append("\""+thumbFile.getName()+"\","+(imgFiles[i].length()/1000)+");\n");
				} else {
					thumbFile=null;
					info.append((imgFiles[i].length()/1000)+");\n");
				}
			}else if(imgFiles[i].getName().toLowerCase().endsWith("mp4") || imgFiles[i].getName().toLowerCase().endsWith("mov")){
				thumbFile = null;
				info.append((imgFiles[i].length()/1000)+");\n");
			}else{
				thumbFile = new File(thumbDir,imgFiles[i].getName());
				if(img == null) img = new ImageIcon(imgFiles[i].getAbsolutePath()).getImage();
				info.append(img.getWidth(null)+","+img.getHeight(null)+","+(imgFiles[i].length()/1000)+");\n");
			}
			if(thumbFile!=null){
				if(force || !thumbFile.exists()){
					if(imgFiles[i].getName().toLowerCase().endsWith("avi")){
						String thmFilename = FileUtilities.removeExtension(imgFiles[i].getAbsolutePath())+".THM";
						img = new ImageIcon(thmFilename).getImage();
					} else {
						if(img == null) img = new ImageIcon(imgFiles[i].getAbsolutePath()).getImage();
					}
					newImg = ImageUtilities.resizeTo(img,new Dimension(100,75));
					//check for bad sizing bug...
					//if(newImg.getWidth(null)!=-1 && newImg.getHeight(null)!=-1)
					 ImageUtilities.writeJPEG( newImg,thumbFile,80 );
					thumbCreatedCount++;
				}
			}
		}
		info.append("cgiImgCount="+imgFiles.length+";\n");
		setStatus("  wrote "+thumbCreatedCount+" thumbs and "+medCreatedCount+" mediums of "+imgFiles.length+" total files into "+folder.getName()+"/");
		FileWriter infoWriter = null;
		if(force || !infoFile.exists()){
			infoWriter = new FileWriter(infoFile);
			infoWriter.write(info.toString());
			infoWriter.flush();
			infoWriter.close();
		}
		return true;
	}
	
	//don't call this anymore...
	private boolean writeThumbsForFolder(File f, boolean force, String destDirName, Dimension dim){
		if(f==null){
			setStatus("no folder selected");
			return false;
		}
		File folder = f.isFile() ? new File(f.getParent()): f;
		//make the subdir
		File subDir = new File(folder,destDirName);
		if(force || !subDir.exists()) subDir.mkdir();
		//pick only the images (".thm" are movie previews)
		File[] imgFiles = folder.listFiles(new FilenameFilter(){
					public boolean accept(File dir, String name){
						return name.toLowerCase().endsWith("jpg") ||
								name.toLowerCase().endsWith("thm");
					}
				});
		int createdCount = 0;
		for(int i=0;i<imgFiles.length;i++){
			File destFile = new File(subDir,imgFiles[i].getName());
			if(force || !destFile.exists()){
				createdCount++;
				Image img = ImageUtilities.getImage(imgFiles[i].getAbsolutePath());
				Image newImg = ImageUtilities.resizeTo(img,dim);
				ImageUtilities.writeJPEG( newImg,destFile,70 );
			}
		}
		setStatus("  wrote thumbnailed images for "+createdCount+"/"+imgFiles.length+" image files in \""+folder.getName()+"/"+destDirName);
		return true;
	}


/******************************************************************************
 **		WRITERS
 ******************************************************************************/

	public boolean writeInfoForYear(int fileType){
		return writeInfoForYear( selectedFile.getParentFile().getParentFile(),fileType );
	}
	/**
	* Create EXIF info files in each of the sub directories of 
	* theindicated the directory.
	*	@param	yearDir	the folder to walk
	*/
	private boolean writeInfoForYear(File yearDir,int fileType){
		if(yearDir==null){
			setStatus("no folder selected");
			return false;
		}
		if(!yearDir.isDirectory()) return false;
		File[] fileList = yearDir.listFiles();
		for(int i=0;i<fileList.length;i++){
			File currFile = fileList[i];
			if(currFile.isDirectory()){
				if(independant){
					if ( !writeInfoForFolder(currFile,
						false,fileType,"../../../../exif.css") )
						//if ( !writeInfoForFolder(currFile,false,fileType,"exif.css") )
						setStatus(currFile.getName()+" : error on file write");
				} else {
					if ( !writeInfoForFolder(currFile,
						EOMPrefs.get(EOMPrefs.EXPORT_UKNOWNS).equals("true"),
						fileType,"../../../../exif.css") )
						//if ( !writeInfoForFolder(currFile,false,fileType,"exif.css") )
						setStatus(currFile.getName()+" : error on file write");
				}
			}
		}
		return true;
	}

	public boolean writeInfoForFolder(int fileType){
		if(independant)
			return writeInfoForFolder(selectedFile.getParentFile(),
				false,fileType,"exif.css");
		return writeInfoForFolder(selectedFile.getParentFile(),
			EOMPrefs.get(EOMPrefs.EXPORT_UKNOWNS).equals("true"),
			fileType,"exif.css");
	}
	public boolean writeInfoForFolder(File f,int fileType){
		if(independant)
			return writeInfoForFolder(f,
				false,fileType,"exif.css");
		return writeInfoForFolder(f,
			EOMPrefs.get(EOMPrefs.EXPORT_UKNOWNS).equals("true"),
			fileType,"exif.css");
	}
	/**
	* Take a folder and create a .txt file for each with the EXIF
	* info that can be extracted from the .jpg files inside of it.
	*	@param	folder	the folder to walk, or a file in the folder
	*	@param	showAll	true if you want to use the unknown tags
	*	@return true if everything went ok, false is some problem
	*/
	private boolean writeInfoForFolder(File f, boolean showAll,int fileType,String remoteCSS){
		if(f==null){
			setStatus("no folder selected");
			return false;
		}
		File folder = f.isFile() ? new File(f.getParent()): f;
		//make the subdir
		File subDir = new File(folder,EXIF_SUB_DIR);
		subDir.mkdir();
		//pick only the images
		File[] imgFiles = folder.listFiles(new FilenameFilter(){
					public boolean accept(File dir, String name){
						return name.toLowerCase().endsWith("jpg");
					}
				});
		for(int i=0;i<imgFiles.length;i++){
			File currFile = imgFiles[i];
			//setStatus(" - "+currFile.getName());
			writeInfoForImage(currFile,subDir,showAll,fileType,remoteCSS);
		}
		if(independant)
			setStatus("  created info files for "+imgFiles.length+" image files in \""+folder.getName()+"/"+EXIF_SUB_DIR);
		else 
			setStatus("created info files for "+imgFiles.length+" image files in \""+folder.getName()+"/"+EXIF_SUB_DIR);
		return true;
	}

	public boolean writeInfoForImage(int fileType){
		if(independant)
			return writeInfoForImage(selectedFile,selectedFile.getParentFile(),
				false,fileType,null);
		return writeInfoForImage(selectedFile,selectedFile.getParentFile(),
			EOMPrefs.get(EOMPrefs.EXPORT_UKNOWNS).equals("true"),fileType,null);
	}
	public boolean writeInfoForImage(int fileType,String remoteCSS){
		if(independant)
			return writeInfoForImage(selectedFile,selectedFile.getParentFile(),
				false,fileType,remoteCSS);
		return writeInfoForImage(selectedFile,selectedFile.getParentFile(),
			EOMPrefs.get(EOMPrefs.EXPORT_UKNOWNS).equals("true"),fileType,remoteCSS);
	}
	/**
	* Take a file and create a .txt file for each with the EXIF
	* info that can be extracted from the .jpg files inside of it.
	*	@param	currFile	the file to get the info from
	*	@param	dirToWriteIn	the folder to write the .txt file in
	*	@param	showAll	true if you want to use the unknown tags
	 *	@param	fileType	the constant designating what type of file to write
	 *	@param	remoteCSS	null if the HTML file should include the CSS in it
	*	@return true if everything went ok, false is some problem
	*/
	private boolean writeInfoForImage(File currFile, File dirToWriteIn, boolean showAll, int fileType, String remoteCSS){
		if(currFile==null){
			setStatus("no file selected");
			return false;
		}
		output("write info for image");
		FileWriter outFile = null;
		try{
			String fileIdent = currFile.getName().substring(0,currFile.getName().lastIndexOf("."));
			outFile = openInfoFile(dirToWriteIn,fileIdent,fileType,remoteCSS);
			Metadata metadata = JpegMetadataReader.readMetadata(currFile);
			Iterator directories = metadata.getDirectoryIterator();
			while (directories.hasNext()) {
			    Directory directory = (Directory)directories.next();
			    writeDirectoryName(directory.getName(),outFile,fileType);
			    // iterate through tags and print to System.out
			    Iterator tags = directory.getTagIterator();
			    while (tags.hasNext()) {
			        Tag tag = (Tag)tags.next();
					if( (tag.getTagName().indexOf("Unknown") == -1) || showAll)
						writeTag(tag,outFile,fileType);
			    }
			}
			closeInfoFile(outFile,fileType);
			output("created info file for "+currFile.getName());
			if(!independant)
				setStatus("created info file for "+currFile.getName());
		} catch (java.lang.ArrayIndexOutOfBoundsException aiobe){
			setStatus("     ERROR : "+aiobe);
			closeInfoFile(outFile,fileType);
			return false;
		} catch (java.lang.NegativeArraySizeException nase){
			setStatus("     ERROR : "+nase);
			closeInfoFile(outFile,fileType);
			return false;		
		} catch (JpegProcessingException jpe){
			jpe.printStackTrace();
			setStatus("     ERROR : "+jpe);
			return false;
		}
		return true;
	}

/******************************************************************************
 **		WRITER HELPERS
 ******************************************************************************/

	/**
	 * Get the file started for this type
	 *	@param	file		the folder where to write the files
	 *	@param	ident		the name of the file, minus the extension
	 *	@param	fileType	should be one of the constants designating the file type
	 *	@param	remoteCSS	null if the HTML file should include the CSS in it,
	 *						otherwise the path to the file to link to
	 */
	private FileWriter openInfoFile(File dir,String ident,int fileType,String remoteCSS){
		output("open info file");
		FileWriter outFile = null;
		try{
			switch(fileType){
				case FILE_TXT:
					outFile = new FileWriter( new File(dir,ident+".txt") );
					outFile.write(ident+".jpg - EXIF Information"+EOL);
					break;
				case FILE_XML:
					//outFile = new FileWriter( new File(dir,ident+".xml") );
					break;
				case FILE_HTML:
					outFile = new FileWriter( new File(dir,ident+".html") );					
					outFile.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">"+EOL+EOL);
					outFile.write("<html>"+EOL+EOL);
					outFile.write("  <head>"+EOL);
					outFile.write("    <title>"+ident+".jpg - EXIF Information</title>"+EOL);
					outFile.write("    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">"+EOL);
					if(remoteCSS!=null){
						outFile.write("    <link rel=\"stylesheet\" href=\""+remoteCSS+"\" type=\"text/css\">"+EOL);
						//and now write the CSS file as well!
						if(remoteCSS.equals("exif.css")){
							FileWriter cssFile = new FileWriter( new File(dir,"exif.css") );
							cssFile.write( FileUtilities.getStringFromResource("exif.css") );
							cssFile.flush();
							cssFile.close();
						}
					} else {
						outFile.write("    <style type=\"text/css\">"+EOL);
						outFile.write( FileUtilities.getStringFromResource("exif.css") );
						outFile.write("    </style>"+EOL);
					}
					//read in the file and dump it!
					outFile.write("    <meta name=\"generator\" content=\"EXIF-O-Matic\">"+EOL);
					outFile.write("  </head>"+EOL+EOL);
					outFile.write("<body>"+EOL+EOL);
					outFile.write(" <center>"+EOL+EOL);
					outFile.write("  <table style=\"margin-left: auto; margin-right: auto; text-align: center;\">");
					//outFile.write("  <table>"+EOL);
					outFile.write("  <tr><td colspan=2 class=\"header\">"+ident+".jpg</td></tr>"+EOL);
					break;
			}
		} catch (IOException ioe){
			ioe.printStackTrace();
			setStatus("     ERROR : "+ioe);
		}
		return outFile;
	}
	
	/**
	 * Write the closing info and close up the file
	 *	@param	file		the pre-initialized file to write to
	 *	@param	fileType	should be one of the constants designating the file type
	 */
	private void closeInfoFile(FileWriter file,int fileType){
		output("close info file");
		if(file==null) return;
		try{	
			switch(fileType){
				case FILE_TXT:
					file.write(EOL);
					break;
				case FILE_XML:
					//file.write(tag.getTagName()+" : "+tag.getDescription()+"\n");
					break;
				case FILE_HTML:
					Calendar now = Calendar.getInstance();
					file.write("  <tr><td colspan=2 class=\"details\">");
					file.write("generated by <a href=\""+EOMConstants.HOMEPAGE+"exifomatic/\">"+
								EOMConstants.APP_NAME+"</a> on "+now.get(Calendar.YEAR)+"."+
								(now.get(Calendar.MONTH)+1)+"."+now.get(Calendar.DATE));
					file.write("</td></tr>"+EOL);
					file.write("  </table>"+EOL+EOL);
					file.write(" </center>"+EOL+EOL);
					file.write("</body>"+EOL+EOL);
					file.write("</html>"+EOL+EOL);
					break;
			}
			file.flush();
			file.close();
		} catch (IOException ioe){
			ioe.printStackTrace();
			setStatus("     ERROR : "+ioe);
		}
	}

	/**
	 * Write the Metadata Directory name to a file in a format
	 *	@param	name	the name of the tag to write
	 */
	private void writeDirectoryName(String name, FileWriter file,int fileType){
		try{	
			switch(fileType){
				case FILE_TXT:
					file.write("- "+name+EOL);
					break;
				case FILE_XML:
					//file.write(tag.getTagName()+" : "+tag.getDescription()+EOL);
					break;
				case FILE_HTML:
					file.write("  <tr>"+EOL);
					file.write("    <td colspan=2 class=\"directoryname\">"+name+"</td>"+EOL);
					file.write("  </tr>"+EOL);
					break;
			}
		} catch (IOException ioe){
			ioe.printStackTrace();
			setStatus("     ERROR : "+ioe);
		}
	}

	/**
	 * Write the EXIF tag info to a file in a format
	 *	@param	tag		the tag to write about
	 *	@param	file	the pre-initialized file to write to
	 *	@param	fileType	should be one of the constants designating the file type
	 */
	private void writeTag(Tag tag, FileWriter file,int fileType){
		try{	
			switch(fileType){
				case FILE_TXT:
					//file.write(tag.getTagName()+" : "+tag.getDescription()+EOL);
					file.write(tag.getTagName()+
						EOMPrefs.getDelimitor(EOMPrefs.get(EOMPrefs.TXT_DELIMITOR))+
						tag.getDescription()+EOL);
					break;
				case FILE_XML:
					//file.write(tag.getTagName()+" : "+tag.getDescription()+EOL);
					break;
				case FILE_HTML:
					file.write("  <tr>"+EOL);
					file.write("    <td class=\"tagname\">"+tag.getTagName()+"</td>"+EOL);
					file.write("    <td class=\"tagdescrip\">"+tag.getDescription()+"</td>"+EOL);
					file.write("  </tr>"+EOL);
					break;
			}
		} catch (MetadataException me ){
			me.printStackTrace();
			setStatus("     ERROR : "+me);
		} catch (IOException ioe){
			ioe.printStackTrace();
			setStatus("     ERROR : "+ioe);
		}
	}

/******************************************************************************
 **		UTILITIES
 ******************************************************************************/

	/**
	* Add something to the status output
	*/
	public void setStatus(String msg){
		ExifOMatic.setStatus(msg);
		if(independant) status.append(msg+"\n");
	}

	/**
	* Dismiss the window
	*/
    public void close() {
        setVisible(false);
        dispose();
    }
    
	/**
	* Just launch the thing!
	*/
    public static void main(String s[]) {
		ExifInfoWriter myManager = new ExifInfoWriter();
		myManager.independant = true;
		myManager.setVisible(true);
    }

	/**
	 * Handles the buttons...
	 */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			String buttName = ((JButton)obj).getText();
			if( buttName.equals("Select File...")){
				selectedFile = selectFile();
			} else if( buttName.equals("Generate for File")){
				writeInfoForImage(FILE_HTML);
			} else if( buttName.equals("Generate for Folder")){
				writeInfoForFolder(FILE_HTML);
			} else if( buttName.equals("Generate for Year")){
				writeInfoForYear(FILE_HTML);
			} else if( buttName.equals("Prepare for PhotoBot")){
				prepareForPhotoBot();
			} else if( buttName.equals("Prepare Year for PhotoBot")){
				prepareForPhotoBotYear();
			}
		}
	}	

	/**
	 * Return the currently selected file
	 *	@return	the file, null if none
	 */
	public File getSelectedFile(){
		return selectedFile;
	}

	/**
	 * Return the currently selected file's name
	 *	@return	the file, null if none
	 */
	public String getSelectedFileName(){
		if(selectedFile!=null)
			return selectedFile.getName();
		return null;
	}

	/**
	 * Return an object array representing the tags.
	 * This can then be used to build a simple JTable.
	 *	@return	an object array, [ n x 2 ]
	 */
	public Object[][] getTagsAsObjectArray(){
		try{
			Metadata metadata = JpegMetadataReader.readMetadata(getSelectedFile());
			Iterator directories = metadata.getDirectoryIterator();
			int tagCount = 0;
			while(directories.hasNext()){
				Directory directory = (Directory)directories.next();
				tagCount += directory.getTagCount();
			}
			output(selectedFile.getName()+" : tag count = "+tagCount);
			Object[][] o = new Object[tagCount][2];
			directories = metadata.getDirectoryIterator();
			int i=0;
			while (directories.hasNext()) {
			    Directory directory = (Directory)directories.next();
			    // iterate through tags and print to System.out
			    Iterator tags = directory.getTagIterator();
			    while (tags.hasNext()) {
			        Tag tag = (Tag)tags.next();
					o[i][0] = tag.getTagName();
					o[i][1] = tag.getDescription();
					i=i+1;
			    }
			}
			return o;
		} catch (Exception e){
			output(e.toString());
			String msg = e.toString();
			int divider = msg.indexOf(":");
			if(divider > -1) msg = msg.substring(divider+1,msg.length());
			Alerts.showError("Error While Opening",
				"There appears to be a problem with "+selectedFile.getName()+" :\n"+
				msg);
			return null;
		}
	}

	/**
 	 * utility println for debugging
	 */
	public static void output(String msg){
		if(DEBUG)
			System.out.println(" ExifInfoWriter : "+msg);
	}

}
