
package com.rahulbotics.exif;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

/**
 * Shows preferences.
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class PrefsDialog extends JDialog implements ActionListener{
	
	private JCheckBox jcbUnknownTags;
	private JComboBox jcbDelimitor;

	/** 
	 * Make the interface for this dialog.
	 *	@param	par	the parent frame to go modal on
	 */
	public PrefsDialog(Frame par){
		super(par,true);
		setTitle("Preferences");
		//control objects
		jcbUnknownTags = new JCheckBox(
			"Export unknown tags",
			EOMPrefs.get(EOMPrefs.EXPORT_UKNOWNS).equals("true")
		);
		jcbUnknownTags.setBounds(15,16,200,25);
		JLabel label1 = new JLabel("Text Field Seperator : ",JLabel.LEFT);
		label1.setBounds(17,50,150,25);
		jcbDelimitor = new JComboBox(EOMPrefs.getDelimitorKeys());
		jcbDelimitor.setBounds(155,51,125,26);
		//Prefs Panel
		JPanel prefsPanel = new JPanel(null);
		prefsPanel.add(jcbUnknownTags);
		prefsPanel.add(label1);
		prefsPanel.add(jcbDelimitor);
		prefsPanel.setBorder( BorderFactory.createEmptyBorder(10,10,10,10) );
		//buttons
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JButton saveButton = new JButton("OK");
		saveButton.addActionListener(this);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		buttonPanel.add(cancelButton);
		buttonPanel.add(saveButton);
		//add it all to this panel
		JPanel parentPanel = new JPanel();	
		parentPanel.setLayout( new BorderLayout() );
		parentPanel.add(prefsPanel,BorderLayout.CENTER);
		parentPanel.add(buttonPanel,BorderLayout.SOUTH);
		//do the dialog part....
		this.setContentPane(parentPanel);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we){
				dispose();
			}
		});
		this.setSize(300,300);
		this.setResizable(false);
		jcbDelimitor.setSelectedItem(EOMPrefs.get(EOMPrefs.TXT_DELIMITOR));
	}
	
	/**
	 * Handle the OK and Cancel button clicks. Both hide the dialog box.
	 */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			if( ((JButton)obj).getText().equals("OK") ){
				EOMPrefs.set(EOMPrefs.EXPORT_UKNOWNS,jcbUnknownTags.isSelected()+"");
				EOMPrefs.set(EOMPrefs.TXT_DELIMITOR,jcbDelimitor.getSelectedItem().toString());
				this.setVisible(false);
			} else if ( ((JButton)obj).getText().equals("Cancel") ){
				this.dispose();
			}
		}
	}	

}
