package com.rahulbotics.exif;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JTextField;

import com.rahulbotics.gui.AboutDialog;
import com.rahulbotics.gui.GUIUtilities;
import com.rahulbotics.io.ImageUtilities;

/**
 * A simple app to export the EXIF info that digicams put in their
 * JPGs to files so they are easier to view.  Actually, most of the
 * functionality is in ExifInfoPanel.
 *
 * TODO
 * 	 - add appleScript events...
 * 	 - for 1.4.1, integrate photoorganizer code:
 *
 *String path = ;
 *BasicJpeg image = new BasicJpeg(new File(path));
 *AbstractImageInfo info = BasicJpeg.getInfo();
 *if(info instanceOf Exif){
 *	Enumeration e = ((Exif) BasicJpeg.getInfo().getReport()).tags();
 *} else {
 *
 *}
 *
 *	@author	Rahul Bhargava
 */
public class ExifOMatic extends JFrame implements EOMConstants {
	/** the menu bar handles lots of the features */
	private EOMMenuBar myMenuBar;
	/** for global outputting  */
	static public JTextField status = new JTextField("choose File->Open to get started");
	/** null if no file open  */
	private ExifInfoPanel myInfoPanel;

	/**
	 * Build up the Frame
	 */
	public ExifOMatic() {
		super("EXIF-O-Matic");
		System.setProperty("apple.laf.useScreenMenuBar","true");
		//System.setProperty("apple.awt.brushMetalLook","true");
		addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent event) {
					exit();
				}
			});
    		EOMPrefs.load();
		//set up the menu bar
		myMenuBar = new EOMMenuBar(this);
		this.setJMenuBar(myMenuBar);
		//set up the status bar
		status.setFont( new Font("SanSerif", Font.PLAIN, 10) );
		status.setBorder( BorderFactory.createEmptyBorder(8,8,8,8) );
		status.setForeground( new Color(51,51,80) );
		status.setEditable(false);
		status.setOpaque(false);
		//finish setting up the JFrame
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(status,BorderLayout.SOUTH);
		GUIUtilities.setNativeLookAndFeel();
		GUIUtilities.setFrameSize(this,710,455);
		this.setResizable(true);
		setVisible(true);
	}

	/**
	 * Ask the user to select an image, then display it and it's EXIF info
	 */
	public void open(){
		ExifInfoPanel myInfoPanel2 = new ExifInfoPanel(this);
		if(myInfoPanel2.failed) return;	//cancelled
		loadInfoPanel(myInfoPanel2);
	}

	/**
	 * display a file and it's EXIF info
	 */
	public boolean openFile(File f) {
		if(!f.exists()){
			return false;
		}
		ExifInfoPanel myInfoPanel2 = new ExifInfoPanel(this,f);
		loadInfoPanel(myInfoPanel2);
		return true;
	}

	/** open helper */
	private void loadInfoPanel(ExifInfoPanel newPanel){
		if(myInfoPanel != null) this.remove(myInfoPanel);	//dump the old one
		myInfoPanel = newPanel;
		this.getContentPane().add(myInfoPanel,BorderLayout.CENTER);
		myMenuBar.setEnabled("Export...",true);
		myMenuBar.setEnabled("Close",true);
		this.validate();
	}

	/**
	 * If there is an image open, close it and fix the menus
	 */
	public void close(){		
		if(myInfoPanel != null) {	//dump the old one
			this.remove(myInfoPanel);
			myInfoPanel = null;
			this.validate();
		}
		myMenuBar.setEnabled("Export...",true);
		myMenuBar.setEnabled("Close",true);
		this.setTitle("EXIF-O-Matic");
		ExifOMatic.setStatus("image closed, choose File->Open to get started");
	}

	/** When an image is open, write the info for it */
	public void exportInfoForImage(){
		myInfoPanel.writeInfoFile();
	}

	public void showPrefsDialog(){
		PrefsDialog pd = new PrefsDialog(this);
		pd.setVisible(true);
	}

	/** Ask the user to pick a folder, then make EXIF html files for it */
	public void processFolder(){
		if(myInfoPanel == null){
			ExifInfoWriter tempExifWriter = new ExifInfoWriter();
			tempExifWriter.selectFile();
			SaveDialog myDialog = new SaveDialog(this);
			if(myDialog.okToSave()){
				if(myDialog.getHTML())
					tempExifWriter.writeInfoForFolder(ExifInfoWriter.FILE_HTML);
				else
					tempExifWriter.writeInfoForFolder(ExifInfoWriter.FILE_TXT);
			}
		} else myInfoPanel.processFolder();
	}

	/** Write the Exif into for the folder's files */
	public boolean processFolder(File f){
		if(!f.exists()) return false;
		ExifInfoWriter tempExifWriter = new ExifInfoWriter();
		tempExifWriter.writeInfoForFolder(f,ExifInfoWriter.FILE_HTML);
		return true;
	}

	/** Display the Mac OSX-like about box */
	public void about(){
		AboutDialog about = new AboutDialog(this,"EXIF-O-Matic",
			VERSION,"http://www.instituteofthefuture.org/exifomatic/",
			ImageUtilities.getImageIconFromResource("exificon.jpg") );
	}

	/** Dismiss the window */
    public void exit() {
    	EOMPrefs.store();
        setVisible(false);
        dispose();
        System.exit(0);
    }

	/**
	 * Add a note to the status window along the bottom
	 *	@param	msg	the String to show, no logging currently
	 */
    public static void setStatus(String msg) {
        status.setText("> "+msg);
    }
    
	/**
	 * Just launch the thing!
	 */
    public static void main(String s[]) {
		ExifOMatic myImageInfo = new ExifOMatic();
    }

}
