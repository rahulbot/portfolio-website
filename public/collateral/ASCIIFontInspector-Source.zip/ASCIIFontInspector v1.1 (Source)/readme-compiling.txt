
ASCIIFontInspector Source Code v1.1 (2009.01.22)


--------
BUILDING
--------

ASCIIFontInspector uses ant to compile.  Ant is a fantastic open-source
cross-platform build tool created by the Apache group.

There is a little tutorial about how to set ant up at:
  http://builder.com.com/article.jhtml?id=r00120020206jam01.htm
and you can find a reference for it at:
  http://jakarta.apache.org/ant/manual/index.html

However, the home build system is Mac OSX, so I warn you not to be
too astonished if something goes screwy on a PC of Linux.
