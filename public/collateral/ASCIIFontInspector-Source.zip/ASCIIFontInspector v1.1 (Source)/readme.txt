
ASCIIFontInspector v1.1 (2009.01.22)

ASCIIFontInspector is just a small application for looking closer
at a font.  When you select a font, it displays all the standard
Roman characters in a table.  You can click each of the letters to
see a bigger version of it on the left.  You can save the character
to a JPEG, or export it to ASCII-art.  As the name suggests, this
only supports ascii characters (because that is all I needed to
work with).

Created by your friends at the Institute of the Future.
  http://www.instituteofthefuture.org/fontinspector/

-------
Support
-------

If you have questions of bugs, please email 
  inspector@instituteofthefuture.org
To uninstall ASCIIFontInspector, just delete this folder.

Notes:
 - Mac Classic Java support is quite behind the times now, so
   it's not really worth my effort to get this working in that OS
 - This shouldn't do anything bad to your system, as it is
   such a simple applicaton.  But in case it does, I'm not
   liable for any damage you inflict upon yourself!

------------
Postcardware
------------
In homage to the old days of BBSing, I've released this software
as "postcard-ware". That means that if you use this and like it,
all I ask is that you send me a postcard from where you live.
Come on - postcards are cheap, and our sun-starved scientists
love communicating with the outside world! Our address is:
 
		Rahulbotics
		63 Irving St.
		Somerville, MA 02144

If you REALLY like this program, then consider going to the webpage
listed above and donating a bit of money to me via PayPal.  Just $5
or so.

-------
CHANGES
-------
v1.1 (2009.01.22)
 - Updated for new Java and release packaging system
v1.0 (2002.12.07)
 - First release, OSX only
