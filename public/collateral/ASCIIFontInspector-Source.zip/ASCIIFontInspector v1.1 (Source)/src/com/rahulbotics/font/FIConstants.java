package com.rahulbotics.font;

import com.rahulbotics.Constants;


/** 
 * Just a useful place to collect constants used in this application.
 *
 *	@author Rahul Bhargava
 */
public interface FIConstants extends Constants {

	public static String APP_VERSION = "1.1";
	public static String APP_NAME = "ASCIIFontInspector";
	public static String APP_HOMEPAGE = "http://www.rahulbotics.com/fontinspector/";
	public static String APP_ICON = "FontInspectorIcon.gif";

}
