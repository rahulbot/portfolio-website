package com.rahulbotics.font;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.apple.mrj.MRJAboutHandler;
import com.apple.mrj.MRJApplicationUtils;
import com.apple.mrj.MRJQuitHandler;
import com.rahulbotics.gui.AboutDialog;
import com.rahulbotics.gui.Alerts;
import com.rahulbotics.gui.FileDialogs;
import com.rahulbotics.gui.FontSelectPanel;
import com.rahulbotics.gui.GUIUtilities;
import com.rahulbotics.gui.ImageBorder;
import com.rahulbotics.io.ImageUtilities;

/**
 * <p>This will create a grid of ASCII '1' to 'Z', then show a big
 * version of the character when it is clicked upon.  Also includes
 * a drop down of all the system fonts.  Also will be able to export
 * to a jpeg, or an ascii version.</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class FontInspector extends JPanel
	implements ActionListener,CharSetCanvasListener,
				MRJAboutHandler, FIConstants, MRJQuitHandler{
	
	/** if true, printout to System.out, otherwise go to specified port */
	public static boolean DEBUG = true;

	private BigCharCanvas charCanvas;
	private CharSetCanvas charsetCanvas;
	private JComboBox fontSelector;
	public String text;	//check this on return from a Dialog!
	
	private Frame parent;
	private String defaultFont = new String("Monospaced");

	public FontInspector(Frame f){
		this(f,true);
	}

	public FontInspector(Frame f, boolean showButtons){
		super();
		parent = f;
		//set up the combo box for choosing fonts
		fontSelector = FontSelectPanel.getFontComboBox(defaultFont);
		fontSelector.setBounds(20,20,300,35);
		fontSelector.addActionListener(this);
		//set up the save as ASCII button
		JButton saveAsA = new JButton("Save ASCII");
		saveAsA.setBounds(610,10,150,25);
		saveAsA.addActionListener(this);
		//set up the save as ASCII button
		JButton saveAsC = new JButton("Save Rotated ASCII");
		saveAsC.setBounds(610,40,150,25);
		saveAsC.addActionListener(this);
		//set up the save as image button
		JButton saveAs = new JButton("Save JPEG");
		saveAs.setBounds(455,10,150,25);
		saveAs.addActionListener(this);
		//set up the save as ASCII button
		JButton saveAsB = new JButton("Save Rotated JPEG");
		saveAsB.setBounds(455,40,150,25);
		saveAsB.addActionListener(this);
		//set up the panel for character drawing in a well
		charCanvas = new BigCharCanvas(defaultFont);
		JPanel charPanel = new JPanel();
		charPanel.add(charCanvas);
		JPanel charBorderPanel = ImageBorder.getOSXImageWellPanel(charPanel);
		charBorderPanel.setBounds(20,75,200,180);
		//set up the panel for the font characters
		charsetCanvas = new CharSetCanvas(defaultFont);
		charsetCanvas.addListener(this);
		JPanel charsetPanel = new JPanel();
		charsetPanel.add(charsetCanvas);
		JPanel charsetBorderPanel = ImageBorder.getOSXImageWellPanel(charsetPanel);
		charsetBorderPanel.setBounds(240,75,520,180);
		//set up this Panel's interface
		if(isMac) {
			MRJApplicationUtils.registerAboutHandler(this);
			MRJApplicationUtils.registerQuitHandler(this);
		}
		this.setLayout(null);
		this.add(fontSelector);
		if(showButtons){
			this.add(saveAs);
			this.add(saveAsA);
			this.add(saveAsB);
			this.add(saveAsC);
		}
		this.add(charBorderPanel);
		this.add(charsetBorderPanel);
		this.setPreferredSize( new Dimension(780,275) );
	}

	/** handle the drop down menu and the buttons */
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==fontSelector){
			charCanvas.setFontName(fontSelector.getSelectedItem().toString());
			charsetCanvas.setFontName(fontSelector.getSelectedItem().toString());
		} else if(e.getSource() instanceof JButton){
			String lbl = ((JButton)e.getSource()).getText();
			if( lbl.equals("Save JPEG") ) saveJPEG();
			else if( lbl.equals("Save Rotated JPEG") ) saveRotatedJPEG();
			else if( lbl.equals("Save ASCII") ) saveAscii();
			else if( lbl.equals("Save Rotated ASCII") ) saveRotatedAscii();
		}
	}

	public void saveJPEG(){
		File f = FileDialogs.showSaveAWT("Save as JPEG",
				charCanvas.getChar()+"","","jpg",parent);
		if(f!=null)
			if (! ImageUtilities.writeJPEG(charCanvas.getImage(),f,100))
				Alerts.showError("File Error",
								"Unable to save the image file!");
	}

	public void saveRotatedJPEG(){
		File f = FileDialogs.showSaveAWT("Save as JPEG",
				"rotated-"+charCanvas.getChar()+"","","jpg",parent);
		if(f!=null)
			if (! ImageUtilities.writeJPEG(charCanvas.getSidewaysImage(),f,100))
				Alerts.showError("File Error",
								"Unable to save the image file!");
	}
	
	public void saveAscii(){
		File f = FileDialogs.showSaveAWT("Save as ASCII Image",
				charCanvas.getChar()+"","","txt",parent);
		if(f!=null){
			try{
				FileWriter fw = new FileWriter(f);
				fw.write( getAscii() );
				fw.flush();
				fw.close();
			} catch (IOException ioe){
				Alerts.showError("File Error",
								"Unable to save the text file!");
			}
		}
	}

	public void saveRotatedAscii(){
		File f = FileDialogs.showSaveAWT("Save as ASCII Image",
				"rotated-"+charCanvas.getChar()+"","","txt",parent);
		if(f!=null){
			try{
				FileWriter fw = new FileWriter(f);
				fw.write( getRotatedAscii() );
				fw.flush();
				fw.close();
			} catch (IOException ioe){
				Alerts.showError("File Error",
								"Unable to save the text file!");
			}
		}
	}
	
	/** return an ascii-art version of the current char */
	public String getAscii(){
		return ImageUtilities.toAscii(charCanvas.getImage(),40);
	}

	/** return an ascii-art version of the current char */
	public String getRotatedAscii(){
		return ImageUtilities.toAscii(charCanvas.getSidewaysImage(),40);
	}
	
	/** when the user clicks on a char in the table, set it to show big */
	public void handleChar(char c){
		if(c!=' ') charCanvas.setChar(c);
	}

	/**
	 * popup a dialog, return a string of the ascii-art version of a big
	 * character
	 */
	public static String showAsciiDialog(Frame owner){
		final JDialog myDialog = new JDialog(owner,"Select a Character",true);
		final FontInspector myInspector = new FontInspector(owner,false);
		//set up the dialog buttons
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JButton okButton = new JButton("Insert");
		okButton.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent E){
				myInspector.text = myInspector.getAscii();
				myDialog.dispose();	//set the str and close it
			}
		});
		JButton ok2Button = new JButton("Insert Sideways");
		ok2Button.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent E){
				myInspector.text = myInspector.getRotatedAscii();
				myDialog.dispose();	//set the str and close it
			}
		});
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent E){
				myDialog.dispose();	//leave it as null and close
			}
		});
		buttonPanel.add(cancelButton);
		buttonPanel.add(ok2Button);
		buttonPanel.add(okButton);
		//finish and show the dialog...
		myDialog.getContentPane().setLayout(new BorderLayout());
		myDialog.getContentPane().add(myInspector,BorderLayout.CENTER);
		myDialog.getContentPane().add(buttonPanel,BorderLayout.SOUTH);
		myDialog.setSize( new Dimension(
			(int) myInspector.getPreferredSize().getWidth(),
			(int) myInspector.getPreferredSize().getHeight()+50
		));
		myDialog.setResizable(false);
		myDialog.show();
		//after they dismiss it, return the text (null or the str)
		return myInspector.text;
	}

	/**
	 * Handles the Max OSX About event - pops up the about box.
	 */
	public void handleAbout(){
		AboutDialog about = new AboutDialog(parent,APP_NAME,
			APP_VERSION,APP_HOMEPAGE,
			ImageUtilities.getImageIconFromResource(APP_ICON) );		
	}

	/**
	 * Handles the Max OSX Quit event - close the application.
	 */
	public void handleQuit(){
		System.exit(1);
	}

	/** print "hello world" to LPT1 */
	public static void main(String arg[]){
		JFrame myFrame = new JFrame(APP_NAME);
		myFrame.getContentPane().add( new FontInspector(myFrame) );
		GUIUtilities.setFrameSize(myFrame,780,275);
		Alerts.setParent(myFrame);
		myFrame.setResizable(false);
		myFrame.setVisible(true);
	}

}
