/*******************************************************************
  Rabbit code that lets you print to the Seiko SLP-100 address
  label printer.

	ToDo:
		- send a CMD_RESET when needed?
	
	2003.03.10 (rb)	removing global arrays for memory savings
	2003.03.09 (rb)	moved fonts to outside file
	2003.03.05 (rb)	test example works prefectly!  fixed serial
	2003.03.04 (rb) got rudimentary printing working with real one
	2003.03.02 (rb) got font working, added serial control
	2003.03.01 (rb) full thing compiles against virtual target,
					moved font into xmem
 ******************************************************************/

#memmap xmem

#ximport "fonts\Trebuchet MS-36.bytes" fontfile

/*******************************************************************
   SLP-100 Constants
 ******************************************************************/

/* define the printable area of a "Standard Address" label */
#define LABEL_X_MM      81                  /* label width (millimeters)    */
#define LABEL_Y_MM      24                  /* label height (millimeters)   */
#define LABEL_WIDTH     (LABEL_X_MM * 8)    /* label width (bits)           */
#define LABEL_HEIGHT    LABEL_Y_MM          /* label height (bytes)         */
#define MAX_ROWS        10                  /* max rows allowed             */
#define MAX_COLS        80                  /* max columns allowed          */

/* Printer status bit definitions */
#define STAT_PAPER_OUT   0x01
#define STAT_PAPER_JAM   0x02
#define STAT_HARD_ERR    0x04
#define STAT_COMM_ERR    0x08
#define STAT_IDLE        0x10
#define STAT_PLATEN_OPEN 0x20
#define STAT_ERROR       0x2F

/* Printer command definitions */
#define XON             0x11
#define XOFF            0x13
#define CMD_NOP         0x00           // No operation
#define CMD_STATUS      0x01           // Request printer status
#define CMD_VERSION     0x02           // Request firmware version
#define CMD_BAUDRATE    0x03           // Change baud rate to nn
#define CMD_PRINT       0x04           // Print literal (binary) data
#define CMD_PRINTRLE    0x05           // Print compressed (RLE) data
#define CMD_MARGIN      0x06           // Image offset (in mm from left edge)
#define CMD_TAB         0x09           // Tab nn dots to the right
#define CMD_LINEFEED    0x0A           // Feed label one line (one dot)
#define CMD_VERTTAB     0x0B           // Feed label nn lines (dots)
#define CMD_FORMFEED    0x0C           // Feed to top of next label
#define CMD_DENSITY     0x0E           // Set print density to nn
#define CMD_RESET       0x0F           // Reset printer
#define CMD_CHECK       0xA5           // Check for correct baud rate

/*******************************************************************
   SLP-100 Global Variables
 ******************************************************************/
unsigned char BitBuffer[LABEL_WIDTH][LABEL_HEIGHT];  /* bitmap buffer            */
int xPos, yPos;
int nLabelLines;
int nFontHeight;
/* for comm stuff */
unsigned char SLP_status;	//holds any status messages sent back
int stalled;
unsigned long fontfilePtr;

//sets up the character map table (CharTable)
int GetXMemOffset(char c){
	switch(c){
		case 32 : return 0;
		case 33 : return 57;
		case 34 : return 124;
		case 35 : return 186;
		case 36 : return 283;
		case 37 : return 380;
		case 38 : return 492;
		case 39 : return 619;
		case 40 : return 651;
		case 41 : return 718;
		case 42 : return 785;
		case 43 : return 852;
		case 44 : return 949;
		case 45 : return 1016;
		case 46 : return 1083;
		case 47 : return 1150;
		case 48 : return 1247;
		case 49 : return 1344;
		case 50 : return 1441;
		case 51 : return 1538;
		case 52 : return 1635;
		case 53 : return 1732;
		case 54 : return 1829;
		case 55 : return 1926;
		case 56 : return 2023;
		case 57 : return 2120;
		case 58 : return 2217;
		case 59 : return 2284;
		case 60 : return 2351;
		case 61 : return 2448;
		case 62 : return 2545;
		case 63 : return 2642;
		case 64 : return 2709;
		case 65 : return 2851;
		case 66 : return 2958;
		case 67 : return 3060;
		case 68 : return 3172;
		case 69 : return 3284;
		case 70 : return 3381;
		case 71 : return 3478;
		case 72 : return 3600;
		case 73 : return 3722;
		case 74 : return 3774;
		case 75 : return 3861;
		case 76 : return 3968;
		case 77 : return 4060;
		case 78 : return 4192;
		case 79 : return 4309;
		case 80 : return 4431;
		case 81 : return 4533;
		case 82 : return 4655;
		case 83 : return 4762;
		case 84 : return 4849;
		case 85 : return 4956;
		case 86 : return 5073;
		case 87 : return 5180;
		case 88 : return 5337;
		case 89 : return 5439;
		case 90 : return 5546;
		case 91 : return 5648;
		case 92 : return 5715;
		case 93 : return 5782;
		case 94 : return 5849;
		case 95 : return 5946;
		case 96 : return 6043;
		case 97 : return 6140;
		case 98 : return 6237;
		case 99 : return 6339;
		case 100 : return 6431;
		case 101 : return 6533;
		case 102 : return 6635;
		case 103 : return 6702;
		case 104 : return 6794;
		case 105 : return 6896;
		case 106 : return 6948;
		case 107 : return 7015;
		case 108 : return 7107;
		case 109 : return 7164;
		case 110 : return 7316;
		case 111 : return 7418;
		case 112 : return 7515;
		case 113 : return 7617;
		case 114 : return 7719;
		case 115 : return 7791;
		case 116 : return 7868;
		case 117 : return 7940;
		case 118 : return 8042;
		case 119 : return 8134;
		case 120 : return 8271;
		case 121 : return 8363;
		case 122 : return 8455;
		case 123 : return 8542;
		case 124 : return 8609;
		case 125 : return 8706;
		case 126 : return 8773;
		case 127 : return 8870;
	}
	return -1;
}

/*******************************************************************
   SLP Utility Functions
 ******************************************************************/
//do something intelligent with the error msg
void HandleError(char *msg){
	printf("\t\t -> Printer says : %s\n",msg);
}

void ParseReceived(unsigned char ch){	/* like CommISR */
	switch( ch & 0xC0 ){	/* bits 7:6 */
		//as we are using hardware flow control, do we need this?
		case 0x00:			/* handshaking */
			if(ch==XOFF){
				stalled = 1;
				HandleError("Xoff");
			} else if (ch==XON){
				stalled = 0;
				HandleError("Xon");
			}
			break;
		case 0x20:
			HandleError("Reserved");
			break;	/* reserved */
		case 0x40: 			/* status byte */
			SLP_status = ch;
			break;
		case 0x80:
			HandleError("Version Number");
			break;	/* version number */
		case 0xC0:
			HandleError("Random Message");
			/* acknowledge or other */
			break;
	}
}

//checks to see if any messages have come back from the printer
void CheckStatus(){
	unsigned char SLP_response[2];
	int count;
    int i;
    char status;
    const char *error_message[] =
        {
		"is out of Labels",				/* status bit 0 */
		"paper feed error",             /* status bit 1 */
		"hardware error",               /* status bit 2 */
		"communications error",         /* status bit 3 */
		"is idle",				        /* status bit 4 */
		"platen is open",         		/* status bit 5 */
		};
	//Check for msgs from the printer
	if(serDpeek()!=-1){
		count = serDread(&SLP_response,2,100);
		for(i=0;i<count;i++){
			//printf("\t\t\t\t -> *got msg - %x\n",SLP_response[0]);
			ParseReceived(SLP_response[i]);
		}
	}	
	status = SLP_status & STAT_ERROR;   /* look only at error bits  */
	if ( status == 0 ) return;          /* just return if no errors */
	for ( i=0; status != 0; ++i ){
		if ( status & 1 )
			HandleError(error_message[i]);
		status >>= 1;                   /* look at next bit */
	}
	SLP_status &= ~STAT_ERROR;          /* clear error bits */
}

/*******************************************************************
   SLP Font Functions
 ******************************************************************/

//grabs the bitmap for a particular char
void GetCharacterMap(char ch,unsigned char *pCharData){
	unsigned char char_info[2];
	int byte_count,i,j;
	//printf(" - Inside GetCharacterMap...");
	//return the char from external memory
	//first grab the height and width...
	xmem2root(char_info,fontfilePtr+GetXMemOffset(ch),sizeof(char_info));
	byte_count = char_info[0]*char_info[1]/8+2; //the byte count is height/8*width+2
	//printf(" char %d, got height=%d width=%d = %d bytes\n",ch,char_info[0],char_info[1],byte_count);
	xmem2root(pCharData,fontfilePtr+GetXMemOffset(ch),sizeof(unsigned char)*byte_count);
	//printf("                                      real height=%d width=%d\n",*pCharData,*(pCharData+1));
	/*for(j=0;j<char_info[1];j++){
		for(i=0;i<char_info[0]/8;i++){
			printf("%02x ",*(pCharData+2+i+j*8));
		}
		printf("\n");
	}*/
}

//sets up the font size information
void InitFont(void){
	char char_info[2];
	fontfilePtr = fontfile+4;
	//printf("inside InitFont... ");
	/* look at ASCII SPACE ' ' record to determine the  */
	/* default height for the font                      */
	xmem2root(char_info,fontfilePtr,sizeof(char_info));
	nFontHeight = char_info[0];                   /* 1st byte is height       */
	nFontHeight = (nFontHeight + 7) / 8;        /* convert height to bytes  */
	nLabelLines = LABEL_HEIGHT / nFontHeight;   /* calc max number of lines */
	printf(" (%d,%d) nFontHeight=%d nLabelLines=%d\n",char_info[0],char_info[1],nFontHeight,nLabelLines);
}

/*******************************************************************
   SLP Serial Functions
 ******************************************************************/
#define DINBUFSIZE		31		//default 31
#define DOUTBUFSIZE		31		//default 31
#define SERD_RTS_PORT	PCDR
#define SERD_RTS_SHADOW	PCDRShadow
#define SERD_RTS_BIT	2		//PC2 default
#define SERD_CTS_PORT	PCDR
#define SERD_CTS_BIT	3		//PC3 default

//smart sending of the character
void Send(unsigned char ch){
	int timeout,i;
	timeout = 10000;
	CheckStatus();
	while(stalled){
		CheckStatus();
		if( --timeout == 0){
			HandleError("Timeout - Printer Buffer is full!");
			exit(1);
		}
		for(i=0;i<100;i++);
	}
	//send it to the printer...
	serDputc(ch);
}

/* 57600 N81, flow control on */
void OpenCommPort(void){
	serDopen(57600);
	serDparity(PARAM_NOPARITY);
	serDdatabits(PARAM_8BIT);
	//serDflowcontrolOn();
}

/* appears to be unnecessary for us */
/*void CloseCommPort(void){
	serDclose();
}*/

/*******************************************************************
   SLP Bitmap Functions
 ******************************************************************/
//empties the bitmap buffer
void ClearBitmapBuffer(void){
	//printf(" - Inside ClearBitmapBuffer...\n");
	memset(BitBuffer,0x00,sizeof(BitBuffer));
	//setmem(BitBuffer, sizeof(BitBuffer), 0);
}


//draws a char from the fontmap @ (xPos,yPos)
int DrawBitmap(char ch){
	unsigned char char_bitmap[5*40+2];	//holds data retrieved from xmem
	unsigned char *pCharData;
	int width, height;
	int w, x, y;
	//printf(" - Inside DrawBitmap...\n");
	//pCharData = (BYTE *) CharTable[ch];
	GetCharacterMap(ch,char_bitmap);
	pCharData = char_bitmap;
	height = (int) *pCharData++;
	width = (int) *pCharData++;
	//printf("       char %d, got height=%d width=%d\n",ch,height,width);
	height = (height + 7) / 8;              /* convert height to bytes */
	if ( width == 0 ){                       /* return if invalid char */
		//printf(" ** DrawBitmap(%d) - width=0)!\n",ch);
		return FALSE;
	}
	if ( xPos + width > LABEL_WIDTH ){       /* return if too wide */
		//printf(" ** DrawBitmap(%d) - too wide)!\n",ch);
		return FALSE;
	}
	if ( yPos + height > LABEL_HEIGHT ){     /* return if too tall */
		//printf(" ** DrawBitmap(%d) - %d + %d > %d)!\n",ch,yPos,height,LABEL_HEIGHT);
		return FALSE;
	}
	if ( ch != 32 ){                         /* don't bitmap spaces */
		/* set absolute limits */
		height += yPos;
		w = width + xPos;
		/* copy the character data to the bitmap buffer */
		for ( x = xPos; x < w; ++x )
			for ( y = yPos; y < height; ++y )
				BitBuffer[x][y] = *pCharData++;
		}
	xPos += width;                          /* update current position */
	return TRUE;                            /* success! */
}

//converts an EditBuffer string label into a BitmapBuffer for printing
void Convert(char *EditBuffer){
	unsigned char row, col, ch;
	//printf(" - Inside Convert...\n");
	ClearBitmapBuffer();                /* clear out any junk */
	yPos = 0;                           /* start at the top */
	for (row=0; row<nLabelLines; ++row){/* process all rows */
		//printf("  row = %d (%s)",row,EditBuffer[row]);
		xPos = 0;                       /* left side of character */
		col = 0;                        /* start with 1st character */
		while ( (ch = EditBuffer[(row*MAX_COLS)+(col++)]) != 0 ){
			if ( !DrawBitmap(ch) )      /* add to bitmap buffer */
				break;                  /* break if off the label */
		}
		yPos += nFontHeight;            /* start next line */
	}
}

/*******************************************************************
   SLP Printing Functions
 ******************************************************************/

//send BitmapBuffer to the printer
void Print(void){
	int i, count;
	int x, y;
	unsigned char linebuf[LABEL_HEIGHT];

	Send(CMD_DENSITY);      /* send density prefix          */
	Send(0x80);             /* set "normal" density         */
	Send(CMD_MARGIN);       /* set left margin              */
	Send(0);            /* 0mm for standard size label on narrow printer */
	//printf("Margin set for 'narrow' printer.\n");
	printf("Printing...\n");
	for ( x = 0; x < LABEL_WIDTH; ++x ){
		/* copy data to local buffer and count printable bytes      */
		i = 0;
		count = 0;
		for ( y = LABEL_HEIGHT-1; y >= 0; --y ){
			if ( (linebuf[i++] = BitBuffer[x][y]) != 0 )
				count = i;
		}
		if ( count == 0 ){              /* any printable data?      */
			Send(CMD_LINEFEED);         /* no, just send line feed  */
		} else {
			Send(CMD_PRINT);            /* send print command       */
			Send(count);                /* send record size         */
			for ( i = 0; i < count; ++i )
				Send(linebuf[i]);       /* send data to the printer */
		}
		for ( i = 0; i < 1000; i++ );
	}
	//Send(CMD_FORMFEED);                 /* advance label            */
	printf(" done.\n");
}

/* print an example label... */
void TextLabel(void){
	char EditBuffer[MAX_ROWS*MAX_COLS];        /* editor buffer            */
	strcpy(&EditBuffer[MAX_COLS*0], "abc");
	strcpy(&EditBuffer[MAX_COLS*1], "bcd");
	strcpy(&EditBuffer[MAX_COLS*2], "cde");
	//strcpy(EditBuffer[0], "Smart Label Printer");
	//strcpy(EditBuffer[1], "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	//strcpy(EditBuffer[2], "abcdefghijklmnopqrstuvwxyz");
	Convert(EditBuffer);      /* convert to bitmap buffer */
	Print();        /* print the label          */
}

/*******************************************************************
   Program Code
 ******************************************************************/
void InitPorts(void){
	OpenCommPort();
}

void main(void) {
	unsigned char SLP_response[1];
	unsigned char bitmap[30];
	int i,j;

	for(i=0;i<30;i++) bitmap[i] = 0x0F;

	/* globals initialization */
	SLP_status = 0;
	stalled = 0;

	printf("Starting Program...\n");
	/* initializations */
	InitPorts();
	InitFont();

	/* run a simple test program */
	while(1){
		costate{
			//press S3 on the eval board
			if (BitRdPortI(PBDR, 3)==0){
				while(BitRdPortI(PBDR, 3)==0);	//debounce
				//printf("sending...");
				TextLabel();
				//serDputc('t');
				//printf("done\n");
			}
			//press S2 on the eval board
			if (BitRdPortI(PBDR, 2)==0){
				while(BitRdPortI(PBDR, 2)==0);	//debounce
				serDputc(CMD_LINEFEED);
			}
		}

		costate{
			if(serDpeek()!=-1){
				CheckStatus();
			}
		}

	}

}
