package org.instituteofthefuture.comstats;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import org.instituteofthefuture.gui.GUIUtilities;
import org.instituteofthefuture.gui.Alerts;

/**
 * <p>Pops up while reading log data.
 *	Stores any errors into the errors string, null is success.</p>
 *  <ul>
 *	<li>2002.12.23 - modigied from jackal.gui.downloadDialog
 *	</ul>
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class RunningDialog extends JDialog {
	protected String errors = null;
	public static JTextArea messages;

	public RunningDialog(JFrame frame,AbstractManager manager) {
		super(frame, true);
		//System.out.println("started! - "+manager.getName());
		this.setTitle("Loading Data");
		JLabel head = new JLabel("Reading "+manager.getName()+"...",JLabel.CENTER);
		head.setFont(new Font("SansSerif",Font.PLAIN,24));
		messages = new JTextArea("Reading "+manager.getName()+"...\n");
		messages.setFont( new Font("Geneva",Font.PLAIN,9) );
		JScrollPane jsp = new JScrollPane(messages);
		//finish making the panel
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(head,BorderLayout.NORTH);
		this.getContentPane().add(jsp,BorderLayout.CENTER);
		//this.getContentPane().add(notes);
		this.setSize(300,200);
		setResizable(false);
		RunningThread readThread= new RunningThread(manager);
		readThread.start();
		this.show();
	}

	class RunningThread extends Thread {
		AbstractManager myManager;
		
		RunningThread(AbstractManager m){
			this.myManager = m;
		}
	
		public void run(){
			try{
				myManager.readData();
			} catch (Exception e){
				errors = e.toString();
			}
			try{
				this.sleep(100);
			} catch (Exception e){
				e.printStackTrace();
			}
			dispose();
		}
	}
	
	public void throwErrors(){
		if(errors!=null)
			throw new RuntimeException(errors);
	}
	
	static public void append(String msg){
		if(messages!=null)
			messages.setText(msg+"\n"+messages.getText());
	}

}
