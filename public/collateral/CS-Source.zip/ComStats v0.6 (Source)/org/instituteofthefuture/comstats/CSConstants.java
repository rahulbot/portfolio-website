package org.instituteofthefuture.comstats;

import org.instituteofthefuture.IFConstants;

/**
 * <p>A bunch of useful constants for the ComStats project.</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public interface CSConstants extends IFConstants{

	/** the name of the icon file inside the jar */
	public static String ICON_FILE = "ChartIcon2.gif";
	
	/** the project name */
	public static String APP_NAME = "ComStats";

	/** the project homepage */
	public static String HOMEPAGE = 
		new String("http://www.instituteofthefuture.org/comstats/");

	/** the project version */
	public static String VERSION = "0.6";

	/** the prefs filename */
	public static String PREFS_FILE = APP_NAME+".properties";

}
