package org.instituteofthefuture.comstats;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.apple.mrj.*;

import org.instituteofthefuture.IFConstants;
import org.instituteofthefuture.gui.AboutDialog;

/** 
 * The menu bar for ComStats.  Most of the actions are executed
 * from here.  It also has hooks for better Mac OSX - like behaviour.
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class CSMenuBar extends JMenuBar 
		implements ActionListener, CSConstants,
			MRJAboutHandler, MRJQuitHandler, MRJPrefsHandler {

	/** the ComStats to operate one */
	private ComStatsFrame parent;

	/**
	 * Make the menu bar.
	 */
	public CSMenuBar(ComStatsFrame p){
		super();
		parent = p;
		registerMRJHandlers();
		addCommonMenus();
	}

	/**
	 * Register the About and Quit handlers to be this class.
	 */
	private void registerMRJHandlers(){
		MRJApplicationUtils.registerAboutHandler(this);
		MRJApplicationUtils.registerQuitHandler(this);
		MRJApplicationUtils.registerPrefsHandler(this);
	}
	
	/**
	 * Add the platform-specific File menu.
	 */
	private void addCommonMenus(){
		this.add( buildSimpleMenu("File",
			new String[]{"Save Graph As...","Print Graph..."}, new char[]{'S','P'} ) );
		this.add( buildSimpleMenu("Stats",
			new String[]{"Refresh Data","Redraw Graph"}, new char[]{'D','R'} ) );
		String digits = new String("123456789");
		JMenu jm = new JMenu("Window");
		String[] names = parent.getPanelNames();
		for(int i=0;i<names.length;i++){
			JMenuItem j = new JMenuItem(names[i]);
			j.setAccelerator( KeyStroke.getKeyStroke(digits.charAt(i),OS_KEY_MASK) );
			j.addActionListener(this);
			jm.add(j);
		}
		jm.addSeparator();
		JMenuItem j = new JMenuItem("Postcardware");
		j.addActionListener(this);
		jm.add(j);
		this.add(jm);
	}

	private JMenu buildSimpleMenu(String menuName,String[] items,char[] shortcuts){
		return buildMenu(menuName,false,items,shortcuts,"","");
	}

	/**
	 * A lower-level utility to build the menus.
	 *	@param menuName	the name of the menu
	 *	@param 	group	true if you want the items to be a mutex, false otherwise
	 *	@param 	items	a string array of the items to go in this menu
	 *	@param 	shortcuts	the key to use as a shortcut for each item in the items array
	 *	@param	def		the default option to select, if group is true
	 *	@return	the menu that was created out of these items
	 */
	private JMenu buildMenu( String menuName, boolean group, String[] items, char[] shortcuts, String post, String def ){
		JMenu jm = new JMenu(menuName);
		ButtonGroup myButGrp = new ButtonGroup();
		for(int i=0;i<items.length;i++){
			if(items[i].equals("-")){
				jm.addSeparator();
			} else {
				JMenuItem j = new JMenuItem();
				if(group){
					j = new JRadioButtonMenuItem(items[i]+post);
					myButGrp.add(j);
					if( j.getText().indexOf(def) != -1 )
						j.setSelected(true);
				} else j = new JMenuItem(items[i]+post);
				if( shortcuts!=null )
					if(shortcuts[i]!=' ')
						j.setAccelerator( KeyStroke.getKeyStroke(shortcuts[i],OS_KEY_MASK) );
				j.addActionListener(this);
				jm.add(j);
			}
		}
		return jm;
	}

/******************************************************************************
 **		EVENT HANDLERS
 ******************************************************************************/

	/**
	 * Handles the edit buttons and the popupmenu items
	 */
	public void actionPerformed(ActionEvent e){
		Object o = e.getSource();
		//System.out.println("object = "+o);
		if(o instanceof JMenuItem){
			JMenuItem j = (JMenuItem) o;
			String s = j.getText();
			if ( s.equals("Save Graph As...")){
				parent.saveAs();
			} else if ( s.equals("Print Graph...")){
				parent.print();
			} else if ( s.equals("Refresh Data")){
				parent.refreshData();
			} else if ( s.equals("Redraw Graph")){
				parent.refreshPlot();
			} else if ( s.equals("Postcardware")){
				AboutDialog.showPostcardware(parent);
			} else {
				parent.showPanelNamed( ((JMenuItem)o).getText() );
			}
		}
	}
	
	/**
	 * Handles the Max OSX Quit event - close the application.
	 */
	public void handleQuit(){
		parent.exit();
	}
	/**
	 * Handles the Max OSX Preferences event - nothing for now.
	 */
	public void handlePrefs(){
		parent.showPrefs();
	}
	/**
	 * Handles the Max OSX About event - pops up the about box.
	 */
	public void handleAbout(){
		parent.showAbout();
	}

}
