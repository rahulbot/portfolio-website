package org.instituteofthefuture.comstats;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import org.instituteofthefuture.gui.CheckBoxPanel;
import org.instituteofthefuture.gui.GUIUtilities;
import org.instituteofthefuture.gui.DimensionPanel;
import org.instituteofthefuture.gui.Alerts;

/**
 * <p>Sets the preferences for ComStats.  This should have one
 * bordered panel per application stats it can view.</p>
 *  <ul>
 *	<li>2002.12.26 - added draw data points option
 *	<li>2002.12.23 - created
 *	</ul>
 * @author Copyright (c) 2003, Rahul Bhargava.  All rights reserved.
 */
public class PrefsDialog extends JDialog
	implements ActionListener {

	/** a panel for each StatsPanel */
	private AbstractPrefsPanel[] prefPanels;
	/** the tabs */
	private JTabbedPane tabs;

	ComStatsFrame parent;

	public PrefsDialog(ComStatsFrame cs) {
		super(cs, true);
		parent = cs;
		this.setTitle("ComStats Preferences");
		addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent event) {
					if (event.getKeyCode() == KeyEvent.VK_ESCAPE)
						closePreferences(false);
				}
			});
		prefPanels = new AbstractPrefsPanel[parent.panels.length+1];
		tabs = new JTabbedPane();
		//make the selectors
		prefPanels[0] = parent.getPrefPanel();
		tabs.addTab(prefPanels[0].getName(),prefPanels[0]);
		for(int i=0;i<parent.panels.length;i++){
			prefPanels[i+1]=parent.panels[i].getPrefsPanel();
			if(prefPanels[i+1]!=null)
				tabs.addTab(prefPanels[i+1].getName(),prefPanels[i+1]);
		}
		//make the button panel
		JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JButton saveButton = new JButton("OK");
		saveButton.addActionListener(this);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		buttonPanel.add(cancelButton);
		buttonPanel.add(saveButton);
		//finish making the panel
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(tabs,BorderLayout.CENTER);
		this.getContentPane().add(buttonPanel,BorderLayout.SOUTH);
		this.setSize(610,450);
		setResizable(false);
	}

	/**
	 * Handle the buttons.
	 */
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if (command == "OK") {
			closePreferences(true);
		}
		if (command == "Cancel") {
			closePreferences(false);
		}
	}

	/**
	 * This actually set the serial port of the brickManager,
	 * and the language for next time, invoked on exit.
	 *	@param	ok	if true then set the port, otherwise ignore it
	 */
	public void closePreferences(boolean ok) {
		if(ok) {
			//System.out.println("PrefsDialog : OK...");
			try{
				//this will throw any errors in format
				for(int i=0;i<prefPanels.length;i++)
					prefPanels[i].checkValid();
			} catch (Exception e){
				Alerts.showError("Error",e.toString());
				return;
			}
			for(int i=0;i<prefPanels.length;i++)
				prefPanels[i].store();
/*			if(!dimPanel.isValid()){
				Alerts.showError("Bad Number","Invalid Number Entered");
				return;
			}
			Dimension dim = dimPanel.getDimension();
			CSPreferences.setSaveHeight(dim.height);
			CSPreferences.setSaveWidth(dim.width);
			boolean[] mailState = mailPanel.getOptionStates();
			CSPreferences.setMailCountDeleted(mailState[0]);
			CSPreferences.setMailCountSent(mailState[1]);
			CSPreferences.setMailCountQuoted(mailState[2]);
			boolean [] drawState = drawPanel.getOptionStates();
			CSPreferences.setDrawDataPoints(drawState[0]);
*/		}
		dispose();
	}

}

