package org.instituteofthefuture;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
import java.awt.print.*;

import org.instituteofthefuture.gui.Alerts;

/**
 * <p>This class holds a few static methods that make it easier to deal with
 * printing.</p>
 *
 * <p>
 * This code is thanks to 
 * <a http="http://www.apl.jhu.edu/~hall/java/Swing-Tutorial/Swing-Tutorial-Printing.html">
 * http://www.apl.jhu.edu/~hall/java/Swing-Tutorial/Swing-Tutorial-Printing.html</a>
 * </p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class PrintUtilities implements Printable {

	/** use this to resize the component that needs printing */
  public static Dimension COMPONENT_PRINTING_SIZE = new Dimension (550,100000);

	/** the component that will be printed */
  private Component componentToBePrinted;

	/**
	* Print the component.
	*	@param	c	the component to print
	*/
  public static void printComponent(Component c) {
    new PrintUtilities(c).print();
  }
 
	/**
	* A constructor that doesn't print immediately
	*	@param	c	the component to print
	*/
  public PrintUtilities(Component componentToBePrinted) {
    this.componentToBePrinted = componentToBePrinted;
  }
 
	/**
	* Print the component previously set
	*/
  public void print() {
    PrinterJob printJob = PrinterJob.getPrinterJob();
    printJob.setPrintable(this);
    if (printJob.printDialog())
      try {
        printJob.print();
      } catch(PrinterException pe) {
        //System.out.println("Error printing: " + pe);
        Alerts.showError("Error While Printing","Sorry, some kind of printing error occurred.");
      }
  }

	/**
	* A lower-level print function, overrinding Printable, don't use this
	*	@param	g	the graphics to print
	*	@param	pageFormat	the way to print it
	*	@param	pageIndex	the page to print
	*/
  public int print(Graphics g, PageFormat pageFormat, int pageIndex) {
    if (pageIndex > 0) {
      return(NO_SUCH_PAGE);
    } else {
      Graphics2D g2d = (Graphics2D)g;
	  //System.out.println("width = "+pageFormat.getWidth()+" x="+pageFormat.getImageableX()+" y="+pageFormat.getImageableY());
      g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
	  //g2d.transform(new AffineTransform(pageFormat.getMatrix()));
      disableDoubleBuffering(componentToBePrinted);
      componentToBePrinted.paint(g2d);
      enableDoubleBuffering(componentToBePrinted);
      return(PAGE_EXISTS);
    }
	//return NO_SUCH_PAGE;
  }

	/**
	* Turn off double buffering
	*	@param	c	the Component to do it to
	*/
  public static void disableDoubleBuffering(Component c) {
    RepaintManager currentManager = RepaintManager.currentManager(c);
    currentManager.setDoubleBufferingEnabled(false);
  }

	/**
	* Turn on double buffering
	*	@param	c	the Component to do it to
	*/
  public static void enableDoubleBuffering(Component c) {
    RepaintManager currentManager = RepaintManager.currentManager(c);
    currentManager.setDoubleBufferingEnabled(true);
  }

}