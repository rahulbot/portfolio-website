package org.instituteofthefuture.io;

import java.io.*;

/**
 * <p>utility to only show images in an open dialog</p>
 * 
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class ImageFilenameFilter implements FilenameFilter {
    
    /**
     * Accept all directories and all gif, jpg, or tiff files.
     */
    public boolean accept(File dir,String name) {
        String extension = FileUtilities.getExtension(name);
        if (extension != null) {
            if (extension.equals(FileUtilities.EXTENSION_JPEG) ||
                extension.equals(FileUtilities.EXTENSION_JPG) ||
                extension.equals(FileUtilities.EXTENSION_GIF) ||
                extension.equals(FileUtilities.EXTENSION_TIFF) ||
                extension.equals(FileUtilities.EXTENSION_TIF)) {
                    return true;
            } else {
                return false;
            }
        }

        return false;
    }

}
