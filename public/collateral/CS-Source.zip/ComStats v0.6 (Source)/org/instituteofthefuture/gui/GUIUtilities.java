package org.instituteofthefuture.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.text.*;
import java.text.*;
import java.lang.reflect.*;
import java.util.*;

import org.instituteofthefuture.IFConstants;

/**
 * <p>This class holds a few static methods that make it easier to deal with
 * random common GUI tasks.</p>
 *
 *	<ul>
 *	<li>2002.11.27 - fixed setFrameSize for Mac Classic support
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class GUIUtilities implements IFConstants {

	/**
	* Set all the swing interface items to look like the platform they are on.
	*/
	static public void setNativeLookAndFeel() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch(Exception e) {
			System.out.println("Error setting native LAF: " + e);
		}
	}
	
	/**
	* Make the JTextArea act more like a multi-line label
	*/
	static public void stylizeAsLabel(JTextArea jta){
		jta.setFont( new Font("SansSerif",Font.PLAIN,10) );
		jta.setWrapStyleWord(true);
		jta.setEditable(false);
		jta.setOpaque(false);
		jta.setHighlighter(null);
		jta.setBorder( new JLabel().getBorder() );
	}

	/**
	* Make all the cells in a table editable or non-editable.  Got this from:
	* http://forum.java.sun.com/thread.jsp?forum=57&thread=300362
	*	@param	editable	true or false - duh!
	*/
	static public void setCellEditable(JTable tbl, boolean editable){
		JTextField column1TF=new JTextField();
		column1TF.setFont(tbl.getFont());
		column1TF.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder"));
		if (editable)
			column1TF.setEditable(true);
		else
			column1TF.setEditable(false);
		TableCellEditor ce=new DefaultCellEditor(column1TF);
		for (int i=0; i<tbl.getColumnCount(); i++)
			tbl.getColumnModel().getColumn(i).setCellEditor(ce);
	}

	/**
	* A system-independant way to set the size of a JFrame, because
	* on Mac OSX the menu bar isn't in the window if you do things
	* right!
	*	@param	frame	the frame to size up
	*	@param	d		the width and height of the contentPanel
	*/
	static public void setFrameSize(JFrame frame, Dimension d){
		setFrameSize(frame,d.width,d.height);
	}

	/**
	* A system-independant way to set the size of a JFrame, because
	* on Mac OSX the menu bar isn't in the window if you do things
	* right!
	*	@param	frame	the frame to size up
	*	@param	width	the contentPanel width
	*	@param	height	the contentPanel height
	*/
	static public void setFrameSize(JFrame frame, int width, int height){
        int winHeight = height;
        int winWidth = width;
        if(isMac){
        	winHeight += 22;	//the OSX window title bar
        } else {
        	winHeight += 47;
        }
        frame.setSize(new Dimension(winWidth,winHeight));
	}

	/**
	* A system-independant way to set the size of a JDialog
	*	@param	dialog	the dialog to size up
	*	@param	width	the contentPanel width
	*	@param	height	the contentPanel height
	*/
	static public void setDialogSize(JDialog dialog, int width, int height){
        int winHeight = height+22;
        int winWidth = width;
        dialog.setSize(new Dimension(winWidth,winHeight));
	}

	/**
	 * On OSX, if the person has spellchecking installed, this will
	 * underline any misspelled words in the JTextArea!
	 *
	 *	@param	jtc		the component to spell check
	 *	@return			true if found the class, false otherwise
	 */
	static public boolean markMisspelledWords(JTextComponent jtc){
		return invokeSpellCheckMethod(jtc,"markMisspelledWords");
	}


	/**
	 * On OSX, if the person has spellchecking installed, this will
	 * start up a spell-check dialog box to check them all! Copied from
	 * com.apple.spell.examples.ExampleContent.
	 *
	 *	@param	jtc		the component to spell check
	 *	@return			true if found the class, false otherwise
	 */
	static public boolean checkSpelling(JTextComponent jtc){
		return invokeSpellCheckMethod(jtc,"checkSpelling");
	}

	/** 
	 * Start a spell-checking method on OSX.  Copied from the file -
	 * com.apple.spell.examples.ExampleContent.  The user must be on
	 * OSX and have installed the "JavaSpellingFramework.pkg"
	 * to use this.  It pops up a friendly error if unable to locate
	 * the com.apple.spell library.  Uses reflection to do it safely.
	 * 
	 *	@param	jtc			the component to spell check
	 *	@param	methodName	the name of the method of start
	 *	@return	true if found the class, false otherwise
	 */
	private static boolean invokeSpellCheckMethod(JTextComponent jtc,String methodName){
		try {
			Class driverClass = java.lang.Class.forName(
				"com.apple.spell.ui.JTextComponentDriver");
			Object driver = driverClass.newInstance();
			Method checkMethod = driverClass.getMethod(methodName,
			new Class[]{javax.swing.text.JTextComponent.class});
			checkMethod.invoke(driver, new Object[]{jtc});
			return true;
		} catch (Throwable t) {
			if(isMacOSX)
				Alerts.showError("Spell Check Not Installed",
					"The spell-checker could not be located.  You should have\n"+
					"received a file called \"JavaSpellingFramework.pkg\" with\n"+
					"this program.  Please install that package and then try\n"+
					"this again."
				);
			else
				Alerts.showError("Spell Check Not Available",
					"Sorry, spell check is only available on Apple's Mac OSX\n"+
					"operating system."
				);
		}
		return false;
	}
	
	/**
	 * Get a drop-down of years
	 *	@return	a list of years from 1998 to next year, preselected
	 *			to this year
	 */
	static public JComboBox getYearComboBox(){
		JComboBox jcbDate = new JComboBox();
		int year = Calendar.getInstance().get(Calendar.YEAR);
		for(int y=1998;y<year+2;y++)
			jcbDate.addItem(y+"");
		jcbDate.setSelectedIndex(year-1998);
		return jcbDate;
	}

	/**
	 * Get a drop-down of months
	 *	@return	a list of months from January to December, preselected
	 *			to the current month
	 */
	static public JComboBox getMonthComboBox(){
		JComboBox jcbDate = new JComboBox();
		jcbDate.addItem("January");
		jcbDate.addItem("February");
		jcbDate.addItem("March");
		jcbDate.addItem("April");
		jcbDate.addItem("May");
		jcbDate.addItem("June");
		jcbDate.addItem("July");
		jcbDate.addItem("August");
		jcbDate.addItem("September");
		jcbDate.addItem("October");
		jcbDate.addItem("November");
		jcbDate.addItem("December");
		int month = Calendar.getInstance().get(Calendar.MONTH);
		jcbDate.setSelectedIndex(month);
		return jcbDate;
	}

	/**
	 * Get a drop-down of days
	 *	@return	a list of days from 1 to 31, preselected
	 *			to the current day-in-month
	 */
	static public JComboBox getDayComboBox(){
		JComboBox jcbDate = new JComboBox();
		for(int d=1;d<32;d++){
			jcbDate.addItem(d+"");
		}
		int day = Calendar.getInstance().get(Calendar.DATE);
		jcbDate.setSelectedIndex(day-1);
		return jcbDate;
	}

	/**
	 * format a double for xx.xx printing
	 *	@return	a string of the data
	 */
	static public String formatDecimal(double d){
		DecimalFormat formatter = new DecimalFormat("00000000.00");
		StringBuffer sb = new StringBuffer();
		formatter.format(d,sb,new FieldPosition(NumberFormat.FRACTION_FIELD));
		String s = sb.toString();
		int start = 0;
		for(int i=0;i<s.length();i++){
			if(s.charAt(i)!='0'){
				start = i;
				break;
			}
		}
		String fixed = sb.toString().substring(start);
		if(fixed.startsWith(".")) fixed = "0"+fixed;
		return fixed;
	}

}
