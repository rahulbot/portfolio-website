package org.instituteofthefuture.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;


/**
 * <p>A transparent JButton.</p>
 *
 * <p>
 * thanks to <a href="http://www.apl.jhu.edu/~hall/java/Java2D-Tutorial.html">
 * http://www.apl.jhu.edu/~hall/java/Java2D-Tutorial.html</a>
 * </p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class AlphaJButton extends JButton {

	/** The alpha to use when painting */
	AlphaComposite myAlpha;
	
	/**
	* Main constructor
	*	@param	s		the text on the button
	*	@param	opacity	the opacity, a float between 0.0 and 1.0
	*/
	public AlphaJButton(String s,float opacity){
		super(s);
		 myAlpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER,opacity);
	}

	/**
	* Override it to paint the button with the opacity specified
	*	@param	g		the graphics
	*/
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setComposite(myAlpha);
		Rectangle r = new Rectangle(2,2,this.getWidth(),this.getHeight());
		//g2d.setPaint(Color.blue);
		g2d.fill(r);
	}

}