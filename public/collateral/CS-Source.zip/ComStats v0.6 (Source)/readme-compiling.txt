
ComStats Source Code v0.6 (2003.04.18)

--------
BUILDING
--------

The source code is out there under the BSD license, but it isn't
really build-able in this form.  Sorry.  Email me if you really
do want to compile it yourself.

However, I do use ComStats uses ant to compile.  Ant is a fantastic
open-source cross-platform build tool created by the Apache group.

There is a little tutorial about how to set ant up at:
  http://builder.com.com/article.jhtml?id=r00120020206jam01.htm
and you can find a reference for it at:
  http://jakarta.apache.org/ant/manual/index.html
