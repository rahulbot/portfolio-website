package org.instituteofthefuture.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

import org.instituteofthefuture.IFConstants;

/**
 * <p>This class holds a few static methods that make it easier to deal with
 * random common GUI tasks.</p>
 *
 *	<ul>
 *	<li>2002.11.27 - fixed setFrameSize for Mac Classic support
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class GUIUtilities implements IFConstants {

	/**
	* Set all the swing interface items to look like the platform they are on.
	*/
	public static void setNativeLookAndFeel() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch(Exception e) {
			System.out.println("Error setting native LAF: " + e);
		}
	}
	
	/**
	* Make the JTextArea act more like a multi-line label
	*/
	public static void stylizeAsLabel(JTextArea jta){
		jta.setFont( new Font("SansSerif",Font.PLAIN,10) );
		jta.setWrapStyleWord(true);
		jta.setEditable(false);
		jta.setOpaque(false);
		jta.setHighlighter(null);
		jta.setBorder( new JLabel().getBorder() );
	}

	/**
	* Make all the cells in a table editable or non-editable.  Got this from:
	* http://forum.java.sun.com/thread.jsp?forum=57&thread=300362
	*	@param	editable	true or false - duh!
	*/
	public static void setCellEditable(JTable tbl, boolean editable){
		JTextField column1TF=new JTextField();
		column1TF.setFont(tbl.getFont());
		column1TF.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder"));
		if (editable)
			column1TF.setEditable(true);
		else
			column1TF.setEditable(false);
		TableCellEditor ce=new DefaultCellEditor(column1TF);
		for (int i=0; i<tbl.getColumnCount(); i++)
			tbl.getColumnModel().getColumn(i).setCellEditor(ce);
	}

	/**
	* A system-independant way to set the size of a JFrame, because
	* on Mac OSX the menu bar isn't in the window if you do things
	* right!
	*	@param	frame	the frame to size up
	*	@param	d		the width and height of the contentPanel
	*/
	public static void setFrameSize(JFrame frame, Dimension d){
		setFrameSize(frame,d.width,d.height);
	}

	/**
	* A system-independant way to set the size of a JFrame, because
	* on Mac OSX the menu bar isn't in the window if you do things
	* right!
	*	@param	frame	the frame to size up
	*	@param	width	the contentPanel width
	*	@param	height	the contentPanel height
	*/
	public static void setFrameSize(JFrame frame, int width, int height){
        int winHeight = height;
        int winWidth = width;
        if(isMac){
        	winHeight += 22;	//the OSX window title bar
        } else {
        	winHeight += 47;
        }
        frame.setSize(new Dimension(winWidth,winHeight));
	}

	/**
	* A system-independant way to set the size of a JDialog
	*	@param	dialog	the dialog to size up
	*	@param	width	the contentPanel width
	*	@param	height	the contentPanel height
	*/
	public static void setDialogSize(JDialog dialog, int width, int height){
        int winHeight = height+22;
        int winWidth = width;
        dialog.setSize(new Dimension(winWidth,winHeight));
	}

}
