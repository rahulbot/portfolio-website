package org.instituteofthefuture.gui;

import javax.swing.*;
import java.awt.*;
import java.io.*;

import org.instituteofthefuture.io.*;

/**
 * <p>This class holds a few static methods that make it easier to deal with
 * File Dialogs.  Use the AWT functions for a more native look on any
 * platform.</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class FileDialogs {

/******************************************************************************
 **		Open
 ******************************************************************************/

	/**
	* Show an open dialog box with AWT classes.
	*	@param	title	the title of the window that pops up
	*	@param	defaultFile	the name of the file to preselect
	*	@param	defaultDir	navigate to this directory when it opens
	*	@param	filter	something like "jpg", null if you don't care
	*	@param	parent	un-enable this window
	*	@return the file to open, null if none selected
	*/
	public static File showOpenAWT(String title,String defaultFile, 
								String defaultDir,String filter,Frame parent){
		FileDialog dialog = new FileDialog(parent,title,FileDialog.LOAD);
		dialog.setDirectory(defaultDir);
		if(filter==null)
			dialog.setFile(defaultFile);
		else{
			dialog.setFile(defaultFile+"."+filter);
			final String myFilter = filter;
			dialog.setFilenameFilter(new FilenameFilter(){
					public boolean accept(File dir, String name){
						return name.toLowerCase().endsWith(myFilter);
					}
				});
		}
		dialog.setVisible(true);
		if(dialog.getFile() != null){
			return new File(dialog.getDirectory(),dialog.getFile());
		}
		return null;
	}

	/**
	* Show an open dialog box with Swing classes.
	*	@param	title	the title of the window that pops up
	*	@param	defaultFile	the name of the file to preselect
	*	@param	defaultDir	navigate to this directory when it opens
	*	@param	filter	something like "jpg", null if you don't care
	*	@param	parent	un-enable this window
	*	@return the file to open, null if none selected
	*/
	public static File showOpenSwing(String title,String defaultFile,
								String defaultDir, String filter, JFrame parent){
		JFileChooser jfcPickFile = new JFileChooser();
		jfcPickFile.setDialogTitle(title);
		jfcPickFile.setCurrentDirectory( new File(defaultDir) );
		final String myFilter = filter;
		jfcPickFile.setFileFilter(new javax.swing.filechooser.FileFilter(){
				public boolean accept(File f){
					return f.getName().toLowerCase().endsWith(myFilter);
				}
				public String getDescription(){
					return myFilter+" Document";
				}
			});
		int returnVal = jfcPickFile.showOpenDialog(parent);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			return jfcPickFile.getSelectedFile();
		}
		return null;
	}

	/**
	* Show an image open dialog box with AWT classes.
	*	@param	title	the title of the window that pops up
	*	@param	defaultFile	the name of the file to preselect
	*	@param	defaultDir	navigate to this directory when it opens
	*	@param	parent	un-enable this window
	*	@return the file to open, null if none selected
	*/
	public static File showImageOpenAWT(String title,String defaultFile, 
								String defaultDir,Frame parent){
		FileDialog dialog = new FileDialog(parent,title,FileDialog.LOAD);
		dialog.setDirectory(defaultDir);
		dialog.setFile(defaultFile);
		dialog.setFilenameFilter( new ImageFilenameFilter() );
		dialog.setVisible(true);
		if(dialog.getFile() != null){
			return new File(dialog.getDirectory(),dialog.getFile());
		}
		return null;
	}


/******************************************************************************
 **		Save
 ******************************************************************************/

	/**
	* Show a save dialog box with AWT classes.
	*	@param	title	the title of the window that pops up
	*	@param	defaultFile	the name to prepropogate the input field with
	*	@param	defaultDir	navigate to this directory when it opens
	*	@param	filter	something like "jpg", null if you don't care
	*	@param	parent	un-enable this window
	*	@return the file to save to, null if none selected
	*/
	public static File showSaveAWT(String title,String defaultFile, 
								String defaultDir,String filter,Frame parent){
		FileDialog dialog = new FileDialog(parent,title,FileDialog.SAVE);
		dialog.setDirectory(defaultDir);
		if(filter==null)
			dialog.setFile(defaultFile);
		else{
			dialog.setFile(defaultFile+"."+filter);
			final String myFilter = filter;
			dialog.setFilenameFilter(new FilenameFilter(){
					public boolean accept(File dir, String name){
						return name.toLowerCase().endsWith(myFilter);
					}
				});
		}
		dialog.setVisible(true);
		if(dialog.getFile() != null){
			return new File(dialog.getDirectory(),dialog.getFile());
		}
		return null;
	}

	/**
	* Show a save dialog box with Swing classes.
	*	@param	title	the title of the window that pops up
	*	@param	defaultFile	the name to prepropogate the input field with
	*	@param	defaultDir	navigate to this directory when it opens
	*	@param	filter	something like "jpg", null if you don't care
	*	@param	parent	un-enable this window
	*	@return the file to save to, null if none selected
	*/
	public static File showSaveSwing(String title,String defaultFile,
								String defaultDir, String filter, JFrame parent){
		JFileChooser jfcPickFile = new JFileChooser();
		jfcPickFile.setDialogTitle(title);
		jfcPickFile.setCurrentDirectory( new File(defaultDir) );
		final String myFilter = filter;
		jfcPickFile.setFileFilter(new javax.swing.filechooser.FileFilter(){
				public boolean accept(File f){
					return f.getName().toLowerCase().endsWith(myFilter);
				}
				public String getDescription(){
					return myFilter+" Document";
				}
			});
		int returnVal = jfcPickFile.showSaveDialog(parent);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			return jfcPickFile.getSelectedFile();
		}
		return null;
	}

}
