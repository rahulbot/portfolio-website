package org.instituteofthefuture.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import org.instituteofthefuture.*;
import org.instituteofthefuture.io.ImageUtilities;

/**
 * <p>A useful holder for making Mac OSX - style About windows.  Goes away when
 * the user hits escape or enter.  Also includes an IF logo.</p>
 *
 * <p>
 * Maybe I should make this a JDialog... anyway this code is inspired by / 
 * copied from Sven (<a href="mailto:sven@mac.com">sven@mac.com</a>,
 * <a href="http://homepage.mac.com/svc">http://homepage.mac.com/svc<a>)
 * </p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class AboutJFrame extends JDialog implements IFConstants {

	/** the fixed with of the window */
	private int myWidth = 270;

	/** the fixed height of the window */
	private int myHeight = 385;

	/**
	* main constructor
	*	@param	parent	the component to print
	*	@param	title	will show up at the top of the window
	*	@param	message	the info message to show in the window
	*	@param	icon	the small image to show
	*/
	public AboutJFrame(Component parent, String title, String message, Icon icon) {
		super();
		addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent event) {
					close();
				}
			});
		addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent event) {
					if (event.getKeyCode() == KeyEvent.VK_ESCAPE ||
						event.getKeyCode() == KeyEvent.VK_ENTER) {
							close();
					}
				}
			});
		
		JPanel myPanel = new JPanel();
		myPanel.setBorder( BorderFactory.createEmptyBorder(5,5,5,5) );

		JLabel iconLabel = new JLabel(icon,JLabel.CENTER);
		JLabel titleLabel = new JLabel(title,JLabel.CENTER);
		titleLabel.setFont( new Font("Sans Serif", Font.BOLD, 16) );
        StringTokenizer otherLabels = new StringTokenizer(message, "\n");

		//myPanel.setLayout( new GridLayout(3+otherLabels.countTokens(),1) );
		myPanel.setLayout( new FlowLayout() );
		//System.out.println("grid layout total = "+(2+otherLabels.countTokens()));
        myPanel.add(iconLabel);
        myPanel.add(titleLabel);

        while (otherLabels.hasMoreElements()) {
            JLabel messageLabel = new JLabel( otherLabels.nextToken(), JLabel.CENTER);
            messageLabel.setFont( new Font("Serif", Font.PLAIN, 12) );
            myPanel.add( messageLabel );
        }
		myPanel.add( new JLabel(ImageUtilities.getImageIconFromResource("if-logo.gif")) );
        if(isMacOSX) myHeight -= 25; else myWidth += 25;
		myPanel.setPreferredSize( new Dimension(myWidth,myHeight) );
        this.getContentPane().add(myPanel);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
		this.setBounds(50,50,myWidth,myHeight);
        setVisible(true);
    }

	/**
	* Dismiss the window
	*/
    public void close() {
        setVisible(false);
        dispose();
    }
    
}
