package org.instituteofthefuture.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.IOException;

import org.instituteofthefuture.*;
import org.instituteofthefuture.io.ImageUtilities;

import edu.stanford.ejalbert.BrowserLauncher;

/**
 * <p>A useful holder for making standard Mac OSX - style About Dialog Boxes.
 * Goes away when the user hits escape,enter, or clicks the OK button.  
 * Note that this is specific to the Institute of the Future (it also
 * includes an IF logo). It would be nice if this resized itself correctly....</p>
 *
 * <p>
 * this code is inspired by / 
 * copied from Sven (<a href="mailto:sven@mac.com">sven@mac.com</a>,
 * <a href="http://homepage.mac.com/svc">http://homepage.mac.com/svc<a>)
 * </p>
 *
 *	<ul>
 *	<li>2002.11.26 - added feature to jump to webpages on click
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class AboutDialog extends JDialog
						implements IFConstants,ActionListener {

	/** the Institute of the Future logo */
	private static JButton IFlogo;
	static{
		IFlogo = new JButton(
			ImageUtilities.getImageIconFromResource("iotf/if-logo.gif"));
		IFlogo.addActionListener(new IFActionListener());
	}
	
	/** the with of the window */
	private int myWidth = 270;

	/** the height of the window */
	private int myHeight = 425;
	
	/** click on this to jump to the app homepage */
	private JButton appIcon;

	/** save the url for the button handler */
	private String appURL;

	/**
	* main constructor
	*	@param	parent	the component to go modal on
	*	@param	appName	will show up at the top of the window
	*	@param	version	the version of this app
	*	@param	link	a link to the webpage for this app
	*	@param	icon	the small image to show
	*/
	public AboutDialog(JFrame parent, String appName, String version, String myLink,Icon icon) {
		super(parent,true);
		appURL = myLink;
		this.setTitle("About "+appName.trim());
		addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent event) {
					close();
				}
			});
		addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent event) {
					if (event.getKeyCode() == KeyEvent.VK_ESCAPE ||
						event.getKeyCode() == KeyEvent.VK_ENTER) {
							close();
					}
				}
			});
		
		JPanel myPanel = new JPanel();
		myPanel.setBorder( BorderFactory.createEmptyBorder(5,5,5,5) );
		JLabel titleLabel = new JLabel("      "+appName+"      ",JLabel.CENTER);
		titleLabel.setFont( new Font("Sans Serif", Font.BOLD, 16) );
		//figure out the time of the build
		Calendar now = Calendar.getInstance();
		//and generate the about message
		String message = "";
		JLabel appLabel = null;
		if(version.length() > 5){
			message = version;
			appLabel = new JLabel(icon);
		} else {
			message = new String(
				"Version "+version+" ("+getMonthName(now.get(Calendar.MONTH))+
					" "+now.get(Calendar.YEAR)+")\n"+
				"\n "+
				myLink+"\n"+
				"\n "+
				"Copyright "+now.get(Calendar.YEAR)+" - Institute of the Future\n"+
				"All Rights Reserved.");
			appIcon = new JButton(icon);
			appIcon.addActionListener(this);
		}
        StringTokenizer otherLabels = new StringTokenizer(message, "\n");
		//myPanel.setLayout( new GridLayout(3+otherLabels.countTokens(),1) );
		myPanel.setLayout( new FlowLayout() );
		//System.out.println("grid layout total = "+(2+otherLabels.countTokens()));
		if(version.length() > 5) myPanel.add(appLabel);
		else myPanel.add(appIcon);
        myPanel.add(titleLabel);
		//make labels for each line of the message string
        while (otherLabels.hasMoreElements()) {
            JLabel messageLabel = new JLabel( otherLabels.nextToken(), JLabel.CENTER);
            messageLabel.setFont( new Font("Serif", Font.PLAIN, 12) );
            myPanel.add( messageLabel );
        }
		//add the institute of the future logo
		myPanel.add( IFlogo );
		//add the ok button which closes it
        JButton okButton = new JButton("     OK     ");
        okButton.setAlignmentY(JButton.BOTTOM_ALIGNMENT);
		okButton.addActionListener(this);
        myPanel.add(okButton);
		//now size it up and show it...
        if(isMacOSX) myHeight -= 25; else myWidth += 25;
		//myPanel.setPreferredSize( new Dimension(myWidth,myHeight) );
        this.setContentPane(myPanel);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
		this.setBounds(50,50,myWidth,myHeight);
        setVisible(true);
    }

	/** dismiss the window */
    public void close() {
        setVisible(false);
        dispose();
    }
        
	/** test this out by popping one up... */
    public static void main(String s[]) {
        JFrame myFrame = new JFrame("Testing...");
        myFrame.setBounds(10,10,600,400);
        myFrame.setVisible(true);
        AboutDialog about = new AboutDialog(myFrame,
        	"About Testing...",
        	"1.0","http://www.instituteofthefuture.org/",
        	ImageUtilities.getImageIconFromResource("iotf/stamp.gif")
        	);
    }

	/** Handle the button clicks. */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			if( ((JButton)obj).getText().indexOf("OK") > -1){
				close();
			} else if(obj == appIcon){
				try{
					BrowserLauncher.openURL(appURL);
				} catch (IOException ioe){
					Alerts.showError("Browser Error",
						"Unable to open a browser!");
				}			
			}
		}
	}	


	/** pop up plea to send me a postcard */
	public static void showPostcardware(JFrame par){
		AboutDialog myAboutPS = new AboutDialog(
				par,"Postcardware",
					"If you like this  software, please send me a postcard - \n"+
					"          Institute of the Future          \n"+
					"          807 Ridge Drive          \n"+
					"          McLean, VA 22101          \n","",
	        		ImageUtilities.getImageIconFromResource("iotf/stamp.gif")
				);
	}

	/**
	 * returns the string of a month in english.
	 * from http://rum.cs.yale.edu/cs112/notes/Calendar.html
	 */
	public static String getMonthName(int month) {
		switch (month) {
		case  1: return ("January");
		case  2: return ("February");
		case  3: return ("March");
		case  4: return ("April");
		case  5: return ("May");
		case  6: return ("June");
		case  7: return ("July");
		case  8: return ("August");
		case  9: return ("September");
		case 10: return ("October");
		case 11: return ("November");
		case 12: return ("December");
		default: return ("Illegal month");
		}
	} // method MonthName

}

/** 
 * just mini helper class to listen for clicks on the
 * static IotF logo at the bottom of the AboutDialog
 * window.  this jumps to the IotF homepage.
 */
class IFActionListener 
			implements IFConstants,ActionListener{

	public void actionPerformed(ActionEvent e){
		try{
			BrowserLauncher.openURL(IF_HOMEPAGE);
		} catch (IOException ioe){
			Alerts.showError("Browser Error",
					"Unable to open a browser!");
		}
	}

}