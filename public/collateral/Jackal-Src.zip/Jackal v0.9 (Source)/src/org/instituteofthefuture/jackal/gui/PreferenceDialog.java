package org.instituteofthefuture.jackal.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import org.instituteofthefuture.jackal.logoutils.Translator;
import org.instituteofthefuture.IFConstants;
import org.instituteofthefuture.jackal.*;
import org.instituteofthefuture.gui.*;

/**
 * <p>Sets the preferences for Jackal.  This should probably be rolled
 * into the JackalPreferences class.  And this should probably be
 * turned into a TabbedPane or something.</p>
 *  <ul>
 *	<li>2002.11.25 - added interface and font panels,
 *		added cancel on ESC
 *	<li>2002.11.21 - added language option panel
 *	<li>2002.11.20 - cleaned up for standard IotF interface
 *	<li>2001.10.15 - changed to use a BrickManager
 *	<li>2001.08.11 - moved to new cricketLogo package
 *	<li>2001.08.10 - starting from LogoBlocks.gui.PreferencePanel, removed sizing info
 *	</ul>
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class PreferenceDialog extends JDialog
	implements ActionListener,IFConstants, JackalConstants {

	RadioButtonPanel portPanel,languagePanel;
	ComboBoxPanel interfacePanel;
	FontSelectPanel fontPanel;
	Jackal parent;

	public PreferenceDialog(Jackal j) {
		super(j, true);
		this.setTitle("Jackal Preferences");
		addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent event) {
					if (event.getKeyCode() == KeyEvent.VK_ESCAPE)
						closePreferences(false);
				}
			});
		parent = j;
		String portNotes = "";
		//make the serial port selector (OS friendly)
		if(isMacOSX)
			portNotes = 
			"Below is a list of all the serial ports Jackal \n"+
			"was able to find on your computer.  Since you \n"+
			"use OSX, only pick the one with the \"tty\" in \n"+
			"it! Then try a test beep to make sure it works.";
		else 
			portNotes = 
			"Below is a list of all the serial ports Jackal \n"+
			"was able to find on your computer.  Select the \n"+
			"one that you have the interface plugged into. \n"+
			"Then try a test beep to make sure it works.";
        portPanel = new RadioButtonPanel(
        	"Serial Port",j.myBrick.portsAvailable(),
        	j.myBrick.getSerialPortName(),
        	portNotes);
		//make the language selector
        languagePanel = new RadioButtonPanel(
        	"Language",Translator.getLanguageNames(),
        	Translator.getLanguageName(j.nextLanguage),
			"Below is a list of the languages that Jackal \n"+
			"supports.  Select the one you would like to \n"+
			"code in.  Note that this change won't take \n"+
			"effect until the next time you open Jackal." );
        //make the interface selector panel
		interfacePanel = new ComboBoxPanel(
			"Interfaces",parent.myInterfaceBuilder.getComboBox(),
			"Below is a list of the interfaces currently \n"+
			"installed in Jackal's "+DIR_INTERFACES+" folder. \n"+
			"Select the one you want to use.  Changes will \n"+
			"happen when you click the \"OK\" button." );
		//make the font selector panel
		fontPanel = new FontSelectPanel(
			JackalPreferences.getFontName(),
			JackalPreferences.getFontSize()
		);
		//make the main options panel
		JPanel optionsPanel = new JPanel();
		optionsPanel.setLayout( new GridLayout(2,2,5,5) );
		//optionsPanel.setLayout( new FlowLayout() );
		optionsPanel.add(portPanel);
		optionsPanel.add(languagePanel);
		optionsPanel.add(interfacePanel);
		optionsPanel.add(fontPanel);
		optionsPanel.setBorder( BorderFactory.createEmptyBorder(8,8,5,8) );
		int maxHieght = (int) Math.max(
			portPanel.getPreferredSize().height,
			Math.max(
				languagePanel.getPreferredSize().height,
				interfacePanel.getPreferredSize().height
			)
		);
		optionsPanel.setPreferredSize( new Dimension(
			(int) portPanel.getPreferredSize().width +
				(int) languagePanel.getPreferredSize().width,
			maxHieght*2) );
/*		optionsPanel.setPreferredSize( new Dimension(
			(int) portPanel.getPreferredSize().getWidth() +
				(int) languagePanel.getPreferredSize().getWidth(),
			(int) (Math.max(
				portPanel.getPreferredSize().getHeight(),
				languagePanel.getPreferredSize().getHeight() )+
				interfacePanel.getPreferredSize().getHeight() )
		) );*/
		//make the button panel
		JPanel buttonPanel = new JPanel();
		JButton saveButton = new JButton("OK");
		saveButton.addActionListener(this);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(this);
		buttonPanel.setLayout(new FlowLayout());
		JLabel spacer = new JLabel("  ");
		spacer.setPreferredSize( new Dimension(
			(int)optionsPanel.getPreferredSize().width-200,
			20));
		buttonPanel.add(spacer);
		buttonPanel.add(cancelButton);
		buttonPanel.add(saveButton);
		//finish making the panel
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(optionsPanel,BorderLayout.CENTER);
		this.getContentPane().add(buttonPanel,BorderLayout.SOUTH);
		GUIUtilities.setDialogSize(this,
			(int)optionsPanel.getPreferredSize().width,
			(int)optionsPanel.getPreferredSize().height+
				(int)buttonPanel.getPreferredSize().height+10
		);
		setResizable(false);
	}
	/*
	public void processEvent(AWTEvent e) {
		String id = e.paramString();
		if (id == "WINDOW_CLOSING") {
			closePreferences(false);
		}
		super.processEvent(e);
	}
	*/
	/**
	 * Handle the buttons.
	 */
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if (command == "OK") {
			closePreferences(true);
		}
		if (command == "Cancel") {
			closePreferences(false);
		}
	}

	/**
	 * This actually set the serial port of the brickManager,
	 * and the language for next time, invoked on exit.
	 *	@param	ok	if true then set the port, otherwise ignore it
	 */
	public void closePreferences(boolean ok) {
		dispose();
		if(ok) {
        	JackalPreferences.setFontName(fontPanel.getSelectedFontName());
        	JackalPreferences.setFontSize(fontPanel.getSelectedFontSize());

			String thisport = portPanel.getSelectedText();
			parent.myBrick.setSerialPortByName(thisport);
			parent.nextLanguage = Translator.getLanguageCode(
				languagePanel.getSelectedText() );
        	parent.jtpProcedures.getPainter().setFont( fontPanel.getSelectedFont() );
        	parent.populateInterface(interfacePanel.getSelectedText());
		}
	}

}

