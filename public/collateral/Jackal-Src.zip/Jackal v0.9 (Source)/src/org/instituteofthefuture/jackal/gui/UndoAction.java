package org.instituteofthefuture.jackal.gui;
 
import javax.swing.*;
import javax.swing.undo.*;
import java.awt.event.ActionEvent;

/**
 * <p>For undoing what you type.  Copied from a java.sun.com example.</p>
 *
 *	<ul>
 *	<li>2001.08.19 - created
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class UndoAction extends AbstractAction {
	private UndoManager undo;
	private RedoAction redoAction;
	
        public UndoAction(UndoManager u) {
            super("Undo");
            setEnabled(false);
            undo = u;
        }
        public void setRedoAction(RedoAction ra){
        	redoAction = ra;
        }
		public void actionPerformed(java.awt.event.ActionEvent e) {
			undo();
        }
        public void undo(){
            try {
                undo.undo();
            } catch (CannotUndoException ex) {
                System.out.println("Unable to undo: " + ex);
                ex.printStackTrace();
            }
            updateUndoState();
            if(redoAction == null) System.out.println("CRAP!");
            redoAction.updateRedoState();
        }
        public void updateUndoState() {
            if (undo.canUndo()) {
                setEnabled(true);
                putValue(Action.NAME, undo.getUndoPresentationName());
            } else {
                setEnabled(false);
                putValue(Action.NAME, "Undo");
            }
        }      
    }    
