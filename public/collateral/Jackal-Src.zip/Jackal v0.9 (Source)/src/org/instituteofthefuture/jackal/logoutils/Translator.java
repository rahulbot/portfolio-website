package org.instituteofthefuture.jackal.logoutils;
 
import java.util.*;
import javax.swing.*;
import java.io.*;

/**
 * <b>Translator v1.8</b>
 *	<p>A simple manager of creating hash tables out of the
 *	languages.txt file.  Creates the tables each time when you
 *	select a new translation to and from language.  Now
 *	integrating into another application only requires this
 *	file and the languages.txt</p>
 *
 *	<ul>
 *	<li>2002.11.23 - moved config file to resource in jar
 *	<li><i>old Change Log at end of file</i>
 *	</ul>
 * 
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class Translator {
	public static String EOL = System.getProperty("line.separator");

	public static final String LANGUAGE_FILENAME = "languages.txt";	//default filename
	public static final int DEFAULT_TABLES = 0;
	public static final boolean HTML = false;
	private static final int DICT_SIZE = 100;
	private static final boolean DEBUG = false;
	
	//the translation constants, used to make the correct hash table
	public static final int ENG_TO_ESP =  0;		//DON'T CHANGE THIS ORDER!!!
	public static final int ENG_TO_POR =  2;
	
	public static final int ESP_TO_ENG =  3;
	public static final int ESP_TO_POR =  5;
	
	public static final int POR_TO_ENG =  9;
	public static final int POR_TO_ESP =  10;
		

	//these arrays get filled with the words... keyed to english because
	//  that was the first language I had
	public static String[] eng;		//english
	public static String[] esp;		//espa�ol
	public static String[] por;		//portuguese


	//pointers to the current translation to use
	public static String[] from;
	public static String[] to;
	
	private static Hashtable ht;

//-------------------------------------------------------------------------------------
//TRANSLATION FUNCTIONS ---------------------------------------------------------------
//-------------------------------------------------------------------------------------

    /**
     * Create a new translator based off of the file passed in
     * 	@param inFile the opened file to read from
     */
	public static void init(BufferedReader inFile){
		ht = null;
		loadLanguageFile(inFile);
	}
    
    /**
     * Create a new translator based off the default file, "languages.txt"
     */
	public static void init(){
		ht = null;
		loadLanguageFile();
	}

//-------------------------------------------------------------------------------------
//TRANSLATION FUNCTIONS ---------------------------------------------------------------
//-------------------------------------------------------------------------------------
	
    /**
     * Just a wrapper for pulling out of the hash table...
     * if no detection then just return the same word	
     *	@param from the word to translate
     * 	@return String the translated version of the word passed in
     */
	public static String translateWord(String from){
	  if (ht != null) {
	  	String to = (String) ht.get(from);
	  	output("Translate: ."+from+". = ."+to+".");
	  	if (to == null) return from;			//no match, echo back original
	  	else if( to.equals(" ") ) return from;	//return spaces
	  	else if( to.equals("") ) return "";		//return empties
	  	else return to;							//return translated word
	  } else {
	  	output("Translate: translator hasn't been initialized yet!");
	  	return null;
	  }
	}
	
    
    /**
     * just loop through by making calls to the HashTable accessor function,
     * translateWord(String) - use current from/to language settings
     *	@param fromTxt the string of words to translate
     * 	@return String the translated version of the string passed in
     */
	public static String translate(String fromTxt){
		String toTxt = "";
		//split on everything, I'm not sure why, but why not!
		StringTokenizer st = new StringTokenizer(fromTxt,"@~![] ()+=-\t\n\r\f",true);
		boolean lastWasEOL = false;
		while (st.hasMoreTokens()) {
			toTxt += translateWord(st.nextToken());
		}
		return toTxt;
	}

    /**
     * call this to translate something quickly and set the from/to state
     *	@param fromTxt the string of words to translate
     *	@param f the language to translate from
     *	@param t the language to translate to
     * 	@return String the translated version of the string passed in
     */
    public static String translate(String fromTxt,String[] f, String[] t){
		setLanguages(f,t);
		return translate(fromTxt);
	}


//-------------------------------------------------------------------------------------
//LANGUAGE SETUP FUNCTIONS ------------------------------------------------------------
//-------------------------------------------------------------------------------------
	
    /**
     * set the langauge to translate from
     *	@param f the table of strings (a member of this class)
     */
	public static void setLanguageFrom(String[] f){ from = f; makeTable(); }
    /**
     * set the langauge to translate to
     *	@param t the table of strings (a member of this class)
     */
	public static void setLanguageTo(String[] t){ to = t; makeTable(); }

    /**
     * Set the langauge to translate from and to.  I suppose I could make and
     * have persistent objects (serialize) all the hash tables, but since this
     * isn't to computationally expensive, I'll just leave it like this
     *	@param f the table of strings (a member of this class) to translate from
     *	@param t the table of strings (a member of this class) to translate to
     */
	public static void setLanguages(String[] f,String[] t){
		from = f;
		to = t;
		makeTable();
	}

    /**
     * Actually generate the hash table using the previously set from and to vectors
     */
	private static void makeTable(){
		output("Making table...");
		ht = new Hashtable();
		for(int i=0;i<from.length;i++){
			output(from[i]+"/"+to[i]);
			if(from[i]!=null && to[i]!=null) ht.put(from[i],to[i]);	//ignore empty array elements
		}	
	}

    /**
     * do the creation of hast tables for translation, use this in concert with
     * the drop down to simplify moving this into other interfaces... so all
     * the handler for your combo box is call this with the selectedIndex!
     *	@param ref on of the constant translations defined above
     */
	public static void setLanguages(int ref){
		switch (ref){
			case ENG_TO_ESP:
				output("eng to esp"); 
				setLanguages(eng,esp);
				break;
			case ENG_TO_POR:
				output("eng to por"); 
				setLanguages(eng,por);
				break;
			case ESP_TO_ENG:
				output("esp to eng"); 
				setLanguages(esp,eng);
				break;
			case ESP_TO_POR:
				output("esp to por"); 
				setLanguages(esp,por);
				break;
			case POR_TO_ENG:
				output("por to eng");
				setLanguages(por,eng);
				break;
			case POR_TO_ESP:
				output("por to esp");
				setLanguages(por,esp);
				break;
		}
	}

//-------------------------------------------------------------------------------------
//INTERFACE FACTORY FUNCTIONS ---------------------------------------------------------
//-------------------------------------------------------------------------------------

    /**
     * use this utility function to easily make a drop down list with the right names
     *	@return JComboBox a combo box of the possible translations
     */
	public static JComboBox makeJComboBox(){
		JComboBox jcbOptions = new JComboBox();
		jcbOptions.addItem("English To Spanish");					//DON'T CHANGE THIS ORDER!!!!
		jcbOptions.addItem("English To Portuguese");
		jcbOptions.addItem("Spanish To English");
		jcbOptions.addItem("Spanish To Portuguese");
		jcbOptions.addItem("Portuguese To English");
		jcbOptions.addItem("Portuguese To Spanish");
		return jcbOptions;
	}
	
//-------------------------------------------------------------------------------------
//UTILITY FUNCTIONS -------------------------------------------------------------------
//-------------------------------------------------------------------------------------
	
    /**
     * for debugging
     *	@param t the string to print
     */
	//for debugging...
	public static void output(String t){
		if(DEBUG) System.out.println("Translator:"+t);
	}

    /**
     * fill the vectors from the languages text file (tab deliminated)
     * called when Translator object is created
     *	@param in the file to read from
     */
    public static void loadLanguageFile(BufferedReader in){
		String line;
		StringTokenizer lineTokens;
		eng = new String[DICT_SIZE];
		esp = new String[DICT_SIZE];
		por = new String[DICT_SIZE];
		int i=0;
		try{
			BufferedReader langFile = in;
			line = langFile.readLine();
			while(line != null){
				lineTokens = new StringTokenizer(line,"\t");
				eng[i] = lineTokens.nextToken();
				esp[i] = lineTokens.nextToken();
				por[i] = lineTokens.nextToken();
				output("init["+i+"] : "+eng[i]+"/"+esp[i]+"/"+por[i]);
				line = langFile.readLine();
				i++;
			}
		} catch (Exception e){
			output(e.toString());
		}        
    }

    /**
     * fill the vectors from the languages text file (tab deliminated)
     * called when Translator object is created, reads from default file
     */
	public static void loadLanguageFile(){
		try{
			BufferedReader langFile = new BufferedReader(new FileReader(LANGUAGE_FILENAME));
            loadLanguageFile(langFile);
		} catch (Exception e){
			output(e.toString());
		}
	
	}

    /**
     * get the String[] for this language, default to eng
     *	@param lang a string of the langauge
     *	@return String[] the table of words for this language
     */
    public static String[] getIdentifier(String lang){
		if(lang == null) lang = "en";	 	// default to english
        if(lang.equals("en")) return eng;
        if(lang.equals("es")) return esp;
		if(lang.equals("pr")) return por;
        return eng;							 // default to english
    }
    
    /**
     * get the list of languages
     *	@return String[] a list of the support langs
     */
    public static String[] getLanguageNames(){
		return new String[]
			{"English", "Spanish", "Portuguese"};
    }

    /**
     * get the 2-letter abbreviation for the full name of a language
     * (default to english)
     */
    public static String getLanguageCode(String lang){
		if(lang.equals("English")) return "en";
		else if(lang.equals("Spanish")) return "es";
		else if(lang.equals("Portuguese")) return "pr";
		else return "en";
    }	

    /**
     * get the full name from the 2-letter code
     * (default to english)
     */
    public static String getLanguageName(String lang){
		if(lang.equals("en")) return "English";
		else if(lang.equals("es")) return "Spanish";
		else if(lang.equals("pr")) return "Portuguese";
		else return "English";
    }	

	public static String getSelectedLanguageName(){
		if(to == eng) return "English";
		else if(to == esp) return "Spanish";
		else if(to == por) return "Portuguese";
		else return "English";
	}

	public static String getSelectedLanguageCode(){
		if(to == eng) return "en";
		else if(to == esp) return "es";
		else if(to == por) return "pr";
		else return "English";
	}
	
	public static JTable getLanguageTable(){
		//esp,eng,por
		String[] languages = new String[]{"English","Spanish","Portugues"};
		String[][] words = new String[eng.length][3];
		for(int i=1;i<eng.length;i++){
			words[i-1][0]=eng[i];
			words[i-1][1]=esp[i];
			words[i-1][2]=por[i];
		}
		return new JTable(words,languages);
	}

}

/******************************************************************************************
 *	CHANGE LOG
 *
 *	2002.11.21 - added accessors for natural language representation of languages
 *	2002.05.14 (rahulb, paulo)
 *		- added support for Portuguese
 *	2002.04.12 (rahulb)
 *		- changed to work with english, spanish, and japanese only
 *	2002.04.05 (rahulb)
 *		- changed commenting to be javadoc compatible for other people
 *	2002.03.15 (gshuman)
 *  	- added getIdentifier(String lang)that returns the String[] corresponding to lang 
 *	2002.03.06 (rahulb)
 *		- making static for LogoBlocks integration
 *	2001.10.20 (rahulb)
 *		- moved to logoutils package, changed to not add eols on a PC
 *	2001.09.04 (rahulb)
 *		- changed to look for '\r' in addition to '\n', which should get
 *			rid of that annoying ClassCastException!
 *	2001.08.31 (rahulb)
 *		- not sure what I'm doing, but something changed...
 *	2001.08.27 (rahulb)
 *		- should change to have each language a static int, not each translation?
 *		- only reads in spa and eng now
 *		- added HTML global for testing without text/html type
 *	2001.08.09 (rahulb)
 *		- changed '\n' and ' ' to be in html to allow for accents and JEditorPane
 *	2001.08.05 (rahulb)
 *		- removed Languages.java, now words are read in from the languages.txt file
 *		- really, the languages themselves should be loaded from that, but that requires
 *		  a lot more time to make this a more generalized engine 
 *		- changed a bunch of the function names to make more sense
 *	2001.08.04 (rahulb)
 *		- added portuguese
 *		- moved constants here
 *		- moved filling a JComboBox to here
 *		- these changes should make it easier to use this in other interfaces
 *	2001.07.31 (rahulb)
 *		- it works, barely
 *
 *****************************************************************************************/
