package org.instituteofthefuture.jackal;

import java.awt.*;
import javax.swing.*;

import org.instituteofthefuture.IFConstants;
import org.instituteofthefuture.jackal.BrickManager;

/**	
 * <p>copied from Fred's UpdateThread</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class MonitorThread extends Thread implements IFConstants{
	private BrickManager myBrick;
	private JLabel myLabel;
    private boolean running = true;
    private boolean paused = false;
    
	public MonitorThread(BrickManager bm,JLabel l) {
		this.myBrick = bm;
		this.myLabel = l;
	}
   
	public void run() {
		while (true) {
			//pause for a bit
		    try{
				Thread.sleep(5);
		    } catch (Exception e){
		    	e.printStackTrace();
		    }
			if(running){
				paused = false;
			    try{
			    	int b= myBrick.read();
				    if (b != -1){		//fresh data
				    	myLabel.setText((new Integer(b)).toString());
				    	//myLabel.setForeground(Color.black);
				    } else { 				//stale data
				    	//myLabel.setForeground(new Color(66,66,66));
					}
			    } catch (Exception e){
			    	//just ignore serial errors and go on
			    }
			} else {
				paused = true;
				//myLabel.setForeground(new Color(66,66,66));
			}
		}
	}

	public void pause(){
		running = false;
		while(paused == false){
		    try{
				Thread.sleep(10);
		    } catch (Exception e){
		    	e.printStackTrace();
		    }
		}
	}
	public void unpause(){ running = true; }
	
}
