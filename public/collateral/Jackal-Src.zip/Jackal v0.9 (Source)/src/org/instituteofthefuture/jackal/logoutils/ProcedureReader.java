package org.instituteofthefuture.jackal.logoutils;

import java.awt.*;
import javax.swing.*;	//for grabbing a webpage
import java.net.*;		//for URL
import java.util.*;
import java.io.*;

import org.instituteofthefuture.jackal.JackalConstants;
import org.instituteofthefuture.io.FileUtilities;
import org.instituteofthefuture.gui.Alerts;

/**
 * <p>This lets me make the smart downloader from lib.txt.  So if you pass it
 * code then it returns the code plus any functions from the library that
 * it uses.</p>
 *
 *	<li>2002.11.21 - moved to logoutils since that makes more sense
 *	<li>2001.10.03 - now updateLib redoes the table, so you can use new 
 *		libs immediately
 *	<li>2001.09.04 - added library file updating from the net
 *	<li>2001.08.16 - created, works
 *	</ul>
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class ProcedureReader implements JackalConstants {

	/** utility for debugging */
	public static boolean DEBUG = false;

	/** the name of the file to read from */
	public String libraryFile;
	
	/** a vectory of the procedures defined in this library */
	private Vector procNames;
	
	/** a has from procedure name to procedure code */
	private Hashtable ht;
	
	/** set the file to read from and initialize the library */
	public ProcedureReader(String fileName){
		libraryFile = fileName;
		initTable();
	}
	
	/** read in a library from the file */
	private void initTable() {
		procNames = new Vector();
		ht = new Hashtable();
		StringTokenizer st;
		boolean finishProc = false;
		String tempProc = "",tempLine,tempWord,tempProcName="";
		int procCount = 0;
		try{
			BufferedReader f = new BufferedReader(new FileReader(libraryFile));
			//BufferedReader f =
			//	FileUtilities.getBufferedReaderFromResource(libraryFile);
			while(f.ready()){
				tempLine = f.readLine()+" \n";
				st = new StringTokenizer(tempLine," ",true);
				while(st.hasMoreTokens()){
					tempWord = st.nextToken();
					if(tempWord.equals("end")) {
						finishProc = true;
					} else if(tempWord.equals("to")){
						tempProc += tempWord;
						tempWord = st.nextToken();	 //dump the space
						tempProc += tempWord;
						tempWord = st.nextToken();	 //read the proc name
						tempProcName = tempWord;
					} 
					tempProc += tempWord; //took out space
					if(finishProc){
						ht.put(tempProcName,tempProc);
						procNames.addElement(tempProcName);
						tempProcName = "";
						tempProc = "";
						finishProc = false;
					}
				}
			}
		} catch (Exception e) {
			output(e.toString());
			Alerts.showError("Problem with Library file",
				"Unable to load library file ("+LIBRARY_FILE+"),\n"+
				"try updating from the help menu.");
		}
		output("libProcCount = "+ht.size());
     	String n;
     	for (Enumeration e = ht.keys() ; e.hasMoreElements() ;) {
     		n = e.nextElement().toString();
			output("  key = _"+n+"_ = _" +ht.get(n)+ "_");
		}
		        
	}

	/** return the code for the procedure named, null if not found */
	public String getCode(String procName){
		Object temp = ht.get(procName);
		if (temp == null) return null;		
		return temp.toString();
	}

	/** for debugging */
	private void output(String msg){
		if(DEBUG) System.out.println("ProcedureReader : "+msg);
	}

	/** grab a new library file from the net, alert if failure */
	public boolean updateLibraryFile() throws Exception{
		/*try{
			HttpURLConnection myConn = new HttpURLConnection(LIBRARY_URL);
			output(myConn.getContent().toString());
			myConn.disconnect();
		} catch (Exception e){
			throw new Exception("Sorry, I couldn't get to the file!");
		}*/
		JEditorPane tempPane;
		try{
			//grab the new code
			//System.out.println("ProcReader : updating from "+LIBRARY_URL);
			tempPane = new JEditorPane(new URL(LIBRARY_URL));
			if( tempPane.getText().indexOf("<html>") != -1 )	//it didn't work!
				throw new Exception("Sorry, Jackal could not find the library file.");
			output(tempPane.getText());
		} catch (Exception e){
			initTable();	//but initialize it anyway in case someone just changed the local file
			throw new Exception("Sorry, Jackal could not connect to the server.");
		}
		try{
			//now overwrite the old library file
			FileWriter fwOut = new FileWriter(libraryFile);
			BufferedWriter out = new BufferedWriter(fwOut);
			out.write(tempPane.getText());
			out.flush();
			out.close();
		} catch (Exception e){
			initTable();	//but initialize it anyway in case someone just changed the local file
			throw new Exception("Sorry, I couldn't save the file!");
		}
		initTable();	//reread the table
		return true;
	}

	/** return a vector of the procedures names in the library */
	public Vector getKeys(){
		return procNames;
	}

    public Vector getProcDefs(){
        Vector procDefs = new Vector();
        for(int i=0;i<procNames.size();i++){
            String temp = (String) ht.get(procNames.elementAt(i));
            //System.out.println(temp);
            String procComment = "";
            if( temp.indexOf(";**") > -1 ){
                procComment = temp.substring( temp.indexOf(";**") , temp.indexOf("\n",temp.indexOf(";**")) );
                procDefs.addElement( "\n"+procComment );
            }
            String procLine = temp.substring(temp.indexOf("to ")+3,temp.indexOf("\n",temp.indexOf("to ")));
            procDefs.addElement( "     "+procLine );
       }
       return procDefs;
    }

}
