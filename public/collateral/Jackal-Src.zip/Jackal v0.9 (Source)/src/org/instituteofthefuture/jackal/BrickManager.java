package org.instituteofthefuture.jackal;

import org.instituteofthefuture.serialio.SerialComm;

/**
 * <p>This class serves as a handy communications wrapper for
 * talking to bricks.  Any new bricks should implement this
 * for user interface compatability, probably around a comm (which
 * should extend org.instituteofthefuture.serialio.SerialComm)
 * and a compiler package.</p>
 *	<ul>
 *	<li>2002.11.24 - added getCodeSize()
 *	<li>2001.10.15 - added read()
 *	<li>2001.10.13 - created to use with Jibble, two implementors should
 *		be CricketManager and YellowBrickManager
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public interface BrickManager{

	/** just download procs to the brick */
	public void download(String s) throws Exception;

	/** download procs and the program to run to the brick */
	public void download(String s,String menu) throws Exception;

	/** download procs and the two programs to run to the brick */
	public void download(String s,String prg1, String prg2) throws Exception;

	/** just run some code */
	public void run(String s) throws Exception;
	
	/** for the monitor */
	public int read() throws Exception;
	
	/** open a serial port by name */
	public void setSerialPortByName(String n);

	/** get the name of the currently selected serial port */
	public String getSerialPortName();

	/** an array of the available ports */
	public String[] portsAvailable();

	/** check this after compiling to see how many bytes were downloaded */
	public int getCodeSize();

	/** the total amount of memory space available on the brick */
	public int getCodeBufferSize();
	
}
