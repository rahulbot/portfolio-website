package org.instituteofthefuture.jackal.gui;

import javax.swing.*;
import javax.swing.undo.*;
import java.awt.event.ActionEvent;

/**
 * <p>For redoing what you type.  Copied from a java.sun.com example.</p>
 *	<ul>
 *	<li>2001.08.19 - created
 *	</ul>
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class RedoAction extends AbstractAction {
	private UndoManager undo;
	private UndoAction undoAction;

        public RedoAction(UndoManager u) {
            super("Redo");
            setEnabled(false);
            undo = u;
        }
        public void setUndoAction(UndoAction ua){
            undoAction = ua;
        }
        public void actionPerformed(java.awt.event.ActionEvent e) {
			redo();
        }
		public void redo(){
            try {
                undo.redo();
            } catch (CannotRedoException ex) {
                System.out.println("Unable to redo: " + ex);
                ex.printStackTrace();
            }
            updateRedoState();
            undoAction.updateUndoState();
		}
        public void updateRedoState() {
            if (undo.canRedo()) {
                setEnabled(true);
                putValue(Action.NAME, undo.getRedoPresentationName());
            } else {
                setEnabled(false);
                putValue(Action.NAME, "Redo");
            }
        }
    }    
