package org.instituteofthefuture.jackal.gui;

import java.awt.*;
import java.util.*;
import java.io.*;
import javax.swing.*;

import org.instituteofthefuture.jackal.JackalConstants;
import org.instituteofthefuture.gui.Alerts;
import org.instituteofthefuture.io.ImageFilenameFilter;

/**
 * <p>This is a convenient way to read in skin files - cool!</p>
 *
 *	<p>File Protocol:
 *	<pre>
 *		#comments
 *		Image=imagename
 *		CommandCenter=Cmd_x Cmd_y Cmd_width Cmd_height
 *		DownloadButt=Dwn_x Dwn_y Dwn_width Dwn_height
 *		Procedures=Prc_x Prc_y Prc_width Prc_height
 *		RunField=Run_x Run_y Run_width Run_height
 *		Author=yourName
 *	</pre></p>
 *	<ul>
 *	<li>2002.11.25 - changed to use locations array for storage, index by name only
 *	<li>2002.11.23 - added loading of author string, moved to a properties file
 *	<li>2002.11.20 - changed to load from [name].txt
 *	<li>2001.09.06 - removed text color
 *	<li>2001.08.17 - removed the monitor line from the file
 *	<li>2001.08.11 - moved to new cricketLogo package
 *	<li>2001.08.10 - added monitor and text color
 *	<li>2001.08.09 - works :-) but it's not too pretty...
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class InterfaceBuilder implements JackalConstants {
	public static boolean DEBUG = false;

	private static String IMAGE = "Image";
	private static String COMMAND = "CommandCenter";
	private static String DOWNLOAD = "DownloadButt";
	private static String MONITOR = "Monitor";
	private static String PROCEDURES = "Procedures";
	private static String RUN_THIS = "RunField";
	private static String AUTHOR = "Author";

	private int locations[][];
	public static final int CMD = 0;
	public static final int DWN = 1;
	public static final int MON = 2;
	public static final int PRC = 3;
	public static final int RUN = 4;
	
	private Properties settings;
	private ImageIcon myImageIcon;

	private boolean tryingDefault = false;

/******************************************************************************
 **		INITIALIZATION
 ******************************************************************************/

	public InterfaceBuilder(){}

	//call this function from an JChooser open dialog
	public void load(String f){
		try{	
			String fileName = f+".txt";
			settings = new Properties();
			settings.load( new FileInputStream(
				new File(DIR_INTERFACES,fileName)) );
			locations = new int[10][4];
			populateLocs(settings.getProperty(COMMAND),CMD);
			populateLocs(settings.getProperty(DOWNLOAD),DWN);
			populateLocs(settings.getProperty(PROCEDURES),PRC);
			populateLocs(settings.getProperty(RUN_THIS),RUN);
			populateLocs(settings.getProperty(MONITOR),MON);
			myImageIcon = new ImageIcon(DIR_INTERFACES+"/"+settings.getProperty(IMAGE));
			tryingDefault = false;
		} catch (Exception e) {
			e.printStackTrace();
			if(tryingDefault = true){
				Alerts.showError("Interface Error",
					"Unable to locate \""+f+"\" and default interface, exiting.");
				System.exit(0);
			}
			tryingDefault = true;
			load("default");
			Alerts.showError("Interface Error",
				"Unable to locate \""+f+"\", using default interface.");
		}
	}

/******************************************************************************
 **		ACCESSORS
 ******************************************************************************/

	private void populateLocs(String s, int ident) throws Exception{
		int[] locs = new int[4];
		StringTokenizer st = new StringTokenizer(s," ");
		String temp;
		//String oTemp = "";
		for(int i=0; i<4; i++){
			temp = st.nextToken();
			locs[i] = Integer.parseInt(temp);
		}
		locations[ident] = locs;
	}
	
	private void populateColor(StringTokenizer st, Color c){
		String temp;
		int r,g,b;
		temp = st.nextToken();	//dump the first token
		temp = st.nextToken();
		r = Integer.parseInt(temp);
		temp = st.nextToken();
		g = Integer.parseInt(temp);
		temp = st.nextToken();
		b = Integer.parseInt(temp);
		c = new Color(r,g,b);		
		output(c.toString());
	}

	public void setNewBounds(Component c,int which){
		int[] locs = locations[which];
		output("setting..."+locs[0]+"/"+locs[1]+"/"+locs[2]+"/"+locs[3]);
		c.setBounds(locs[0],locs[1],locs[2],locs[3]);
	}
	
	public ImageIcon getImageIcon() {return myImageIcon;}
	public String getImageFilename() {return settings.getProperty(IMAGE);}
	public String getName() {
		return settings.getProperty(IMAGE).substring(
			0,settings.getProperty(IMAGE).lastIndexOf('.') );
	}
	public String getAuthor() {return settings.getProperty(AUTHOR);}
	public String getDescription() { 
		return "\""+getName()+"\" interface ("+getAuthor()+")";
	}

/******************************************************************************
 **		UTILITY
 ******************************************************************************/

	public String[] getInterfaceNames(){
		//Mac Classic doesn't support File.listFiles!
		String[] imageFiles = new File(DIR_INTERFACES).list(
			new ImageFilenameFilter());
		String[] names = new String[imageFiles.length];
		for(int i=0;i<imageFiles.length;i++){
			names[i]=imageFiles[i].substring(0,imageFiles[i].indexOf('.'));
		}
		return names;
	}

	public JComboBox getComboBox(){
		JComboBox jcb = new JComboBox();
		String[] names = getInterfaceNames();
		for(int i=0;i<names.length;i++){
			jcb.addItem(names[i]);
			if(names[i].equals(getName())) jcb.setSelectedIndex(i);
		}
		return jcb;
	}

	private void output(String s){
		if(DEBUG) System.out.println("InterfaceBuilder : "+s);
	}

}
