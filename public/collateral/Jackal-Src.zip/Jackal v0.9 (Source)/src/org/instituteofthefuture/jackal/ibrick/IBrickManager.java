package org.instituteofthefuture.jackal.ibrick;

/**
 * <p>Implement this to use the IBrickServer and IBrickConnect
 * dialogs.</p>
 *	<ul>
 *	<li>2002.11.20 - created
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public interface IBrickManager{
	
	public void setRemoteInterface(boolean connOK);
	
}
