package org.instituteofthefuture.jackal.ibrick;

import javax.swing.*;				//for TextBox outputting
import java.net.*;					//for socket stuff
import java.io.*;					//for socket stuff
import java.util.*;					//for Vector
import org.instituteofthefuture.jackal.BrickManager;

/**
 * <p>The handles the controlling IBrick client, now there is only one,
 * others are refused a connection</p>
 *	<ul>	
 *	<li>2002.01.17 - adding iTalk abilities
 *	<li>2001.10.15 - changed to use a BrickManager
 *	<li>2001.09.01 - cleaning up for use in Jackel, changed to Thread rather,
 *		than Runnable and removed all file stuff, renamed, made more
 *		procedures for clarity
 *	<li>2000.12.06 - added file save and load support!
 *	<li>2000.12.03 - added file list transfer on login
 *	<li>2000.12.02 - started, appears to work!
 *	</ul>
 *
 * @see org.instituteofthefuture.jackal.ibrick.IBrickMessage
 * @see org.instituteofthefuture.jackal.ibrick.IBrickClient
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
 public class IBrickServer implements Runnable{

	private boolean DEBUG = true;

	private ServerSocket ss;
	private Socket client;
	private ObjectInputStream in;
	private ObjectOutputStream out;

	private JTextPane outputBox = null;
	private JTextField statusBox = null;
	private BrickManager parentCM;
	
	public IBrickServer(BrickManager pcm){
		parentCM = pcm;
	}
	public IBrickServer(BrickManager pcm,JTextPane jta, JTextField jtf){
		parentCM = pcm;
		outputBox = jta;
		statusBox = jtf;
	}
		
	private void outputStatus(String msg){
		if(statusBox != null) statusBox.setText(msg);
	}
	
	private void outputMsg(String msg){
		if(outputBox != null) outputBox.setText(outputBox.getText()+msg+"\n");
	}
	
	private void output(String msg){
		if(DEBUG) System.out.println("IBrickServer : "+msg);
	}

	public void run(){
		outputStatus("Starting server...");
		output("INIT - IBrick server....");
		//init the server socket, block for a client
		try{
			ss = new ServerSocket(IBrickMessage.PORT);
		} catch (Exception e) {
			output("Init Error: "+e.toString());
		}
		while(true){
			try{
				waitForLogin();
				initStreams();
			} catch (Exception e) {
				output("Error: "+e.toString());
			}
			while( receiveCommand() ) {}
			output("client lost!");
			closeClient();
		}
	}

	/** block till you get a client login */
	private void waitForLogin() throws Exception{
		outputStatus("Waiting for a client...");
		output("waiting for client...");
		client = ss.accept();
		output(" Got a client!");
		outputStatus("Got a client!");
	}
	
	/**initialize the input and output streams to the client once they've logged in */
	private void initStreams() throws Exception{
		in = new ObjectInputStream( client.getInputStream() );
		out = new ObjectOutputStream( client.getOutputStream() );
	}
	
	/** wait for a command from the client, handle any errors from it */
	private boolean receiveCommand(){
		IBrickMessage icm;
		try{
			outputStatus("Awaiting client commands...");
			icm = blockForMsg();
			if( !parseMsg( icm ) ) return false;
			return true;
		} catch (NullPointerException npe) {
			output("SERROR-Listener1: lost client");
			return false;
		} catch (Exception e) {
			output("SERROR-Listener2: " +e);
			return false;
		}	
	}

	/** got a logout, close it all up */
	private void closeClient(){
		try{
			if (client!=null) client.close(); else output("client null");
			if (out!=null) out.close(); else output("out null");
			if (in!=null) in.close(); else output("in null");
		} catch (Exception e) {
			output("       SERROR10: "+e);
		}
	}
	
	/** block till you get a message from the client */
	private IBrickMessage blockForMsg(){			//blocking
		output("waitMsg....");
		Object temp;
		IBrickMessage icm = null;
		try{ 
			//System.out.print("waiting for a message...");
			temp = in.readObject();
			//System.out.println("__got it!");
			icm = (IBrickMessage) temp;
		} catch (Exception e) {
			output("SERROR-Listener8: " + e);
		}
		output("........got");
		return icm;
	}

	private void killServer(){
		output("trying to kill the server");
		icmLogout();		//tell the client I'm going down!
		try{
			closeClient();
			ss.close();
			output("success!");
		} catch (Exception e){
			output("killServer "+e.toString());
		}	
	}

	/** called when the thread is stopped */
	protected void finalize(){
		output("finalizing - ");
		killServer();
	}

	/** This is the low-level communication function that handles all messages sent to the server */
	private void dispatchCommand(IBrickMessage msg){
	    output("Sending a message of type "+msg.getType());
	    if (out != null) {
	    	try{
	      		out.writeObject(msg);
	      		out.flush();
			} catch (Exception e) {output("ERROR: "+e); }
	    }
	}

	private void icmLogout() { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_LOGOUT,"SERVER","The server stopped, sorry!") ); }

	//------------------------------------------------------- CONTROL
	
	/** receive and handle a message, plus the handshaking logic for them all */
	private boolean parseMsg(IBrickMessage msg){
	   output("Got msg type = "+msg.getType() );
		try {
			if (msg.getType() == IBrickMessage.MSG_PROC) {
				output("["+msg.getUser()+"] Got a PROC");
				outputMsg(msg.getUser()+" is downloading code ("+msg.getMsg().length()+").");
				try {
					parentCM.download(msg.getMsg(),msg.getHead(),"");
					dispatchCommand(new IBrickMessage(IBrickMessage.MSG_OK,"SERVER","downloaded"));
				} catch (Exception e){
					dispatchCommand(new IBrickMessage(IBrickMessage.MSG_ERROR,"SERVER",e.toString()));
				}
			}
			if (msg.getType() == IBrickMessage.MSG_RUN) {
				output("["+msg.getUser()+"] Got a RUN");
				outputMsg(msg.getUser()+" is running code ("+msg.getMsg().length()+").");
				try { parentCM.run(msg.getMsg());
					dispatchCommand(new IBrickMessage(IBrickMessage.MSG_OK,"SERVER","running"));
				} catch (Exception e){
					dispatchCommand(new IBrickMessage(IBrickMessage.MSG_ERROR,"SERVER","RUN ERROR",e.getMessage()));
				}
			}
			if (msg.getType() == IBrickMessage.MSG_LOGIN) {
				outputMsg("*** "+msg.getUser()+" has connected ***");
				outputStatus("Awaiting commands from "+msg.getUser());
				output("["+msg.getUser()+"] Got a LOGIN");
				dispatchCommand(new IBrickMessage(IBrickMessage.MSG_LOGIN,"SERVER","Welcome to the IBrick Server - you have control!"));
				output("sent reply");
			}
			if (msg.getType() == IBrickMessage.MSG_LOGOUT) {
				outputMsg("*** "+msg.getUser()+" had disconnected! ***");
				output("["+msg.getUser()+"] Got a LOGOUT");
				return false;
			}
			if (msg.getType() == IBrickMessage.MSG_ERROR) {
				outputMsg("Error!");
				output("["+msg.getUser()+"] Got a ERROR");
			}
			if (msg.getType() == IBrickMessage.MSG_OK) {
				outputMsg("OK :-)");
				output("["+msg.getUser()+"] Got a OK");
			}
		} catch (Exception e) { output("SERROR-Listener5: "+e); }
		return true;
	}

}
