package org.instituteofthefuture.jackal;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.undo.*;
import com.apple.mrj.*;

import org.instituteofthefuture.IFConstants;
import org.instituteofthefuture.gui.*;
import org.instituteofthefuture.io.*;

import org.instituteofthefuture.jackal.gui.*;
import org.instituteofthefuture.jackal.logoutils.*;

//aweseom calss to launch a browser
import edu.stanford.ejalbert.BrowserLauncher;

/** 
 *	<p>This is the menubar for Jackal.</p>
 *	<ul>
 *	<li>2002.11.26 - fixed for Mac Classic
 *	<li>2002.11.20 - created, fixed to be Mac-friendly
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class JackalMenuBar extends JMenuBar implements ActionListener,
	IFConstants, MRJAboutHandler, MRJQuitHandler, MRJPrefsHandler,
	JackalConstants {

	/** for MRJ radar #2680426 */
	private boolean alreadyQuitting = false;

	public static boolean DEBUG = true;

	//Menus
	private JMenu			  jmFile;
	private JMenuItem			jmiFileNew;
	private JMenuItem			jmiFileOpen;
	private JMenuItem			jmiFileSave;
	private JMenuItem			jmiFileSaveAs;
	private JMenuItem		    jmiFilePrint;	
	private JMenuItem		    jmiFileQuit;
	private JMenu			  jmEdit;
    private JMenuItem			jmiEditUndo;
    private JMenuItem			jmiEditRedo;
    private JMenuItem			jmiEditCut;
    private JMenuItem			jmiEditCopy;
    private JMenuItem			jmiEditPaste;
    private JMenuItem			jmiEditSelectAll;
    private JMenuItem			jmiEditFind;
    private JMenuItem			jmiEditFindAgain;
    private JMenuItem			jmiEditFindAndReplace;
	private JMenuItem			jmiEditPreferences;
	public JMenu			  jmBrick;
	private JMenuItem		    jmiBrickDownload;
	private JMenuItem		    jmiBrickBeep;
	public JMenuItem			jmiBrickServer;
	public JMenuItem			jmiBrickRemote;
	private JMenu			  jmHelp;
	private JMenuItem			jmiHelpCricket;
	private JMenuItem			jmiHelpCmdRef;
	private JMenuItem			jmiHelpLangRef;
	private JMenuItem			jmiHelpSkins;
	private JMenuItem			jmiHelpICricket;
	private JMenuItem			jmiHelpUpdateLib;
	private JMenuItem			jmiHelpViewLib;
	private JMenuItem			jmiHelpAbout;
	private JMenuItem			jmiHelpPostcardware;
	private JMenuItem			jmiHelpWebpage;

	private Jackal parent;

	public JackalMenuBar(Jackal par,UndoAction undoAction, RedoAction redoAction){
		super();
		parent = par;
		populateMenus(undoAction,redoAction);
		if (isMac) registerMRJHandlers();
	}

	/**
	 * Build the menus for this application
	 */
    private void populateMenus(UndoAction undoAction, RedoAction redoAction){
	  	//FILE menu *************************************************
		jmFile = new JMenu("File");						//jmFile
		if(!isMac) jmFile.setMnemonic(KeyEvent.VK_F);
		this.add(jmFile);
		jmiFileNew = new JMenuItem("New");				//	jmiFileNew
		if(!isMac) jmiFileNew.setMnemonic(KeyEvent.VK_N);
		jmiFileNew.addActionListener(this);
		jmiFileNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,OS_KEY_MASK));
		jmFile.add(jmiFileNew);
		jmiFileOpen = new JMenuItem("Open");			//	jmiFileOpen
		if(!isMac) jmiFileOpen.setMnemonic(KeyEvent.VK_O);
		jmiFileOpen.addActionListener(this);
		jmiFileOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,OS_KEY_MASK));
		jmFile.add(jmiFileOpen);
		jmiFileSave = new JMenuItem("Save");			//	jmiFileSave
		if(!isMac) jmiFileSave.setMnemonic(KeyEvent.VK_S);
		jmiFileSave.addActionListener(this);
		jmiFileSave.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,OS_KEY_MASK));
		jmFile.add(jmiFileSave);
		jmiFileSaveAs = new JMenuItem("Save As");		//	jmiFileSaveAs
		if(!isMac) jmiFileSaveAs.setMnemonic(KeyEvent.VK_A);
		jmiFileSaveAs.addActionListener(this);
		//jmiFileSaveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,OS_KEY_MASK & ActionEvent.SHIFT_MASK));
		jmFile.add(jmiFileSaveAs);
		jmFile.addSeparator();
		jmiFilePrint = new JMenuItem("Print");			//	jmiFilePrint
		if(!isMac) jmiFilePrint.setMnemonic(KeyEvent.VK_P);
		jmiFilePrint.addActionListener(this);
		jmiFilePrint.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,OS_KEY_MASK));
		jmFile.add(jmiFilePrint);
		if(!isMacOSX) jmFile.addSeparator();
		jmiFileQuit = new JMenuItem("Exit");			//	jmiFileQuit
		if(!isMac) jmiFileQuit.setMnemonic(KeyEvent.VK_X);
		jmiFileQuit.addActionListener(this);
		jmiFileQuit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,OS_KEY_MASK));
		if(!isMacOSX) jmFile.add(jmiFileQuit);
	  	//EDIT menu *************************************************
		jmEdit = new JMenu("Edit");						//jmEdit
		if(!isMac) jmEdit.setMnemonic(KeyEvent.VK_E);
		this.add(jmEdit);
		//add various editing actions...
		if(isMacClassic){	// init(Acton) was added in Java 1.3
			jmEdit.add(undoAction);
			jmEdit.add(redoAction);
		} else {
			jmiEditUndo = new JMenuItem(undoAction);
			if(!isMac) jmiEditUndo.setMnemonic(KeyEvent.VK_U);
			jmiEditUndo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,OS_KEY_MASK));
			jmEdit.add(jmiEditUndo);
			jmiEditRedo = new JMenuItem(redoAction);
			if(!isMac) jmiEditRedo.setMnemonic(KeyEvent.VK_R);
			jmiEditRedo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,OS_KEY_MASK));
			jmEdit.add(jmiEditRedo);
		}
		jmEdit.addSeparator();			//Mnemonics are already there!
		//jmiEditCut = new JMenuItem(parent.getActionByName(DefaultEditorKit.cutAction));
		//jmiEditCut.setText("Cut");
		jmiEditCut = new JMenuItem("Cut");
		if(!isMac) jmiEditCut.setMnemonic(KeyEvent.VK_T);
		jmiEditCut.addActionListener(this);
		jmiEditCut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,OS_KEY_MASK));
		jmEdit.add(jmiEditCut);		
		//jmiEditCopy = new JMenuItem(parent.getActionByName(DefaultEditorKit.copyAction));
		//jmiEditCopy.setText("Copy");
		jmiEditCopy = new JMenuItem("Copy");
		if(!isMac) jmiEditCopy.setMnemonic(KeyEvent.VK_C);
		jmiEditCopy.addActionListener(this);
		jmiEditCopy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,OS_KEY_MASK));
		jmEdit.add(jmiEditCopy);				
		//jmiEditPaste = new JMenuItem(parent.getActionByName(DefaultEditorKit.pasteAction));
		//jmiEditPaste.setText("Paste");
		jmiEditPaste = new JMenuItem("Paste");
		if(!isMac) jmiEditPaste.setMnemonic(KeyEvent.VK_V);
		jmiEditPaste.addActionListener(this);
		jmiEditPaste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,OS_KEY_MASK));
		jmEdit.add(jmiEditPaste);		
		jmiEditSelectAll = new JMenuItem("Select All");
		if(!isMac) jmiEditSelectAll.setMnemonic(KeyEvent.VK_A);
		jmiEditSelectAll.addActionListener(this);
		jmiEditSelectAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,OS_KEY_MASK));
		jmEdit.add(jmiEditSelectAll);
		//and now a separator
		//jmEdit.addSeparator();
		//jmEdit.add(parent.getActionByName(DefaultEditorKit.selectAllAction));
		//jmEdit.addSeparator();
		jmiEditFind = new JMenuItem("Find");//jmEditFind
		if(!isMac) jmiEditFind.setMnemonic(KeyEvent.VK_F);
		jmiEditFind.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F,OS_KEY_MASK));
		jmiEditFind.addActionListener(this);
		//jmEdit.add(jmiEditFind);
		jmiEditFindAgain = new JMenuItem("Find Again");//jmEditFind
		if(!isMac) jmiEditFindAgain.setMnemonic(KeyEvent.VK_G);
		jmiEditFindAgain.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G,OS_KEY_MASK));
		jmiEditFindAgain.addActionListener(this);
		//jmEdit.add(jmiEditFindAgain);
		jmiEditFindAndReplace = new JMenuItem("Find And Replace");//jmEditFind
		if(!isMac) jmiEditFindAndReplace.setMnemonic(KeyEvent.VK_R);
		jmiEditFindAndReplace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,OS_KEY_MASK));
		jmiEditFindAndReplace.addActionListener(this);
		//jmEdit.add(jmiEditFindAndReplace);
		if(!isMacOSX) jmEdit.addSeparator();
		jmiEditPreferences = new JMenuItem("Preferences");//jmEditPreferences
		if(!isMac) jmiEditPreferences.setMnemonic(KeyEvent.VK_P);
		jmiEditPreferences.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_SEMICOLON,OS_KEY_MASK));
		jmiEditPreferences.addActionListener(this);
		if(!isMacOSX) jmEdit.add(jmiEditPreferences);
	  	//BRICK menu *************************************************
		jmBrick = new JMenu("Handy Cricket");
		if(!isMac) jmBrick.setMnemonic(KeyEvent.VK_C);
		this.add(jmBrick);
		jmiBrickDownload = new JMenuItem("Download");	//	jmiBrickDownload
		if(!isMac) jmiBrickDownload.setMnemonic(KeyEvent.VK_D);
		jmiBrickDownload.addActionListener(this);
		jmiBrickDownload.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,OS_KEY_MASK));
		jmBrick.add(jmiBrickDownload);
		jmiBrickBeep = new JMenuItem("Beep");			//	jmiBrickBeep
		if(!isMac) jmiBrickBeep.setMnemonic(KeyEvent.VK_B);
		jmiBrickBeep.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B,OS_KEY_MASK));
		jmiBrickBeep.addActionListener(this);
		jmBrick.add(jmiBrickBeep);
		jmBrick.addSeparator();
		jmiBrickServer = new JMenuItem("Become Server");		//jmiBrickServer
		if(!isMac) jmiBrickServer.setMnemonic(KeyEvent.VK_S);
		jmiBrickServer.addActionListener(this);
		jmBrick.add(jmiBrickServer);
		jmiBrickRemote = new JMenuItem("Connect to iCricket");	//jmiBrickRemote
		if(!isMac) jmiBrickRemote.setMnemonic(KeyEvent.VK_R);
		jmiBrickRemote.addActionListener(this);
		jmBrick.add(jmiBrickRemote);
	  	//HELP menu *************************************************
		jmHelp = new JMenu("Help");						//jmHelp
		jmiHelpCricket = new JMenuItem("See the Cricket");	//jmiHelpCricket
		if(!isMac) jmiHelpCricket.setMnemonic(KeyEvent.VK_C);
		jmiHelpCricket.addActionListener(this);
		jmHelp.add(jmiHelpCricket);
		if(!isMac) jmHelp.setMnemonic(KeyEvent.VK_H);
		this.add(jmHelp);
		jmiHelpCmdRef = new JMenuItem("Logo Reference");//jmiHelpCmdRef
		if(!isMac) jmiHelpCmdRef.setMnemonic(KeyEvent.VK_R);
		jmiHelpCmdRef.addActionListener(this);
		jmHelp.add(jmiHelpCmdRef);
		jmiHelpLangRef = new JMenuItem("Translation Reference");//jmiHelpLangRef
		if(!isMac) jmiHelpLangRef.setMnemonic(KeyEvent.VK_L);
		jmiHelpLangRef.addActionListener(this);
		jmHelp.add(jmiHelpLangRef);
		jmiHelpSkins = new JMenuItem("How to Make a Skin");		//	jmiHelpSkins
		if(!isMac) jmiHelpSkins.setMnemonic(KeyEvent.VK_I);
		jmiHelpSkins.addActionListener(this);
		jmHelp.add(jmiHelpSkins);
		jmiHelpICricket = new JMenuItem("What's an iCricket?");	//	jmiHelpICricket
		if(!isMac) jmiHelpICricket.setMnemonic(KeyEvent.VK_I);
		jmiHelpICricket.addActionListener(this);
		jmHelp.add(jmiHelpICricket);
		jmHelp.addSeparator();
		jmiHelpViewLib = new JMenuItem("View Library File");//	jmiHelpViewLib
		if(!isMac) jmiHelpViewLib.setMnemonic(KeyEvent.VK_L);
		jmiHelpViewLib.addActionListener(this);
		jmHelp.add(jmiHelpViewLib);
		jmiHelpUpdateLib = new JMenuItem("Update Library File");//	jmiHelpUpdateLib
		if(!isMac) jmiHelpUpdateLib.setMnemonic(KeyEvent.VK_L);
		jmiHelpUpdateLib.addActionListener(this);
		jmHelp.add(jmiHelpUpdateLib);
		jmHelp.addSeparator();
		jmiHelpAbout = new JMenuItem("About");		//jmiHelpAbout
		if(!isMac) jmiHelpAbout.setMnemonic(KeyEvent.VK_B);
		jmiHelpAbout.addActionListener(this);
		if(!isMacOSX) jmHelp.add(jmiHelpAbout);
		jmiHelpPostcardware = new JMenuItem("Postcardware");	//jmiHelpPostcardware
		if(!isMac) jmiHelpPostcardware.setMnemonic(KeyEvent.VK_P);
		jmiHelpPostcardware.addActionListener(this);
		jmHelp.add(jmiHelpPostcardware);
		jmiHelpWebpage = new JMenuItem("Visit Webpage");	//jmiHelpWebpage
		if(!isMac) jmiHelpWebpage.setMnemonic(KeyEvent.VK_W);
		jmiHelpWebpage.addActionListener(this);
		jmHelp.add(jmiHelpWebpage);
    }

    /**
     * Rename all the menus from a file. Spanish = "es", English = "en",
     * Portuguese = "pr".  This should only be called at startup. 
     */
    public void renameMenus(String localeLang){
        PropertyResourceBundle localLabels = null;
        try{
			InputStream tempIS = FileUtilities.getInputStreamFromResource(
            		"GUIBundle_"+localeLang+".properties"
            		);
            localLabels = new PropertyResourceBundle(tempIS);
            rename(localLabels);
        } catch (Exception e){
            output(e+" - Local Bundle not found for \"GUIBundle_"+localeLang+".properties\"!");
            //handleError("No local language version found, defaulting to English.");
        }
    }

	/**
	 * Rename the menu items based on the locale-specific bundle passed in
	 *	@param	labels	the local resource bundle
	 */
	private void rename(ResourceBundle labels){
		try{
        if(labels==null) return;
        jmFile.setText( labels.getString("file") );
        jmiFileNew.setText( labels.getString("new") );
        jmiFileOpen.setText( labels.getString("open") );
        jmiFileSave.setText( labels.getString("save") );
        jmiFileSaveAs.setText( labels.getString("saveAs") );
        jmiFilePrint.setText( labels.getString("print") );
		jmiFileQuit.setText( labels.getString("exit") );
		jmEdit.setText( labels.getString("edit") );
		//on mac classic these aren't initialized
		if(!isMacClassic) jmiEditUndo.setText( labels.getString("undo") );
		if(!isMacClassic) jmiEditRedo.setText( labels.getString("redo") );
        jmiEditCut.setText( labels.getString("cut") );
		jmiEditCopy.setText( labels.getString("copy") );
		jmiEditPaste.setText( labels.getString("paste") );
		jmiEditSelectAll.setText( labels.getString("selectAll") );        
        jmiEditFind.setText( labels.getString("find") );
        jmiEditFindAgain.setText( labels.getString("findAgain") );
        jmiEditFindAndReplace.setText( labels.getString("findAndReplace") );
        jmiEditPreferences.setText( labels.getString("preferences") );
        jmBrick.setText( labels.getString("brick") );
        jmiBrickDownload.setText( labels.getString("download") );
        jmiBrickBeep.setText( labels.getString("beep") );
        jmiBrickServer.setText( labels.getString("becomeServer") );
        jmiBrickRemote.setText( labels.getString("connectToServer") );
        jmHelp.setText( labels.getString("help") );
		jmiHelpCricket.setText( labels.getString("seeCricket") );
        jmiHelpCmdRef.setText( labels.getString("logoReference") );
        jmiHelpLangRef.setText( labels.getString("translationReference") );
        jmiHelpSkins.setText( labels.getString("howToMakeASkin") );
        jmiHelpICricket.setText( labels.getString("whatsAniCricket") );
        jmiHelpViewLib.setText( labels.getString("viewLibraryFile") );
        jmiHelpUpdateLib.setText( labels.getString("updateLibraryFile") );	
		jmiHelpAbout.setText( labels.getString("about") );
		jmiHelpPostcardware.setText( labels.getString("postcardware") );
		jmiHelpWebpage.setText( labels.getString("visitWebpage") );
        } catch (Exception e){
        	e.printStackTrace();
        }
	}

	/**
	 * Menu Handler, invokes almost all actions on the Jackal parent
	 */
	public void actionPerformed(java.awt.event.ActionEvent event){
		Object object = event.getSource();
		if(object == jmiFileQuit) { parent.fileQuit();						//Quit
		} else if (object == jmiFileNew){ parent.fileNew();					//New
		} else if (object == jmiFileOpen){ parent.fileOpen();				//Open
		} else if (object == jmiFileSave){ parent.fileSave();				//Save
		} else if (object == jmiFileSaveAs){ parent.fileSaveAs();			//SaveAs
        } else if (object == jmiFilePrint) { parent.print();				//Print
        } else if (object == jmiEditCut) { parent.cut();					//Cut
        } else if (object == jmiEditCopy) { parent.copy();					//Copy
        } else if (object == jmiEditPaste) { parent.paste();				//Paste
        } else if (object == jmiEditSelectAll) { parent.selectAll();		//Select All
        } else if (object == jmiEditFind) { parent.find();					//Find
        } else if (object == jmiEditFindAgain) { parent.findAgain();		//Find Again
        } else if (object == jmiEditFindAndReplace) { parent.findAndReplace();	//Find And Replace
		} else if (object == jmiEditPreferences){ parent.showPrefsDialog();	//Preferences
		} else if (object == jmiBrickDownload){ parent.brickDownload();		//Download
		} else if (object == jmiBrickBeep){ parent.brickRun("beep");		//Beep
		} else if (object == jmiBrickServer){ parent.cricketServer();		//Server
		} else if (object == jmiBrickRemote){ parent.cricketRemote();		//Remote
		} else if (object == jmiHelpCmdRef){ parent.helpCommandRef();		//Command Reference
		} else if (object == jmiHelpLangRef){ 			//Translation Reference
			TableViewerFrame viewer =
				new TableViewerFrame("Languages",Translator.getLanguageTable());
		} else if (object == jmiHelpSkins){ parent.showHTMLWin("SkinsHowTo.html");	//Skins
		} else if (object == jmiHelpICricket){ parent.showHTMLWin("iBrick.html");	//iCricket
		} else if (object == jmiHelpUpdateLib){ parent.updateLib();			//Update Library
		} else if (object == jmiHelpViewLib){ parent.showProcDefs();		//View Library
		} else if (object == jmiHelpAbout){ handleAbout();					//About
		} else if (object == jmiHelpCricket){
			ImageViewerFrame imgView = new ImageViewerFrame("hc15.jpg",true);
		} else if (object == jmiHelpPostcardware){							//Postcardware
			AboutDialog.showPostcardware(parent); 
		} else if (object == jmiHelpWebpage){								 //Webpage
			try{
				BrowserLauncher.openURL(HOMEPAGE_URL);
			} catch (IOException ioe){
				Alerts.showError("Error",
					"Sorry, an error occured while trying to start\n"+
					"your web browser.");
			}
		}
	}

/******************************************************************************
 **		MAC HANDLING
 ******************************************************************************/
	
	public void registerMRJHandlers(){
		MRJApplicationUtils.registerAboutHandler(this);
		MRJApplicationUtils.registerQuitHandler(this);
		if(!isMacClassic)	//doesn't exit on Mac Classic
			MRJApplicationUtils.registerPrefsHandler(this);
	}

	/**
	 * Handles the Max OSX Quit event - close the application
	 */
	public void handleQuit(){
		if(!alreadyQuitting){
			alreadyQuitting = true;
			parent.fileQuit();
		}
	}
	/**
	 * Handles the Max OSX About event - pops up the about box
	 */
	public void handleAbout(){
		//show an about box
		AboutDialog myAbout = new AboutDialog(
			parent,"      Jackal      ",VERSION,HOMEPAGE_URL,
			ImageUtilities.getImageIconFromResource("jackal-icon.gif") );
	}
	/**
	 * Handles the Max OSX Preferences event - pops up the preference window
	 */
	public void handlePrefs(){
		parent.showPrefsDialog();
	}

	/**
	 * for debugging...
	 */
	public void output(String msg){
		if (DEBUG) System.out.println("JackalMenuBar: "+msg);
	}


}