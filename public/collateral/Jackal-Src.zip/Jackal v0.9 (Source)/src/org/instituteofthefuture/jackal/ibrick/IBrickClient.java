package org.instituteofthefuture.jackal.ibrick;

import java.io.*;
import java.net.*;
import java.util.*;				//for Vector
import javax.swing.JTextArea;

import org.instituteofthefuture.jackal.Jackal;

/**
 * <p>this is now just an interface to the cricket, use methods to start</p>
 *	<ul>
 *	<li>2002.01.17 - adding iTalk abilities
 *	<li>2001.09.01 - adapting for use in Jackel, removed file list transfer
 *		on login and dumb outputting stuff and par
 *	<li>2000.12.03 - added userName field and changed IKMs to use it,
 *		added file list transfer on login, save functionality, added par
 *	<li>2000.11.30 - made uppercase
 *	</ul>
 *
 * @see org.instituteofthefuture.jackal.ibrick.IBrickMessage
 * @see org.instituteofthefuture.jackal.ibrick.IBrickServer
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class IBrickClient {
	public static boolean DEBUG = false;	
	public String defaultUserName = "";
	public String defaultServerAddress = "";

	private Jackal par;
	private Socket serverSocket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private String userName;

	private boolean connected = false;
	
	public IBrickClient(Jackal p){
		par = p;
	}

	//-------------------------------------------------- COMM CONTROL
	/**
	 * throws exception if it fails to connect
	 * returns false if someone else has control
	 */
	public boolean connOpen(String un,String hostName) throws Exception
	{
		IBrickMessage icm;
		userName = un;
		output(un+" Trying to connect to server....\n");
		//open connection to host
		serverSocket = new Socket(hostName,IBrickMessage.PORT);
		output("Opened socket to server...");
		out = new ObjectOutputStream(serverSocket.getOutputStream());
		in = new ObjectInputStream(serverSocket.getInputStream());
		output ("made streams...");
		icmLogin();
		output ("sent login....");
		if (blockForMsg().getType()==IBrickMessage.MSG_LOGOUT) return false;
		connected = true;
		return true;
	}

	private IBrickMessage blockForMsg(){			//blocking
		Object temp;
		IBrickMessage icm = null;
		try{ 
			System.out.print("waiting for a message...");
			temp = in.readObject();
			icm = (IBrickMessage) temp;
			System.out.println("__got it! ("+icm.getType()+")");
		} catch (java.io.EOFException eofe) {
			output(" blockForMsg : got eof!");
			connected = false;
			par.setRemoteInterface(false);
			par.handleError("Sorry, it looks like the server went down!");
			return null;
		} catch (Exception e) { output("blockForMsg : " + e); }
		return icm;
	}

	public void connClose() {
		icmLogout();
		try{
			out.flush();
			out.close();
			out = null;
			serverSocket.close();
			connected = false;
		} catch (Exception e) {output(" connClose: "+e);}
	}

	//--------------------------------------------------- DEBUGGING
	private void output(String msg){
		if(DEBUG) System.out.println("IBrickClient : "+msg);
	}

	//--------------------------------------------------- COMMUNICATION

	//don't call these directly
	private void icmLogin() { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_LOGIN,userName,"please let me login!") ); }
	private void icmLogout() { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_LOGOUT,userName,"please let me logout!") ); }
	private void icmOK() { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_OK,userName) ); }
	private void icmDownload(String toRun,String code) { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_PROC,userName,toRun,code) ); }
	private void icmRun(String code) { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_RUN,userName,code ) ); }
    private void icmByte(int num) { dispatchCommand( new IBrickMessage(IBrickMessage.MSG_BYTE,userName,num) ); }

	/** use this to run code from the command center */
	public void run(String code) throws Exception{
		try{
			icmRun(code);
			handleServerResponse();
		} catch (Exception e){
			output(" run : "+e.toString());
			par.handleError(e.toString());
		}
	}

	/** use this to download a program */
	public void download(String toRun, String code) throws Exception{
		icmDownload(toRun,code);
		handleServerResponse();
	}
	
	private void handleServerResponse() throws Exception{
		IBrickMessage icm = blockForMsg();
		if(icm.getType() == IBrickMessage.MSG_OK) return;
		if (icm.getType() == IBrickMessage.MSG_LOGOUT) {			//the server stopped!
			par.setRemoteInterface(false);
			connected = false;
		}
		throw new Exception(icm.getMsg());	//probably a parse error
	}

	/**
	 *This is the low-level communication function that handles all messages
	 *	sent to the server
	 */
	private void dispatchCommand(IBrickMessage msg){
	    output("dispatchCommand : Sending a message of type "+msg.getType());
	    if (out != null) {
	    	try{
	      		out.writeObject(msg);
	      		out.flush();
			} catch (Exception e) {output("dispatchCommand: "+e); }
	    }
	}

	//------------------------------------------------------- UTILITY
	private void sleep(int time){
		try{
			Thread.sleep(time);
		} catch (Exception e) { System.out.println(e); return;}
	}

	public boolean connected(){
		return connected;
	}

}
