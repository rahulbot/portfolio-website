package org.instituteofthefuture.jackal.ibrick;

import java.awt.*;
import java.net.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.Color;

import org.instituteofthefuture.jackal.BrickManager;

/** 
 * <p>Popup to show status of IBrick Server</p>
 * 	<ul>
 *	<li>2002.11.20 - made standard java interface, moved to ibrick
 *	<li>2001.10.15 - changed to use a BrickManager
 *	<li>2001.09.04 - fixed to be sized right on a pc - ugh!
 *  <li>2001.09.02 - cleaning up ModalJDialog and redoing for jackel
 *	<li>2000.12.02 - works :-)
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */ 
public class IBrickServerDialog extends JDialog implements ActionListener {
	public static final boolean DEBUG = false;
	
	//brick stuff
	IBrickServer myServer;
	Thread myServerThread;
	
	//interface components
	JFrame			par;
	JTextField		jtfAddress;
	JTextField		jtfStatus;
	JTextPane		jtpMsgs;
	JScrollPane		jspMsgs;
	
	//interface helpers
	private int myWidth = 485;
	private int myHeight = 345;

	public IBrickServerDialog(JFrame f,BrickManager bm){
		super(f,true);
		this.par = f;
		populate();
		IBrickServer myServer = new IBrickServer(bm,jtpMsgs,jtfStatus);
		myServerThread = new Thread(myServer);
		myServerThread.start();
		//if(myServer == null) output("stopServer : MYSERVER is NULL!");
		//else output("stopServer : MYSERVER is NULL!");
		this.setVisible(true);
	}

	public void populate(){
		output("populating");
		Container cp = getContentPane();	
		cp.setLayout(null);
		JLabel label;	//for created labels
		//the header text
		label = new JLabel("Start an iBrick server",JLabel.CENTER);
		label.setFont(new Font("SansSerif", Font.PLAIN, 20));
		label.setBounds(0,3,myWidth,40);
		cp.add(label);
		//the address label
		label = new JLabel("My Address >",JLabel.RIGHT);
		label.setFont(new Font("SansSerif", Font.PLAIN, 12));
		label.setBounds(0,50,130,23);
		cp.add(label);
		//the address text field
		jtfAddress = new javax.swing.JTextField();
		jtfAddress.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jtfAddress.setOpaque(false);
		jtfAddress.setBorder(BorderFactory.createEmptyBorder());
		jtfAddress.setBounds(135,50,320,23);
		jtfAddress.setEditable(false);
		try{ jtfAddress.setText( java.net.InetAddress.getLocalHost().toString() );
		} catch (UnknownHostException uhe) { output(uhe.toString()); }
		cp.add(jtfAddress);
		//the status label
		label = new JLabel("Server Status >",JLabel.RIGHT);
		label.setFont(new Font("SansSerif", Font.PLAIN, 12));
		label.setBounds(0,84,130,23);
		cp.add(label);
		//the status field
		jtfStatus = new javax.swing.JTextField();
		jtfStatus.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jtfStatus.setBorder(BorderFactory.createEmptyBorder());
		jtfStatus.setOpaque(false);
		jtfStatus.setBounds(135,84,320,23);
		jtfStatus.setEditable(false);
		cp.add(jtfStatus);
		//the messages label
		label = new JLabel("Server Info >",JLabel.RIGHT);
		label.setFont(new Font("SansSerif", Font.PLAIN, 12));
		label.setBounds(0,114,130,23);
		cp.add(label);
		//the messages text field
		jtpMsgs = new javax.swing.JTextPane();
		jtpMsgs.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jtpMsgs.setOpaque(false);
		jtpMsgs.setEditable(false);
		jspMsgs = new javax.swing.JScrollPane(jtpMsgs);
		jspMsgs.setBorder(BorderFactory.createEmptyBorder());
		jspMsgs.setBounds(135,114,320,150);
		cp.add(jspMsgs);
		//the server button
		JButton jbuttStopServer = new JButton("Stop Server");
		jbuttStopServer.setBounds(308,280,150,30);
		jbuttStopServer.addActionListener(this);
		cp.add(jbuttStopServer);
		//finish setting up the dialog
		setBounds(30,30,myWidth,myHeight);
		this.setResizable(false);
	}

	/**
	 * Handles all the buttons
	 */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			if( ((JButton)obj).getText().equals("Stop Server") ){
				stopServer();
			} else if ( ((JButton)obj).getText().equals("Start Server") ){
				//cancel();
			}
		}
	}

	/**
	 * kill the server and close the dialog
	 */
	void stopServer() {
		output("stopServer : trying to kill the server!");
		try{
			myServerThread.stop();
			this.dispose();
		} catch (Exception e) {
			output("stopServer : "+e.toString());
		}
	}
	
	/**
	 * for debugging
	 */
	public void output(String msg){
		if (DEBUG) System.out.println("IBrickServerDialog: "+msg);
	}

	/**
	 * for testing
	 */
	public static void main(String args[]){
		IBrickServerDialog d = new IBrickServerDialog(null,null);
	}

}
