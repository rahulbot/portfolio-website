package org.instituteofthefuture.jackal.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import org.instituteofthefuture.gui.GUIUtilities;
import org.instituteofthefuture.gui.Alerts;
import org.instituteofthefuture.jackal.*;

/**
 * <p>Pops up while download, auto disapears.
 *	Stores any errors into the errors string, null is success.</p>
 *  <ul>
 *	<li>2002.11.28 - created
 *	</ul>
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class DownloadDialog extends JDialog {
	public String errors = null;

	public DownloadDialog(Jackal j) {
		super(j, true);
		this.setTitle("Downloading...");
		JLabel head = new JLabel("Downloading...",JLabel.CENTER);
		head.setFont(new Font("SansSerif",Font.PLAIN,24));
		//finish making the panel
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(head,BorderLayout.CENTER);
		//this.getContentPane().add(notes);
		GUIUtilities.setDialogSize(this,300,100);
		setResizable(false);
		DLThread dlt= new DLThread(j);
		dlt.start();
		this.show();
	}

	class DLThread extends Thread {
		Jackal j;
			
		DLThread(Jackal parent){
			this.j= parent;
		}
	
		public void run(){
			try{
				j.reallyDownload();
			} catch (Exception e){
				errors = e.toString();
			}
			dispose();
		}
	}

}
