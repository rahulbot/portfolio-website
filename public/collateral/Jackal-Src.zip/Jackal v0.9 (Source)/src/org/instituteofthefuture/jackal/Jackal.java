package org.instituteofthefuture.jackal;
 
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import javax.swing.undo.*;

//the Institute of the Future standard libraries
import org.instituteofthefuture.*;
import org.instituteofthefuture.gui.*;
import org.instituteofthefuture.io.*;

//the various Jackal support classes
import org.instituteofthefuture.jackal.gui.*;
import org.instituteofthefuture.jackal.ibrick.*;
import org.instituteofthefuture.jackal.logoutils.*;

//Fred's compiler, made into a BrickManager
import com.handyboard.cricket.*;

//JEdit syntax highlighting package - fantastic
import org.syntax.jedit.*;
import org.syntax.jedit.tokenmarker.*;

//MacOS specific functions
import com.apple.mrj.*;

/**
 * <b>Jackal 0.9</b>
 * <p>
 *	Bugs:<ul>
 *	<li>BrowserLauncher sometimes crashes on Mac Classic
 *	<li>if no serial ports found, preferences dialog looks funny
 *	<li>dynamic libraries can't work from command center
 *	<li>stop IBrick server doesn't finalize on a PC! :-(
 *	<li>if you name a procedure the same as a library funtion, it won't work!
 *	</ul>
 * To Do:<ul>
 *	<li>add highlighting to command center - 2 JEditTextAreas mirror each other :-(
 *	<li>save dialog should default to name of first procedure
 *	<li>add preference to defualt to the last program edited on startup
 *	<li>add preference to always download library file
 *	<li>add sound on download and error
 *	<li>find and replace
 *	</ul>
 * </p>
 * <p>
 * <i>Change Log</i>
 *	<ul>
 *	<li>2002.11.26 - works on Mac Classic, added download popup,
 *		fixed translation file
 *	<li>2002.11.25 - fixed serialcomm timeout on PC and ask to
 *		save on exit, added to preferences
 *	<li>2002.11.24 - changed prefs and skin.txt to properties file,
 *		added aqua interface
 *	<li>2002.11.23 - works with HandyCricket (it beeps!),
 *		fixed jlDownload and jlMonitor, moved support files into jar
 *	<li>2002.11.23 - added more MRJ support (Jakl/JKlg)
 *	<li>2002.11.22 - lots of commenting, added status field for feedback
 *	<li>2002.11.20 - integrated Fred's HandyCricket compiler, to test
 *	<li>2002.11.19 - integrated Institute of the Future java libraries
 *	<li>2002.11.17 - started major overhaul for Jackal v2.0!
 *	</ul>
 * </p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class Jackal extends JFrame implements 
			IFConstants, IBrickManager, JackalConstants,
			MRJOpenApplicationHandler,MRJOpenDocumentHandler,
			MRJPrintDocumentHandler, MouseListener{

	public static boolean DEBUG = false;

	//for the copy/cut/paste/undo stuff
	Hashtable actions;
	protected UndoAction undoAction;
	protected RedoAction redoAction;
	protected UndoManager undoManager = new UndoManager();

	/** 
	 * holds the number of characters in the last program saved,
	 * used to check and see if changes have been made
	 */
	private int lastProgramLength;
	/** the language I'm in currently */
	public String language;
	/** the language to load next time */
	public String nextLanguage;
	/** everything to the brick goes through this interface */
	public BrickManager myBrick;
	/** for using skins */
	public InterfaceBuilder myInterfaceBuilder;
	/** for smart downloading of procedures */
	public ProcedureReader procLibrary;
	/** for controlling a remote cricket */
	private IBrickClient myICClient;
    /** reset to null on new, open, save, save as */
    private File currFile = null;
    /** tells which type of BrickManager to use, set from the command line */
	public static int BRICK_TYPE = HANDY_CRICKET;
    /** the syntax highlighter to user */
	private LogoTokenMarker myTokenMarker,myOtherTokenMarker;
    /** for updating the monitor with any data the brick sends back */
	private MonitorThread myMonitor;

	/** the panel that the skin goes onto */
	private JPanel interfacePanel;
    /** the background image */
	private JImagePanel			jipBgImage;
    /** where users type procedures */
	public JEditTextArea		jtpProcedures;
    /** the command center */
	private JTextArea 		jtpCommand;
    /** the command center */
	private JScrollPane 		jspCommand;
    /** the run this area */
	private JTextField 			jtfRun;
    /** the download button, this has to be a label to be see-through on OSX! 
     *	(Radar #2869569?)
     */
	private JLabel				jlDownload;
    /** the monitor button, not used currently */
	private JLabel				jlMonitor;
    /** the menu bar */
	private JackalMenuBar		jmbMenus;
    /** the status field, for feedback to the user */
	private static JTextField		jtfStatus;

/******************************************************************************
 **		INITIALIZATION
 ******************************************************************************/

	/** do everything! */
	public Jackal(int bID){
		super("Jackal");
		GUIUtilities.setNativeLookAndFeel();
		if(isMac) setupForMacOS();		//add file codes and listeners
		Alerts.setParent(this);			//for future alert dialogs...
		BRICK_TYPE = bID;		
		//setup the interface
		//buildInterfaceItems(interfacePanel);
		this.setResizable(false);
		this.getContentPane().setLayout(new BorderLayout());
		//register a window closing listeners
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		//set up the main interface panel to populate
		interfacePanel = new JPanel();
		interfacePanel.setLayout(null);
		//load up the preferences
		JackalPreferences.load();
		//start up the translator
		language = JackalPreferences.getLanguage();
		nextLanguage = JackalPreferences.getLanguage();
		Translator.init(FileUtilities.getBufferedReaderFromResource("languages.txt"));
		Translator.setLanguages(Translator.eng,Translator.getIdentifier(language));
		output("Jackal - translator setup");
		//create this to simplify life when setting my own key-bindings...
		createActionTable(new JTextPane());
		//set up the static interactive interface items
		jipBgImage = new JImagePanel();								//Background Image
		jlMonitor = new javax.swing.JLabel("...");					//Monitor
		jlMonitor.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jlMonitor.setVerticalAlignment(JLabel.CENTER);
		jlMonitor.setHorizontalAlignment(JLabel.CENTER);
		jlMonitor.addMouseListener(this);
		//jlMonitor.setBorder(BorderFactory.createEmptyBorder());
		//jlMonitor.setOpaque(false);
		jtfRun = new javax.swing.JTextField();						//Run This Field
		jtfRun.setFont(new Font("SansSerif", Font.PLAIN, 14));
		jtfRun.setBorder(BorderFactory.createEmptyBorder());
		//jlDownload = new JButton("b");
		jlDownload = new JLabel("");
		//jlDownload.setOpaque(true);
		//jlDownload.addActionListener(this);
		jlDownload.addMouseListener(this);
		//jlDownload.setBorder(BorderFactory.createEmptyBorder());
		//jtpCommand = new javax.swing.JTextArea();					//Command Center Area
		jtpCommand = new JTextArea();							//Command Center Area
		jtpCommand.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jtpCommand.addKeyListener(new EnterListener());
		jtpCommand.setText(EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL+EOL);
		jspCommand = new javax.swing.JScrollPane(jtpCommand);
		jspCommand.setBorder(BorderFactory.createEmptyBorder());
        jtpProcedures = new JEditTextArea();						//Procedures Area
        //and set the font from the preferences
        jtpProcedures.getPainter().setFont( JackalPreferences.getFont() );
		//setup the jedit syntax highlighting to the correct keywords config file
		switch(BRICK_TYPE){
			case HANDY_CRICKET:
				myTokenMarker = new LogoTokenMarker("syntax-coloring.txt");
				myOtherTokenMarker = new LogoTokenMarker("syntax-coloring.txt");
				break;
		}
		jtpProcedures.setTokenMarker(myTokenMarker);
		//jtpCommand.setTokenMarker(myOtherTokenMarker);
		jtfStatus = new JTextField("initializing");
		jtfStatus.setOpaque(false);
		jtfStatus.setEditable(false);
		jtfStatus.setFont(new Font("SansSerif", Font.PLAIN, 10));
		jtfStatus.setForeground( new Color(33,33,33) );
		jtfStatus.setBorder( BorderFactory.createEmptyBorder(5,5,5,5) );
		//set the translator back to translate to english
		Translator.setLanguages(Translator.getIdentifier(language),Translator.eng);
		//create the brick manager based on the value passed in
		switch(BRICK_TYPE){
			case HANDY_CRICKET:
				myBrick = new HandyCricketManager();
				procLibrary = new ProcedureReader(LIBRARY_FILE);
				output("Starting with Handy Cricket");
				this.setTitle("Jackal - Logo for the Handy Cricket");
				break;
			default:
				System.out.println("Invalid brick specified, I'm bailing out!");
				System.exit(0);	
				break;
		}
		myBrick.setSerialPortByName(JackalPreferences.getSerialPort());
        //initialize the menus
		redoAction = new RedoAction(undoManager);
		undoAction = new UndoAction(undoManager);
		redoAction.setUndoAction(undoAction);
		undoAction.setRedoAction(redoAction);
		output("Jackal - about to populateMenus...");
        jmbMenus = new JackalMenuBar(this,undoAction,redoAction);
        jmbMenus.renameMenus(language);				//i18n from the GUI file
        this.setJMenuBar(jmbMenus);
        //System.out.println("file should be = GUIBundle_"+Locale.getDefault().getLanguage()+".properties");
		//set up extra the keystrokes to use
		//addRahulsKeymapBindings(jtpProcedures);	//don't need this anymore?
		//start up the undo edit listeners
		jtpProcedures.getDocument().addUndoableEditListener(new MyUndoableEditListener());
		//jtpCommand.getStyledDocument().addUndoableEditListener(new MyUndoableEditListener());
		jtpCommand.getDocument().addUndoableEditListener(new MyUndoableEditListener());
		//add the keywords to the syntax highlighting
		myTokenMarker.addKeywords(procLibrary.getKeys());
		//start the IBrick services, for brick remote control
		myICClient = new IBrickClient(this);	//for IBrick
		myICClient.defaultUserName = JackalPreferences.getUserName();
		myICClient.defaultServerAddress = JackalPreferences.getServerAddress();
		//put "untitled" in the menu bar
        updateTitleBar();
		//populate the interface...
		myInterfaceBuilder = new InterfaceBuilder();	//used later to load the interface file
		//this if should go away...
		populateInterface( JackalPreferences.getInterface() );
		//set up the new monitor
		myMonitor = new MonitorThread(myBrick,jlMonitor);
		try { myMonitor.setPriority(Thread.MIN_PRIORITY);
		} catch (Exception e) { e.printStackTrace(); }
		myMonitor.start();			//starts off paused
		//add a program for starters...
		fileNew();
		//and now add the items to the main panel
		this.getContentPane().add(interfacePanel,BorderLayout.CENTER);
		this.getContentPane().add(jtfStatus,BorderLayout.SOUTH);
		String bootString = new String("Jackal v"+VERSION+" / ");
		bootString += Translator.getLanguageName(language)+" / ";
		bootString += myInterfaceBuilder.getName()+" / ";
		if(isMacOSX) bootString+="Mac OSX";
		else if(isWindows) bootString+= "Windows";
		else if(isMacClassic) bootString+= "Mac Classic";
		else bootString+= "Unknown OS";
		setStatus(bootString);
	}

    /**
     * Set the brick type and then run Jackal for that brick
     */
	public static void main(String args[]){
		int myBrickID = Jackal.HANDY_CRICKET;
		if(args.length == 1){
			if( args[0].equals("bluecricket") )
				myBrickID = Jackal.BLUE_CRICKET;
			else if( args[0].equals("handycricket") )
				myBrickID = Jackal.HANDY_CRICKET;
			else if( args[0].equals("yellowbrick") )
				myBrickID = Jackal.YELLOW_BRICK;
		}
		JFrame jfMainWindow = new Jackal(myBrickID);
		jfMainWindow.setVisible(true);
	}

/******************************************************************************
 **		EVENT HANDLERS
 ******************************************************************************/

    /** Window handler for closing the window... don't save prefs? */
	class SymWindow extends java.awt.event.WindowAdapter{
		public void windowClosing(java.awt.event.WindowEvent event){
			Object object = event.getSource();
			if (object == Jackal.this){
				setVisible(false);	// hide the Frame
				dispose();			// free the system resources
				System.exit(0);		// close the application
			}
		}
		public void windowActivated(java.awt.event.WindowEvent event){
			super.windowActivated(event);
			//jtpProcedures.requestFocus();
		}
	}
	
    /** Quit the application, saving preferences */
	public void fileQuit(){
		setStatus("Saving preferences and exiting.");
		savePrefs();
		if(askToSave()==JOptionPane.CANCEL_OPTION) return; //if cancel save then cancel quit
		setVisible(false);	// hide the Frame
		dispose();			// free the system resources
		System.exit(0);		// close the application	
	}	
	
    /** Standard cut action */
	public void cut(){
		jtpProcedures.cut();
	}
    /** Standard copy action */
	public void copy(){
		jtpProcedures.copy();
	}
    /** Standard paste action */
	public void paste(){
		jtpProcedures.paste();
	}
    /** Standard select all action */
	public void selectAll(){
		jtpProcedures.selectAll();
	}

	/** Listens for an enter key in the command center */
	public class EnterListener implements KeyListener {
		public void keyTyped(KeyEvent ke) {		}
		public void keyPressed(KeyEvent ke) {
			switch ( ke.getKeyChar() ){
			case KeyEvent.VK_ENTER:
				ke.consume();
				//we only want to run what is on the current line, so parse that out
				int cPos = jtpCommand.getCaretPosition();
				String ccTxt = jtpCommand.getText();
				//this new stuff should work!
				int lastEOL = ccTxt.lastIndexOf(EOL,cPos-2);
				if(lastEOL == -1) lastEOL = -1;
				int nextEOL = ccTxt.indexOf(EOL,cPos);
				if(nextEOL == -1) nextEOL = ccTxt.length()-1;
				ccTxt = ccTxt.substring(lastEOL+1,nextEOL);
				/*
				//ugh, apparently I still need to check for pc vs. mac
				int lastEOL,nextEOL;
				String osName = new String(System.getProperty("os.name"));
				if ((osName.toLowerCase()).indexOf("mac") == -1){
					ccTxt = ccTxt.replace('\r','~');	//change "\r\n" to "~\n")
					lastEOL = ccTxt.lastIndexOf('\n',cPos-2);
					nextEOL = ccTxt.indexOf('~',cPos);
					if(nextEOL == -1) nextEOL = cPos-1;
					ccTxt = ccTxt.substring(lastEOL+1,nextEOL);
					ccTxt = ccTxt.replace('~',' ');
				} else {		//we're on a mac
					lastEOL = ccTxt.lastIndexOf('\r',cPos-2);
					nextEOL = cPos-1;
					ccTxt = ccTxt.substring(lastEOL+1,nextEOL);
				}
				*/
				//now that the text is right, run it
				output("RUN @ ("+(lastEOL+1)+","+(nextEOL)+"): = '"+ccTxt+"'");
				brickRun(ccTxt);
				break;
			}
			return;
		}
		public void keyReleased(KeyEvent ke) { }
	}

	/** listens for edits that have been undone */
	protected class MyUndoableEditListener implements UndoableEditListener {
		public void undoableEditHappened(UndoableEditEvent e) {
			//ignore style changes, this is a total hack!
			if(e.getEdit().toString().indexOf("DefaultStyledDocument")!=-1) return;
			//Remember the edit and update the menus
			undoManager.addEdit(e.getEdit());
			undoAction.updateUndoState();
			redoAction.updateRedoState();
		}
	}

	/** for the download and monitor labels to act like buttons! */
	public void mouseClicked(MouseEvent e){
		if(e.getSource() == jlDownload) {
			brickDownload();
		} else if(e.getSource()==jlMonitor) {
			//don't do anything right now
		}
	}
	/** do nothing */
	public void mouseEntered(MouseEvent e){
	}
	/** do nothing */
	public void mouseExited(MouseEvent e){
	}
	/** do nothing */
	public void mousePressed(MouseEvent e){
	}
	/** do nothing */
	public void mouseReleased(MouseEvent e){
	}

/******************************************************************************
 **		MACOS HELPERS
 ******************************************************************************/

	/** set up the open file and app handlers, and the prefs location(?) */
	public void setupForMacOS(){
		MRJApplicationUtils.registerOpenApplicationHandler(this);
		MRJApplicationUtils.registerOpenDocumentHandler(this);
		MRJApplicationUtils.registerPrintDocumentHandler(this);
		/** where the preferences file is written to and read from on MacOS*/
		try{
			String macPrefsLoc = MRJFileUtils.findFolder(
				MRJFileUtils.kPreferencesFolderType).getPath();
			output("Preferences should be saved: "+macPrefsLoc);
			if(isMac) JackalPreferences.setDir(macPrefsLoc);
		} catch (FileNotFoundException fnfe){
			Alerts.showError("Preferences Problem",
			"Unable to find where preferences are stored on MacOS");
		}
	}
	
	/** MRJ - when the app opens */
	public void handleOpenApplication(){
	}
	
	/** 
	 *MRJ - when a file is dragged onto the application, open it .
	 * unfortunately due to Radar #2720352, this doesn't work right
	 */
	public void handleOpenFile(File file){
		openFile(file);
	}

	/** when print is selected from the contextual menu, open and print it */
	public void handlePrintFile(File file){
		openFile(file);
		print();
	}

/******************************************************************************
 **		CRICKET COMMUNICATIONS
 ******************************************************************************/

	/**
	 * this is used to pause and unpause the monitor updated so something
	 * else can use the serial port 
	 */
	private void setMonitorPaused(boolean pause){
		output("trying to set monitor to "+pause);
		if(pause) myMonitor.pause();
		else myMonitor.unpause();
		//while(myMonitor.isReallyPaused()!=pause);
		output("set monitor to "+pause);
	}

	/** translate and run the program ton the brick */
	public void brickRun(String s){
		setMonitorPaused(true);
		String codeToRun = Translator.translate(s);
		output("brickRun - ");
		try {
			if(myICClient.connected()) {
				output("....remote...");
				setStatus("Downloading code to run to IBrick...");
				myICClient.run(codeToRun);
			} else {
				setStatus("Downloading code to run...");
				myBrick.run(codeToRun);
			}
			setStatus("Download complete.");
		} catch (Exception e){
			//if(DEBUG) e.printStackTrace();
			setStatus("Error while downloading!");
			handleError(e.toString());
		}
		setMonitorPaused(false);
	}

	public void brickDownload(){
		DownloadDialog d = new DownloadDialog(this);
		if(d.errors!=null)
			Alerts.showError("Download Error",d.errors);
	}

	/** translate, add libraries, and download the program to the brick */
	public void reallyDownload() throws Exception{
		setMonitorPaused(true);
		String codeToDownload = addNeededLibraryProcs( Translator.translate( jtpProcedures.getText() ) );
		String codeToRun = Translator.translate( jtfRun.getText() );
		try {
			if(myICClient.connected()){
				output("....remote...");
				setStatus("Downloading code to IBrick...");
				myICClient.download(codeToRun,codeToDownload);
				//myICClient.run(codeToRun);
			} else {
				setStatus("Downloading code...");
				myBrick.download(codeToDownload, codeToRun, "beep");
			}
			setStatus("Downloaded "+myBrick.getCodeSize()+" bytes ( "+
				(myBrick.getCodeBufferSize()-myBrick.getCodeSize())+
				" available)");
		} catch (ClassCastException cce){
			cce.printStackTrace();
		}
		setMonitorPaused(false);
	}

	/** return the code only for the procedures you call from lib.txt */
	private String addNeededLibraryProcs(String txt){
		return EOL+addNeededLibraryProcs(txt, new Hashtable(),-1);
	}

	/** smartly add any library procedures that are used on download */
	private String addNeededLibraryProcs(String txt,Hashtable addedProcs, int numProcsAdded){
		setStatus("Adding any needed library procedures...");
		if(numProcsAdded == 0) return txt;		//return condition
		output("added "+numProcsAdded+" libraries");
		StringTokenizer st = new StringTokenizer(txt," \r\n[]()");
		String procsToAdd = "";
		String tempWord;
		String tempProcCode;
		numProcsAdded = 0;
		while(st.hasMoreTokens()){
			tempWord = st.nextToken();
			tempProcCode = procLibrary.getCode(tempWord);
			if(tempProcCode != null){
				//this is a procedure, so add it to the download
				if(addedProcs.get(tempWord) == null){
					//well, only really add it if it hasn't been added already
					addedProcs.put(tempWord,new Integer(1));		//add it with a useless int
					output("  added library proc '"+tempWord+"'");
					procsToAdd += EOL + tempProcCode+EOL;
					numProcsAdded++;
				}
			}
		}
		//output("--"+numProcsAdded+"----------------------------------------------");
		//output(procsToAdd+txt);
		//output("------------------------------------------------");
		setStatus("Added "+numProcsAdded+" library procedures");
		return addNeededLibraryProcs(procsToAdd+txt,addedProcs,numProcsAdded);
	}

	/** start the iBrick server */
	public void cricketServer(){
		//pop up some kind of interface window to control the server
		setStatus("Starting IBrick server...");
		IBrickServerDialog serverPopUp = new IBrickServerDialog(this,myBrick);
	}

	/** connect or disconnect to a remote brick */
	public void cricketRemote(){
		if(myICClient.connected()){			//disconnect
			setStatus("Closing IBrick connection...");
			output("cricketRemote : closing myICClient");
			setRemoteInterface(false);
			myICClient.connClose();
			setStatus("Closed IBrick connection.");
			setMonitorPaused(false);
		} else {							//connect
			setMonitorPaused(true);
			output("cricketRemote : opening myICClient");
			//pop up a modal dialog to input a username and servername
			setStatus("Opening IBrick connection...");
			IBrickConnectDialog connectPopup = new IBrickConnectDialog(this,this,myICClient);
		}
	}

	/** called by a IBrickConnectDialog once it is connected */
	public void setRemoteInterface(boolean connOK){
		jmbMenus.jmiBrickServer.setEnabled(!connOK);
		if(	connOK ){
			output("Connected!");
			jmbMenus.jmiBrickRemote.setText("Disconnect from IBrick");
			jmbMenus.jmBrick.setText("IBrick");
			setStatus("Connected to IBrick");
		} else {
			output("not connected!");
			jmbMenus.jmiBrickRemote.setText("Connect to IBrick");
			jmbMenus.jmBrick.setText("Cricket");
			setStatus("Unable to connect to IBrick");
		}
	}

/******************************************************************************
 **		UTILITY
 ******************************************************************************/

	/** set the text of the status bar, for general feedback to the user */
	public static void setStatus(String msg){
		if(DEBUG) System.out.println("STATUS: "+msg);
		jtfStatus.setText("> "+msg);
	}

	/** utility to get the program to pause for a bit */
	private void sleep(int timeMS){
		try{
			Thread.sleep(timeMS);
		} catch (Exception e) { 
			System.out.println(e);
			return;
		}
	}

	/** utility for getting default editor kit actions */
	public Action getActionByName(String name) {
		return (Action)(actions.get(name));
	}
	/** utility for getting default editor kit actions */
	private void createActionTable(JTextComponent textComponent) {
		actions = new Hashtable();
		Action[] actionsArray = textComponent.getActions();
		for (int i = 0; i < actionsArray.length; i++) {
			Action a = actionsArray[i];
			actions.put(a.getValue(Action.NAME), a);
		}
	}

	/** popup a standard question dialog */
    public int handleQuestion(String msg){
        output(msg);
        return JOptionPane.showConfirmDialog(this,msg,"?",JOptionPane.YES_NO_CANCEL_OPTION);
    }

	/** popup a standard error dialog */
	public void handleError(String msg){
		output(msg);
		String fixedMsg = msg;
		if(msg.indexOf("NullPointerException") > -1) return;
		if(msg.indexOf(":") > -1){
			fixedMsg = msg.substring( msg.lastIndexOf(":")+1 );
		}
		Alerts.showError("Error",fixedMsg);
	}

	/** popup a standard message dialog */
	public void handleMsg(String msg){
		output(msg);
		String fixedMsg = msg;
		if(msg.indexOf("NullPointerException") > -1) return;
		if(msg.indexOf(":") > -1){
			fixedMsg = msg.substring( msg.lastIndexOf(":")+1 );
		}
		Alerts.showMessage("For Your Information",fixedMsg);
	}

	/** utility for debugging */
	public void output(String msg){
		if (Jackal.DEBUG) System.out.println("Jackal : "+msg);
	}

/******************************************************************************
 **		FILE FUNCTION
 ******************************************************************************/

	/** ask them if they want to save a file, this should be smarter */
	private int askToSave(){
		int reply;
		if(lastProgramLength==0) return JOptionPane.NO_OPTION;
		int currProgramLength = jtpProcedures.getText().length();
		if(lastProgramLength == currProgramLength)
			return JOptionPane.NO_OPTION;
		reply = handleQuestion("Would you like to save first?");
		switch(reply){
			case JOptionPane.YES_OPTION:		//yes
				fileSave();
				break;
			case JOptionPane.NO_OPTION: 		//no
				break;
			case JOptionPane.CANCEL_OPTION: 	//cancel
				break;
		}
		return reply;
	}

    /** if this is an open file, save it, otherwise save as dialog */
    public int fileSave(){
        //if new file, not saved before
        if(currFile == null) return fileSaveAs();
        saveTo(currFile);
        return JFileChooser.APPROVE_OPTION;
    }
    
	/** prompt the user to save the program to a new file */
	public int fileSaveAs(){
		File file = FileDialogs.showSaveAWT("Save Your Program",
								"myProgram",DIR_PROGRAMS,FILE_EXTENSION,this);
		if (file!=null) {
            saveTo(file);
            output("File saved as "+file.getName());
			return JFileChooser.CANCEL_OPTION;
		} else {
			output("Save cancelled by user");
		}
        updateTitleBar();
		return JFileChooser.APPROVE_OPTION;
	}
    
	/** save the program to the specified file */
    private void saveTo(File f){
        try{
			//for macs to put the cute icon on it (MRJ Radar #2925661)
            output("Saving: " + f.getName() + ".");
			setStatus("Saving as \""+f.getName()+"\"...");
            FileWriter fwOut = new FileWriter(f);
            BufferedWriter out = new BufferedWriter(fwOut);
            //Daniel says to always save in english for portability
            out.write( Translator.translate(jtfRun.getText()+EOL) );
            out.write( Translator.translate(jtpProcedures.getText()) );
            out.flush();
            out.close();
            currFile = f;
			MRJFileUtils.setFileType(f,FILE_TYPE_LOGO);
			MRJFileUtils.setFileCreator(f,CREATOR_CODE);
			lastProgramLength = jtpProcedures.getText().length();
			setStatus("Saved to \""+f.getName()+"\"");
        } catch (IOException ioe){
            output(ioe.toString());
        }
    }

    /** works, but doesn't save the CommandCenter - is this a feature? */
	public void fileOpen(){
        //need to confirm save of previous file
        if(askToSave() == JOptionPane.CANCEL_OPTION) return;
		File file = FileDialogs.showOpenAWT("Open a Program","",DIR_PROGRAMS,FILE_EXTENSION,this);
		if(file==null){
			output("Open cancelled");
			setStatus("Open cancelled");
			return;
		}
		openFile(file);
/*		jfcPickFile.setCurrentDirectory(new File(DIR_PROGRAMS));
		jfcPickFile.setFileFilter(jfcPickFile.getAcceptAllFileFilter());
		int returnVal = jfcPickFile.showOpenDialog(this);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File file = jfcPickFile.getSelectedFile();
*/
	}

    /** read the procs and info stuff */
	private void openFile(File file){
		try {
			setStatus("Opening \""+file.getName()+"\"");
			String procs = "";
			BufferedReader in = new BufferedReader(new FileReader(file));
			Translator.setLanguages(Translator.eng,Translator.getIdentifier(language));
			jtfRun.setText(Translator.translate(in.readLine()));
			while(in.ready()){
				String currLine = in.readLine();
				procs += currLine+EOL;
			}
			jtpProcedures.setText(Translator.translate(procs));
			lastProgramLength = jtpProcedures.getText().length();
			currFile = file;
			Translator.setLanguages(Translator.getIdentifier(language),Translator.eng);
			setStatus("Opened \""+file.getName()+"\"");
		} catch (IOException ioe){
			output(ioe.toString());
		}
		updateTitleBar();
	}
    
    /** close the old file and open a simple program to edit */
    public void fileNew(){
        //need to confirm save of previous file
        if(askToSave() == JOptionPane.CANCEL_OPTION) return;
        currFile = null;
			Translator.setLanguages(Translator.eng,Translator.getIdentifier(language));
        String program = new String("to moof"+EOL+"\tbeep"+EOL+"end");
        jtpProcedures.setText(Translator.translate(program));
        //jtpProcedures.setText(program);		
			Translator.setLanguages(Translator.getIdentifier(language),Translator.eng);        
        jtfRun.setText(Translator.translate("moof"));
		lastProgramLength = jtpProcedures.getText().length();
		setStatus("Created new file");
        updateTitleBar();
    }

    /** go to the net and get a new libary file */
	public void updateLib(){
		try{
			setStatus("Updating libraries...");
			if( procLibrary.updateLibraryFile() ){
				handleMsg("Your libraries were updated - have fun!");
				setStatus("Libraries updated");
			} else {
				setStatus("Unable to update libraries");
			}
			//redo it anyway, in case someone changes the actual local file
			myTokenMarker.addKeywords( procLibrary.getKeys() );
		} catch (Exception e){
			//if(DEBUG) e.printStackTrace();
			handleError(e.toString());
		}
	}

/******************************************************************************
 **		FINDING STUFF - I tried something but it didn't work, to be written
 ******************************************************************************/

    /** doesn't do anything */
    private boolean didAFindAlready = false;

    /** doesn't do anything */
    public void find(){
        /*String str = JOptionPane.showInputDialog("What you like to find?");
        if(str==null) return;
		didAFindAlready = true;
        output("find: \""+str+"\"");
        jtpProcedures.find(str);*/
    }

    /** doesn't do anything */
    public void findAgain(){
        /*if(!didAFindAlready) return;
		output("find again: ");
        jtpProcedures.findAgain();*/
    }

    /** doesn't do anything */
    public void findAndReplace(){
        /*String str = JOptionPane.showInputDialog("What you like to find?");
		output("find: \""+str+"\"");*/
    }


/******************************************************************************
 **		INTERFACE HELPERS
 ******************************************************************************/

    /** Popup the Preferences dialog box */
	public void showPrefsDialog(){
		setMonitorPaused(true);
		PreferenceDialog prefsPopUp = new PreferenceDialog(this);
		prefsPopUp.show();
		setMonitorPaused(false);
	}

	/** save the preferences when the program quits */
	public void savePrefs(){
		JackalPreferences.setSerialPort( myBrick.getSerialPortName() );
		JackalPreferences.setLanguage( nextLanguage );
		JackalPreferences.setUserName( myICClient.defaultUserName );
		JackalPreferences.setServerAddress( myICClient.defaultServerAddress );
		JackalPreferences.setInterface( myInterfaceBuilder.getName() );
		//font and size are set by PreferenceDialog
		JackalPreferences.store();
	}

    /** Popup a window with the appropriate Logo command reference file */
	public void helpCommandRef(){
		switch(BRICK_TYPE){
			case HANDY_CRICKET:
				showHTMLWin("LogoRef-HandyCricket.html");
				break;
		}
	}

	/** set the title bar to be the current open file */
    private void updateTitleBar(){
        if(currFile == null) this.setTitle("Jackal - Untitled");
        else this.setTitle("Jackal - " + currFile.getName());
    }

	/** 
	 * prints the code, but not syntax highlighted...
	 */
	public void print(){
		setStatus("Printing...");
		JEditorPane tempPane = new JEditorPane(
			"text/plain",jtpProcedures.getText() );
		tempPane.setSize(PrintUtilities.COMPONENT_PRINTING_SIZE);
		PrintUtilities.printComponent(tempPane);	
		setStatus("Printing completed");
	}

	/** actually grab the properties from the InterfaceBuilder */
	public void populateInterface(String fname){
		try{
			output("Opening Interface: " + fname + ".");
			setStatus("Opening interface \""+fname+"\"");
			myInterfaceBuilder.load(fname);
			//remove all the components
			setVisible(false);
			interfacePanel.remove(jspCommand);
			interfacePanel.remove(jlDownload);
			interfacePanel.remove(jtfRun);
			interfacePanel.remove(jtpProcedures);
			interfacePanel.remove(jlMonitor);
			interfacePanel.remove(jipBgImage);
			//set their new locations and values
			myInterfaceBuilder.setNewBounds(jspCommand,myInterfaceBuilder.CMD);
			myInterfaceBuilder.setNewBounds(jlDownload,myInterfaceBuilder.DWN);
			myInterfaceBuilder.setNewBounds(jtfRun,myInterfaceBuilder.RUN);
			myInterfaceBuilder.setNewBounds(jlMonitor,myInterfaceBuilder.MON);		//taken out for now
			myInterfaceBuilder.setNewBounds(jtpProcedures,myInterfaceBuilder.PRC);
			ImageIcon tempII = myInterfaceBuilder.getImageIcon();
			jipBgImage.setImage(tempII.getImage());
			//re-add them all
			interfacePanel.add(jipBgImage);
			interfacePanel.add(jspCommand);
			interfacePanel.add(jlDownload);
			interfacePanel.add(jtfRun);
			interfacePanel.add(jlMonitor);			//taken out for now
			interfacePanel.add(jtpProcedures);
			interfacePanel.add(jipBgImage);
			//now resize the interface panel
			interfacePanel.setPreferredSize( new Dimension(
				tempII.getImage().getWidth(null),
				tempII.getImage().getHeight(null) )
			);
			resizeWin();		//and resize the frame
			setStatus( myInterfaceBuilder.getDescription() );
			setVisible(true);
		} catch (NullPointerException npe){
			npe.printStackTrace();
		}
	}

	/** resize the window after loading a new interface */
	private void resizeWin(){
		int heightFix = jtfStatus.getPreferredSize().height;
		output(" fix for height = "+heightFix);
		output(" image height = "+interfacePanel.getPreferredSize().height);
		//set the size with the IofF standard resizer
		GUIUtilities.setFrameSize(this,
				interfacePanel.getPreferredSize().width,
				interfacePanel.getPreferredSize().height+heightFix);
		if(!isMacOSX) {
			//do I need to change the size for a PC? (damn menu bars)
		}
		output("new imageUpdate : done...");
		this.setVisible(true);
	}

	/** popup a window showing the procedures defined in the library file */
	public void showProcDefs(){
		setStatus("Showing procedure definitions");
		TextViewerFrame myWin = new TextViewerFrame(
					"Library Procedures", procLibrary.getProcDefs() );
	}
	
	/** utility to popup a window displaying an HTML file */
	public void showHTMLWin(String file){
		output(" HTMLViewer - "+file);
		setStatus("Showing "+file);
		HtmlViewerFrame helpViewer = new HtmlViewerFrame(file,true);
	}

	/** 
	 * Key bindings to make it a better text editor.... 
	 * not used right now because JEditTextPane is so awesome
	 */
	protected void addRahulsKeymapBindings(JTextPane textPane) {
		//Add a new key map to the keymap hierarchy.
		Keymap keymap = textPane.addKeymap("RahulsBindings", textPane.getKeymap());
		Action action;
		KeyStroke key;

		//Ctrl-up_arrow to go to start of document
		action = getActionByName(DefaultEditorKit.beginAction);
		key = KeyStroke.getKeyStroke(KeyEvent.VK_UP, OS_KEY_MASK);
		keymap.addActionForKeyStroke(key, action);

		//Ctrl-left_arrow to go to start of line
		action = getActionByName(DefaultEditorKit.beginLineAction);
		key = KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, OS_KEY_MASK);
		keymap.addActionForKeyStroke(key,action);

		//Option-left_arrow to go to start of word
		action = getActionByName(DefaultEditorKit.beginWordAction);
		key = KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, OS_KEY_MASK);
		keymap.addActionForKeyStroke(key,action);

		//Ctrl-down_arrow to go to start of document
		action = getActionByName(DefaultEditorKit.endAction);
		key = KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, OS_KEY_MASK);
		keymap.addActionForKeyStroke(key,action);

		//Ctrl-right_arrow to go to start of line
		action = getActionByName(DefaultEditorKit.endLineAction);
		key = KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, OS_KEY_MASK);
		keymap.addActionForKeyStroke(key,action);

		//Option-right_arrow to go to start of word
		action = getActionByName(DefaultEditorKit.endWordAction);
		key = KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, OS_KEY_MASK);
		keymap.addActionForKeyStroke(key,action);

		textPane.setKeymap(keymap);
	}

}
