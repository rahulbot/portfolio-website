package org.instituteofthefuture.jackal.ibrick;

import java.awt.*;
import java.net.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;

import org.instituteofthefuture.gui.Alerts;

/** 
 *  <p>Popup to log into an IBrick server</p>
 *	<ul>
 *	<li>2002.11.20 - made standard java interface, moved to ibrick
 *	<li>2001.09.04 - fixed to be sized right on a pc - ugh!
 *  <li>2001.09.02 - cleaning up ModalJDialog and redoing for Jackel
 *	<lI>2000.12.02 - works :-)
 *	</ul>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */ 
public class IBrickConnectDialog extends JDialog implements ActionListener{
	public static final boolean DEBUG = false;
	
	private IBrickClient 		myClient;
	
	//interface components
	private IBrickManager	parent;
	private JTextField		jtfAddress;
	private JTextField		jtfName;
	
	//interface helpers
	private int myWidth = 485;
	private int myHeight = 180;

	public IBrickConnectDialog(JFrame p,IBrickManager cla,IBrickClient icc){
		super(p,true);
		this.parent = cla;
		this.myClient = icc;
		populate();
		this.setVisible(true);
	}

	/**
	 * build the interface
	 */
	public void populate(){
		output("populating..");
		Container cp = getContentPane();	
		cp.setLayout(null);
		JLabel label;	//for created labels
		//the header text
		label = new JLabel("Connect to an iBrick Server",JLabel.CENTER);
		label.setFont(new Font("SansSerif", Font.PLAIN, 20));
		label.setBounds(0,3,myWidth,40);
		cp.add(label);
		//the user name label
		label = new JLabel("User Name >",JLabel.RIGHT);
		label.setFont(new Font("SansSerif", Font.PLAIN, 12));
		label.setBounds(0,50,130,23);
		cp.add(label);
		//the user name to user
		if(myClient!=null)
		jtfName = new javax.swing.JTextField(myClient.defaultUserName);
		else jtfName = new javax.swing.JTextField();
		jtfName.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jtfName.setBounds(135,50,320,23);
		cp.add(jtfName);
		//the server address label
		label = new JLabel("Server Address >",JLabel.RIGHT);
		label.setFont(new Font("SansSerif", Font.PLAIN, 12));
		label.setBounds(0,84,130,23);
		cp.add(label);
		//the server address field
		if(myClient!=null)
		jtfAddress = new javax.swing.JTextField(myClient.defaultServerAddress);
		else jtfAddress = new javax.swing.JTextField();
		jtfAddress.setFont(new Font("SansSerif", Font.PLAIN, 12));
		jtfAddress.setBounds(135,84,320,23);
		cp.add(jtfAddress);
		//the connect button
		JButton jbuttConnect = new JButton("Connect");
		jbuttConnect.setBounds(358,120,100,30);
		jbuttConnect.addActionListener(this);
		cp.add(jbuttConnect);
		//the cancel button
		JButton jbuttCancel = new JButton("Cancel");
		jbuttCancel.setBounds(250,120,100,30);
		jbuttCancel.addActionListener(this);
		cp.add(jbuttCancel);
		//finish setting up the window elements
		this.setBounds(30,30,myWidth,myHeight);
		this.setResizable(false);
		output("done..");
	}

	/**
	 * Handles all the buttons
	 */
	public void actionPerformed(ActionEvent e){
		Object obj = e.getSource();
		if(obj instanceof JButton){
			if( ((JButton)obj).getText().equals("Connect") ){
				tryToConnect();
			} else if ( ((JButton)obj).getText().equals("Cancel") ){
				cancel();
			}
		}
	}
	
	/**
	 * Attempt to open up a connection to a remote server
	 */
	private void tryToConnect(){
		try {
			myClient.connOpen( jtfName.getText(), jtfAddress.getText() );
			myClient.defaultUserName = jtfName.getText();
			myClient.defaultServerAddress = jtfAddress.getText();
			parent.setRemoteInterface(true);
			closeDialog();
		} catch (Exception e){
			//output("CERROR: " +msg);
			handleError(e.toString());
		}	
	}

	/**
	 * Popup a standard alert, with a cleaned message
	 */
	public void handleError(String msg){
		output(msg);
		String fixedMsg = msg;
		if(msg.indexOf("NullPointerException") > -1) return;
		if(msg.indexOf(":") > -1){
			fixedMsg = msg.substring( msg.lastIndexOf(":")+1 );
		}
		Alerts.showError("Connect Error",fixedMsg);
	}

	/**
	 * close up the client connect
	 */
	private void cancel(){
		parent.setRemoteInterface(false);
		closeDialog();
	}

	/**
	 * just dump the dialog
	 */
	private void closeDialog(){
		this.dispose();
	}
	
	/**
	 * for debugging
	 */
	public void output(String msg){
		if (DEBUG) System.out.println("IBrickConnectDialog : "+msg);
	}

	/**
	 * for testing
	 */
	public static void main(String args[]){
		IBrickConnectDialog d = new IBrickConnectDialog(new JFrame(),null,null);
	}

}
