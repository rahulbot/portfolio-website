package org.instituteofthefuture.jackal;

//for application creator code / file type info
import com.apple.mrj.MRJOSType;
import com.apple.mrj.MRJFileUtils;

import java.io.File;

/**
 * <p>A bunch of useful constants for Jackal</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public interface JackalConstants{

	/** the current release version, string representation */
	public static String VERSION = "0.9";

/******************************************************************************
 **		FILE LOCATIONS
 ******************************************************************************/

	/** where default location for the preferences file */
	public static final String LIBRARY_FILE = "hc-lib.txt";
	/** where default location for the preferences file */
	public static final String DEFAULT_PREFS_DIR = ".";
	/** the name of the preferences file */
	public static final String PREFS_FILE = "Jackal-Preferences.txt";
	/** the default location for programs (used in open and save) */
	public static final String DIR_PROGRAMS = "programs/";
	/** the default location for interfaces (used in load) */
	public static final String DIR_INTERFACES = "interfaces/";
	/** the default location of various other support files */
  //  public static final String DIR_LANGS = "support/";
	/** homepage for this product */
	public static String HOMEPAGE_URL = "http://www.instituteofthefuture.org/jackal/";
	/** where to update the library file from */
	public static String LIBRARY_URL = HOMEPAGE_URL+LIBRARY_FILE;

/******************************************************************************
 **		BRICK_CONSTANTS
 ******************************************************************************/

	/** load up a YellowBrickManager */
	public static final int YELLOW_BRICK = 0;
	/** load up a BlueCricketManager */
	public static final int BLUE_CRICKET = 1;
	/** load up a HandyCricketManager */
	public static final int HANDY_CRICKET = 2;

/******************************************************************************
 **		FILE INFORMATION
 ******************************************************************************/

	/** the application creator code, registered with apple */
	public static MRJOSType CREATOR_CODE = new MRJOSType("Jakl");
	/** the file type for all created Logo files */
	public static MRJOSType FILE_TYPE_LOGO = new MRJOSType("logo");
	/** the file type for all created Logo files */
	public static String FILE_EXTENSION = new String("lgo");

}
