package org.instituteofthefuture.jackal.ibrick;

import java.io.*;				//for serializable
import java.util.*;				//for Vector

/**
 * <p>This lets us send messages back and forth to an IBrick.</p>
 *	<ul>
 *	<li>2002.01.17 - adding iTalk abilities
 *	<li>2001.09.01 - cleaning up for Jackel, renamed from IKM
 *	<li>2000.12.06 - added file load and file
 *	<li>2000.12.03 - added list, save, and head and user fields
 *	<li>2000.12.02 - added Login and Logout
 *	<li>2000.11.30 - created
 *	</ul>
 *
 * @see org.instituteofthefuture.jackal.ibrick.IBrickClient
 * @see org.instituteofthefuture.jackal.ibrick.IBrickServer
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class IBrickMessage implements Serializable {

	public static int PORT = 6576;

	public static int MSG_PROC = 0;		//downloading procedures
	public static int MSG_RUN = 1;		//running code
	public static int MSG_LOGIN = 2;	//login to IBrick server
	public static int MSG_LOGOUT = 3;	//logout from IBrick server
    public static int MSG_BYTE = 4;		//relay a byte from the monitor
	public static int MSG_ERROR = 8;	//server returns errors
	public static int MSG_OK = 9;		//typical response from server on any command
	
	private int msgType;
	private String user;
	private String head;
	private String msg;
	private Vector list;
    private int num;
	
	//constructors
	public IBrickMessage(int t, String u)
		{ msgType = t; user = u; }
	public IBrickMessage(int t, String u, String m)
		{ msgType = t; user = u; msg = m; }
	public IBrickMessage(int t, String u, Vector l)
		{ msgType = t; user = u; list = l; }
	public IBrickMessage(int t, String u, int n)
		{ msgType = t; user = u; num = n; }
	public IBrickMessage(int t, String u, String h, String m)
		{ msgType = t; user = u; head = h; msg = m; }
	public IBrickMessage(int t, String u, String h, Vector l)
		{ msgType = t; user = u; head = h; list = l; }
	public IBrickMessage(int t, String u, String h, String m, Vector l)
		{ msgType = t; user = u; head = h; msg = m; list = l; }
	
	//access methods
	public int getType() {return msgType;}
	public String getUser() {return user;}
	public String getHead() {return head;}
	public String getMsg() {return msg;}
	public Vector getList() {return list;}
    public int getNumber() {return num;}
    
	//set methods
    public void setType(int t) {msgType = t;}
	public void setUser(String u) {user = u;}
	public void setHead(String h) {head = h;}
	public void setMsg(String m) {msg = m;}
	public void setList(Vector l) {list = l;}
    public void setNumber(int n) {num = n;}
	
}
