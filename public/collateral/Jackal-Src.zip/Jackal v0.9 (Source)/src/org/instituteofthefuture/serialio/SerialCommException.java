package org.instituteofthefuture.serialio;

/**
 * <p>Execption with descriptive message for serial port errors</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public class SerialCommException extends Exception {

    public SerialCommException(String s){ super(s); }
    
}
