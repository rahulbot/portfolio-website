package org.instituteofthefuture.serialio;

import javax.comm.*;
import java.util.*;
import java.io.*;
import java.awt.Frame;

import org.instituteofthefuture.IFConstants;
import org.instituteofthefuture.gui.Alerts;

/**
 * <p>Wrapper for brick serial communications, uses Sun's javax.comm
 * API</p>
 *
 * @author Copyright (c) 2002, Rahul Bhargava.  All rights reserved.
 */
public abstract class SerialComm implements IFConstants{
	public static boolean DEBUG = false;

    protected String portName;
    protected SerialPort sp;
    protected InputStream input;
    protected OutputStream output;

	public SerialComm(){
		try{
			portName = availablePorts()[0];
		} catch (ArrayIndexOutOfBoundsException aiobe){
			if(isMac)
				Alerts.showError("No Serial Ports",
						"Unable to find any serial ports - \n"+
						"you probably forgot to plug in your\n"+
						"USB->Serial adaptor.");
			else 
				Alerts.showError("No Serial Ports","Unable to find any serial ports.");
		}
	}
	
    public SerialComm(String s) {
		portName = s; 
    }

    public abstract void deviceCheck() throws SerialCommException;
    public abstract void runCommand(int addr, int[] bytes) throws SerialCommException;
    public abstract void downloadCode(int addr, int[] bytes) throws SerialCommException;
    public abstract boolean bytesEqual(int addr, int[] bytesToCompare) throws SerialCommException;

    protected void write(int b) throws SerialCommException {
		try {
		    output.write(b);
		} catch (Exception ioe) {
		    throw new SerialCommException("Serial I/O error in write");
		}
    }

    public int read() throws SerialCommException{
		try {
		    return input.read();
		} catch (Exception ioe) {
		    throw new SerialCommException("Serial I/O error in read");
		}
    }
    
    public int readWord() throws SerialCommException{
		int high = read();
		int low = read();
		return high*256+low;
    }

    protected void clearcom() throws SerialCommException {
		try {
		    input.skip(input.available());
		} catch (Exception ioe) {
		    throw new SerialCommException("Serial I/O error in clearcom");
		}
    }

    public void close() throws SerialCommException{
		try {
	    	sp.close();
		}	catch (Exception ioe) {
	    	throw new SerialCommException("Serial I/O error in close");
		}
    }

	protected void init(int baud) throws SerialCommException{ 
		try {
		    if(sp != null) close();		//added to hopefully be friendlier in ownership
		    output("initializing port: " + portName);
		    sp= (SerialPort)(CommPortIdentifier.getPortIdentifier(portName).open("Serial Communications",50));
		    sp.setSerialPortParams(baud, sp.DATABITS_8, sp.STOPBITS_1, sp.PARITY_NONE);
		    sp.enableReceiveTimeout(15);
		    output=sp.getOutputStream();
		    input=sp.getInputStream();
		} catch (PortInUseException piue) { 
		    throw new SerialCommException("Serial port in use"); 
		} catch (NoSuchPortException nspe) {
			throw new SerialCommException("No serial port with that name");
		} catch (UnsupportedCommOperationException ucoe) {
			throw new SerialCommException("Can't perform that serial operation");
		} catch (IOException e) {
			throw new SerialCommException(e.getMessage());
		} catch (Exception e){
            output("SerialComm error in init! "+e.toString());
            e.printStackTrace();
        }
    }

    public static String[] availablePorts() {
		Enumeration sportsAll = null;
		Vector v = new Vector();
		SerialPort sp;
		CommPortIdentifier portID;
	
		if (isMac && !isMacOSX) {
		    try {
				CommDriver cd = (CommDriver)Class.forName("javax.comm.mac.MacCommDriver").newInstance();
				cd.initialize();
			} catch (Exception e) {
				Alerts.showError("Internal Error",
						"Sorry, but I was unable to load MacCommDriver - you "+
						"probably don't have javax.comm installed correctly.");
			}
		}
		sportsAll= CommPortIdentifier.getPortIdentifiers();
		
		while (sportsAll.hasMoreElements()) {
		    portID= (CommPortIdentifier)(sportsAll.nextElement());
		    //System.out.println("port id : " + portID.getName());
		    if (portID.getPortType() == portID.PORT_SERIAL) {
				v.addElement(portID.getName());
		   	}
		}
		String[] ports = new String[v.size()];
		v.copyInto(ports);
		return ports;
    }
    
    public void setPortName(String n){
    	portName = n;
    }
    
    public String getPortName(){
    	return portName;
    }

	/** utility for debugging */
	public void output(String msg){
		if (DEBUG) System.out.println("SerialComm : "+msg);
	}
    
}
