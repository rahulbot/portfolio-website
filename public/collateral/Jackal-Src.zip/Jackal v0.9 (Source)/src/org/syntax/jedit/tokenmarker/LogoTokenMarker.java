/**
 * <p>Logo token marker - copied from Perl token marker, added a bunch
 * of things</p>
 *	<ul>
 *	<li>2002.11.23 - moved config file to library inside of jar
 *	</ul>
 *
 * @author Rahul Bhargava, Institute of the Future
 */

package org.syntax.jedit.tokenmarker;

import java.io.*;
import java.util.*;
import javax.swing.text.Segment;

import org.instituteofthefuture.jackal.logoutils.Translator;
import org.instituteofthefuture.io.FileUtilities;

import org.syntax.jedit.KeywordMap;

/**
 * Perl token marker.
 *
 * @author Slava Pestov
 * @version $Id: PerlTokenMarker.java,v 1.11 1999/12/13 03:40:30 sp Exp $
 */
public class LogoTokenMarker extends TokenMarker
{
	static boolean DEBUG = false;

	private void output(String msg){
		if(DEBUG)
			System.out.println(" LogoTokenMarker: "+msg);
	}

	public LogoTokenMarker(String fileName)
	{
		output("init file = "+fileName);
		populateKeywordsFromFile(fileName);
	}

    private int lastOffset;
    private int lastKeyword;
    
	public byte markTokensImpl(byte token, Segment line, int lineIndex)
	{
        output("LogoTokenMarker : line = \""+line+"\"");
		char[] array = line.array;
		int offset = line.offset;
		lastOffset = offset;
		lastKeyword = offset;
		int length = line.count + offset;
		boolean backslash = false;

loop:		for(int i = offset; i < length; i++)
		{
			int i1 = (i+1);

			char c = array[i];
			if(c == '\\')
			{
				backslash = !backslash;
				continue;
			}

			switch(token)
			{
			case Token.NULL:
				switch(c)
				{
				case '"':
					doKeyword(line,i,c);
					if(backslash)
						backslash = false;
					else
					{
						addToken(i - lastOffset,token);
						token = Token.LITERAL1;
						lastOffset = lastKeyword = i;
					}
					break;
				case ';':
					if(backslash)
						backslash = false;
					else
					{
						doKeyword(line,i,c);
						addToken(i - lastOffset,token);
						addToken(length - i,Token.COMMENT1);
						lastOffset = lastKeyword = length;
						break loop;
					}
					break;
				default:
					backslash = false;
					if(!Character.isLetterOrDigit(c)
						&& c != '_' && c!= '-')		//"-" is part of a keyword to!
						doKeyword(line,i,c);
					break;
				}
				break;
			case Token.LITERAL1:
				if(backslash)
					backslash = false;
				else if(c == ' ')
				{
					addToken(i1 - lastOffset,token);
					token = Token.NULL;
					lastOffset = lastKeyword = i1;
				}
				break;
			default:
				throw new InternalError("Invalid state: "
					+ token);
			}
		}

		if(token == Token.NULL)
			doKeyword(line,length,'\0');

		switch(token)
		{
		case Token.LITERAL1:
			addToken(length - lastOffset,Token.INVALID);
			token = Token.NULL;
			break;
		default:
			addToken(length - lastOffset,token);
			break;
		}

		return token;
	}
    
	private static KeywordMap logoKeywords;

	private static KeywordMap getKeywords()
	{
		return logoKeywords;
	}	

	private boolean doKeyword(Segment line, int i, char c)
	{
		int i1 = i+1;

		int len = i - lastKeyword;
		byte id = logoKeywords.lookup(line,lastKeyword,len);
		if(id != Token.NULL)
		{
			if(lastKeyword != lastOffset)
				addToken(lastKeyword - lastOffset,Token.NULL);
			addToken(len,id);
			lastOffset = i;
		}
		lastKeyword = i1;
		return false;
	}

//-----------------------------------------------------------------------------
// FILE INIT
//-----------------------------------------------------------------------------

	public void populateKeywordsFromFile(String fileLoc){
		int i = 0;
		String line;
		String temp,groupName;
        byte groupID = 0;
		StringTokenizer lineTokens;
        logoKeywords = new KeywordMap(true);
		try{
			//BufferedReader langFile = new BufferedReader(new FileReader(fileLoc));
			BufferedReader langFile = 
				FileUtilities.getBufferedReaderFromResource(fileLoc);
			while(langFile.ready()){
				line = langFile.readLine();
                //ignore blank lines and comments
				if(line.length()==0 || line.indexOf("//")==0) continue;
				lineTokens = new StringTokenizer(line," ");
                //handle the define line
                if(lineTokens.countTokens()==2){	//it's a define line
                    temp =  lineTokens.nextToken();	//dump the semicolon
                    groupName = lineTokens.nextToken();	//dump the group name
                    if(groupName.equals("KEYWORD1")) groupID = Token.KEYWORD1;
                    else if(groupName.equals("KEYWORD2")) groupID = Token.KEYWORD2;
                    else if(groupName.equals("KEYWORD3")) groupID = Token.KEYWORD3;
                    else if(groupName.equals("OPERATOR")) groupID = Token.OPERATOR;
                    continue;
                }
				//handle each keyword
				temp = lineTokens.nextToken();
				if( (temp!=null) ) logoKeywords.add(Translator.translateWord(temp),groupID);
                i++;
			}
			//System.out.println("keyword count = "+i);
		} catch (IOException ioe){
			System.out.println("Unable to load Syntax Coloring file from '"+fileLoc+"'!");	
		} catch (NullPointerException npe){
			npe.printStackTrace();
		}
	}
    
    public void addKeywords(Vector strings){
        for(int i=0;i<strings.size();i++){
            output("LogoTokenMarker: added \""+(String)strings.elementAt(i)+"\"");
            logoKeywords.add((String)strings.elementAt(i),Token.KEYWORD3);
        }
        //System.out.println("added "+strings.size());
    }
    
}
