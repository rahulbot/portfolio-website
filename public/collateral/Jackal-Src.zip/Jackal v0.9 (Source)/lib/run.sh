java -cp Jackal-OSX.jar Jackal handycricket
