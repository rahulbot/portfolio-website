# this is a little script to build a disk image of a folder, the
# preferred way to release software for OSX
#!/bin/sh

VOL="$1"
DIR="release"
SRC="$2"
DMG="${DIR}/temp-$VOL.dmg"
MSG="copy this folder to your hard drive ->"

rm -f "${DIR}${VOL}.dmg"
hdiutil create "$DMG" -megabytes 5 -ov -type UDIF
DISK=`hdid -nomount "$DMG" |awk '/scheme/ {print substr ($1, 6, length)}'`
newfs_hfs -v "$VOL" /dev/r${DISK}s2
hdiutil eject $DISK
hdid ${DMG}
mkdir "/Volumes/${VOL}/${SRC}/"
touch "/Volumes/${VOL}/${MSG}"
ditto -rsrcFork -v "${DIR}/$SRC" "/Volumes/${VOL}/${SRC}/"
hdiutil eject $DISK
hdiutil convert ${DMG} -format UDZO -o "${DIR}/${VOL}.dmg"
rm -f "$DMG"
