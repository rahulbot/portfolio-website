
@APP@ Source Code v@VERSION@ (@DATE@)

Jackal is open-sourced, which means you are free to use the code
as you see fit.  All code is meant to adhere to the Java 1.1.8 API
(plus swing) - this due to really old Java support on Mac Classic.

Jackal comes under the MIT license, so you don't need to open-source
a project that uses some of this code (but you do need to credit
that it comes from Jackal).   We kindly ask that you submit any
useful changes or additions back to the community. The code is pretty
well commented. The lead developer is Rahul Bhargava, submit any
useful changes to
  rahulb@instituteofthefuture.org

Portions of the Jackal code were written by Rahul while he was a
graduate student at MIT.  That code has been legally released by
MIT as open-source.

--------
BUILDING
--------

@APP@ uses ant to compile.  Ant is a fantastic open-source
cross-platform build tool created by the Apache group.

There is a little tutorial about how to set ant up at:
  http://builder.com.com/article.jhtml?id=r00120020206jam01.htm
and you can find a reference for it at:
  http://jakarta.apache.org/ant/manual/index.html

The home build system is Mac OSX, but I have built it successfully
on Windows (the only thing that doesn't work, of course, is the
script to create a .dmg for Mac OSX)  Sorry, as far as I can tell,
ant doesn't run on Mac Classic - and shame on you for even thinking
about developing on that old OS!

So to do a fresh build, open a command line to the Jackal-Source
directory and type:
 ant compile
that will compile jar files for OSX, Mac, and PC.

-------
PORTING
-------

** TO OTHER LANGUAGES **

Although Jackal is written in Java, it doesn't use the i18n the
"right" way.  This is because it's more about being able to
program the Brick in another language, rather than having the
interface be translated.

There are a few files to edit for i18n : 
  - create a new GUIProperties file for your language
  - create a column in the languages.txt file with translations
    for the Logo commands
  - change jackal.logoutils.Translator to support the new language

** TO OTHER DEVICES **

This seemed like a good idea, so most of Jackal's code tries to
isolate the Brick as much as possible behind the BrickManager
implementation.  It would be quite simple to swap in a new compiler
for some other microprocessor and just use the Jackal GUI on top
of other back-end code.  All you need to do is:
 - wrap up a compiler and comm class behind a new BrickManager
 - add a new BrickType for that microprocessor
 - change the code whenever there is a "switch(BRICK_TYPE)" to
    do the appropriate thing for your brick
 - make a new syntax highlighting configuration file
 - probably add some words to the Translator config file, or
    just turn it off

** TO OTHER PLATFORMS **

Should be simple, as long as the have a reasonably good Java
implementation.  The important thing to do is find a working
javax.comm implementation for that platform.  Then just add
another target to the build file.

-------
Credits
-------

Jackal was created by Rahul Bhargava. However, a number of other
resources are used within :
 - the com.handyboard.cricket package is licensed from Fred Martin,
    with minor additions by Rahul Bhargava
 - the javax.comm.MRJ package is copyright 1999 Patrick Beard
    beard@netscape.com
    http://homepage.mac.com/pcbeard/javax.comm.MRJ/
 - the javax.comm installer for MacOS is from RXTX
    http://www.rxtx.org
 - the org.syntax.jedit package is Copyright (C) 1999 Slava Pestov
    http://syntax.jedit.org
 - the BrowerLauncher class is courtesy Eric Albert
 	ejalbert@cs.stanford.edu
 - Java2HTML v1.2 is copyright (c) 2000 Ritelink Computing Ltd.
    http://www.java2html.com
