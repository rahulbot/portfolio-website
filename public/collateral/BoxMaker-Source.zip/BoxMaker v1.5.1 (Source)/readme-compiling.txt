
I use ant to compile, an open-source cross-platform build tool.

There is a little tutorial about how to set ant up at:
  <http://builder.com.com/article.jhtml?id=r00120020206jam01.htm>
and you can find a reference for it at:
  <http://jakarta.apache.org/ant/manual/index.html>
  