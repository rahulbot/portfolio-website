package com.rahulbotics.boxmaker;

import com.rahulbotics.Constants;

/** 
 * Just a useful place to collect constants used in this application.
 *
 *	@author Rahul Bhargava
 */
public interface BoxMakerConstants extends Constants{

	public static String APP_NAME = "BoxMaker";

	public static String VERSION = "1.5.1";

	public static String PREFS_FILE = "BoxMaker.properties";
    
    public static String WEBSITE_URL = "http://www.rahulbotics.com/boxmaker/";

}
